/**
 * Image Upload API Route
 * 
 * Uploads images to the Python backend service for later use in slide injection.
 */

import { NextRequest, NextResponse } from 'next/server';

const SLIDE_SERVICE_PORT = 3002;

/**
 * POST /api/slides/images/upload
 * Upload an image for use in slide generation
 */
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/images/upload`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
      return NextResponse.json(
        { error: errorData.detail || 'Upload failed' },
        { status: response.status }
      );
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Image upload error:', error);
    return NextResponse.json(
      { error: 'Failed to connect to slide generator service' },
      { status: 503 }
    );
  }
}
