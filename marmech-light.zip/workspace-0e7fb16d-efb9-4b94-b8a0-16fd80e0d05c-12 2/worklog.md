# BTS MarTech Slide Generator - Project Handoff

## Project Overview
A comprehensive PowerPoint slide generation application with AI-powered text generation, style preservation, and BTS corporate branding.

## Current State: FULLY WORKING ✅

### Core Features (All Functional)
1. **Template Upload** - Upload .pptx templates and extract placeholder information
2. **Text Injection** - Inject text while preserving original template formatting
3. **Style Customization** - Font family, size, bold, italic controls per placeholder
4. **Color Picker** - 10 BTS corporate colors with visual selection
5. **AI Text Generation** - Generate content for all slides using z-ai chat
6. **Style Preservation** - "Preserve original template style" option works correctly
7. **Theme Color Support** - Extracts and preserves theme colors from templates

### BTS Corporate Colors
| Name | Hex | Usage |
|------|-----|-------|
| Deep Navy | #0A1A5F | Primary brand color |
| Mid Blue | #0088C7 | Secondary brand color |
| Light Cyan | #4AD8E0 | Accent color |
| Dark Blue | #004E8C | Professional blue |
| Heading Navy | #1A2A5F | For headings |
| Body Gray | #333333 | For body text |
| White | #FFFFFF | For light backgrounds |
| Alert Red | #E53935 | For emphasis |
| Success Green | #43A047 | For positive data |
| Warning Orange | #FB8C00 | For highlights |

---

## Architecture

### Services
```
├── Next.js App (Port 3000) - Main frontend
│   └── src/app/page.tsx - Main page
│   └── src/components/bts/ - BTS components
│
└── Slide Generator Service (Port 3002) - Python/FastAPI
    ├── api.py - REST API endpoints
    ├── slide_generator.py - Core slide generation
    ├── mlx_generator.py - AI text generation via z-ai
    └── chart_generator.py - Chart generation
```

### Key Files

**Frontend:**
- `src/components/bts/SlideGeneratorForm.tsx` - Main form component
- `src/components/bts/TemplateUploader.tsx` - Template upload component
- `src/app/api/slides/` - API route handlers (proxy to Python service)

**Backend (Python):**
- `mini-services/slide-generator/api.py` - FastAPI endpoints
- `mini-services/slide-generator/slide_generator.py` - Core logic with style preservation
- `mini-services/slide-generator/mlx_generator.py` - AI text generation using z-ai chat

---

## How to Run

### Services auto-start, but if needed:
```bash
# Frontend (auto-runs on port 3000)
cd /home/z/my-project && bun run dev

# Slide Generator (auto-runs on port 3002)
cd /home/z/my-project/mini-services/slide-generator
./venv/bin/uvicorn api:app --host 0.0.0.0 --port 3002 --reload
```

---

## Recent Bug Fixes (Important for Context)

### 1. Color Not Applied to Generated PPTX
**Problem:** Colors selected in UI appeared as black in downloaded PPTX.
**Solution:** Three-part fix:
- Added `'color': item.style.color` to `extract_style()` in api.py
- Added hex-to-RGBColor conversion in `_style_dict_to_text_style()` in slide_generator.py
- Added `preserved_style.font_color = custom_text_style.font_color` in `_inject_text_preserve_style()`

### 2. Theme Colors Not Preserved
**Problem:** Templates using PowerPoint theme colors lost their colors.
**Solution:** Enhanced `_extract_run_style()` to handle both RGB and theme color references.

### 3. AI Generation Not Working for All Slides
**Problem:** Only one slide was being filled.
**Solution:** Updated API to loop through ALL slides in the template with slide context.

### 4. JSON Parsing from z-ai
**Problem:** z-ai output includes log lines and markdown code blocks.
**Solution:** Added parsing logic to extract JSON from output:
- Strip ```json and ``` markers
- Find JSON starting with `{`

---

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/slides/templates/upload-secure` | POST | Upload template |
| `/api/slides/placeholders/{template_id}/{slide_index}` | GET | Get placeholders |
| `/api/slides/generate` | POST | Generate presentation |
| `/api/slides/download/{filename}` | GET | Download generated file |

### Generate Request Payload
```json
{
  "template_id": "template_name_abc123",
  "slide_index": 0,
  "use_ai_generation": false,
  "global_prompt": "Optional AI prompt",
  "placeholder_styles": {
    "0": {
      "fontFamily": "Arial",
      "fontSize": 36,
      "bold": true,
      "italic": false,
      "color": "#0088C7",
      "useOriginalStyle": false
    }
  },
  "content": {
    "title": { "text": "Title", "style": {...} },
    "subtitle": { "text": "Subtitle", "style": {...} },
    "body": { "text": "Body text", "style": {...} }
  }
}
```

---

## Known Limitations / Future Improvements

1. **Image Placeholders** - Currently shown but not editable in UI
2. **Chart Generation** - Backend supports it, frontend not exposed
3. **Multi-template Selection** - Currently one template at a time
4. **History/Saved Presentations** - Not implemented
5. **Preview before download** - Not implemented

---

## Dependencies

**Frontend:**
- Next.js 16, React, TypeScript
- shadcn/ui components, Tailwind CSS
- Lucide icons

**Backend:**
- Python 3.12, FastAPI
- python-pptx for PowerPoint manipulation
- z-ai CLI for AI text generation

---

## For New Chat Session

Simply say:
> "Please read /home/z/my-project/worklog.md to understand the BTS MarTech Slide Generator project, then help me continue development."

This will give the new session full context of the working application.
