/**
 * Image List API Route
 * 
 * List all uploaded images.
 */

import { NextResponse } from 'next/server';

const SLIDE_SERVICE_PORT = 3002;

/**
 * GET /api/slides/images/list
 * List all uploaded images
 */
export async function GET() {
  try {
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/images/list`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      return NextResponse.json(
        { error: 'Failed to fetch images' },
        { status: response.status }
      );
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Image list error:', error);
    return NextResponse.json(
      { error: 'Failed to connect to image service' },
      { status: 503 }
    );
  }
}
