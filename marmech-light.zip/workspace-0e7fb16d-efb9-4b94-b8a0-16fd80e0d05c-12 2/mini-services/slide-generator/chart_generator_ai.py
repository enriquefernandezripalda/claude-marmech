"""
AI-Powered Chart Generator
==========================

Intelligent chart generation from CSV data using AI.
Analyzes data structure, determines best chart type, and creates professional visualizations.

Author: BTS MarTech Team
"""

import os
import json
import subprocess
from dataclasses import dataclass
from typing import Optional, List, Dict, Any, Tuple
from pathlib import Path

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
from pptx.chart.data import CategoryChartData

# BTS Brand Colors
BTS_COLORS = [
    RGBColor(0x0A, 0x1A, 0x5F),  # Deep Navy
    RGBColor(0x00, 0x88, 0xC7),  # Mid Blue
    RGBColor(0x4A, 0xD8, 0xE0),  # Light Cyan
    RGBColor(0x00, 0x4E, 0x8C),  # Dark Blue
    RGBColor(0x1A, 0x2A, 0x5F),  # Heading Navy
]

BTS_COLOR_NAMES = ['Deep Navy', 'Mid Blue', 'Light Cyan', 'Dark Blue', 'Heading Navy']


@dataclass
class ChartSpecification:
    """AI-generated chart specification."""
    chart_type: str  # bar, line, pie, column, area
    title: str
    x_axis_column: str
    y_axis_columns: List[str]
    series_names: Optional[List[str]] = None
    legend_position: str = "bottom"
    insights: str = ""
    confidence: float = 1.0


@dataclass
class AIChartResult:
    """Result of AI chart generation."""
    success: bool
    message: str
    chart_spec: Optional[ChartSpecification] = None
    download_url: Optional[str] = None
    errors: List[str] = None
    
    def __post_init__(self):
        if self.errors is None:
            self.errors = []


class AIChartGenerator:
    """
    AI-powered chart generator that analyzes CSV data and creates charts.
    """
    
    def __init__(self, templates_dir: str = "templates", output_dir: str = "output"):
        self.templates_dir = Path(templates_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
    
    def analyze_data_with_ai(
        self,
        csv_headers: List[str],
        csv_rows: List[List[str]],
        user_prompt: str
    ) -> ChartSpecification:
        """
        Use AI to analyze CSV data and determine the best chart configuration.
        
        Args:
            csv_headers: Column headers from CSV
            csv_rows: Data rows from CSV
            user_prompt: User's instructions for what chart to create
            
        Returns:
            ChartSpecification with AI-recommended chart settings
        """
        
        # Sample data for AI analysis (first 10 rows)
        sample_data = csv_rows[:10]
        
        # IMPORTANT: Check if user explicitly requested a specific chart type
        user_prompt_lower = user_prompt.lower()
        explicit_chart_type = None
        if 'pie chart' in user_prompt_lower or 'pie' in user_prompt_lower:
            explicit_chart_type = 'pie'
        elif 'line chart' in user_prompt_lower or 'line' in user_prompt_lower:
            explicit_chart_type = 'line'
        elif 'bar chart' in user_prompt_lower or 'bar' in user_prompt_lower:
            explicit_chart_type = 'bar'
        elif 'column chart' in user_prompt_lower or 'column' in user_prompt_lower:
            explicit_chart_type = 'column'
        elif 'area chart' in user_prompt_lower or 'area' in user_prompt_lower:
            explicit_chart_type = 'area'
        
        # Build AI prompt
        ai_prompt = f"""You are a data visualization expert. Analyze this CSV data and create a chart specification.

CSV HEADERS: {json.dumps(csv_headers)}

SAMPLE DATA (first 10 rows):
{json.dumps(sample_data, indent=2)}

USER REQUEST: {user_prompt}

CRITICAL: If the user explicitly requested a specific chart type (like "pie chart", "bar chart", etc.), you MUST use that chart type in the "chart_type" field.

Determine the best chart configuration. Consider:
1. What chart type best represents this data? (bar, line, pie, column, area) - RESPECT USER'S EXPLICIT REQUEST!
2. Which column should be the X-axis (categories)?
3. Which columns contain numeric data for Y-axis (values)? For pie charts, use ONE numeric column.
4. What should the chart title be?
5. Any key insights about the data?

Respond ONLY with valid JSON in this exact format:
{{
  "chart_type": "bar|line|pie|column|area",
  "title": "Chart Title Here",
  "x_axis_column": "column_name",
  "y_axis_columns": ["numeric_column1"],
  "series_names": ["Series 1 Name"],
  "legend_position": "bottom|right|top|left|none",
  "insights": "Brief insight about the data",
  "confidence": 0.95
}}

Generate the JSON response now:"""

        # Call AI
        try:
            result = subprocess.run(
                ['z-ai', 'chat', '-p', ai_prompt],
                capture_output=True,
                text=True,
                timeout=60
            )
            
            if result.returncode != 0:
                raise Exception(f"AI call failed: {result.stderr}")
            
            # Parse AI response
            output = result.stdout
            spec = self._parse_ai_response(output, csv_headers, csv_rows, explicit_chart_type)
            return spec
            
        except subprocess.TimeoutExpired:
            raise Exception("AI analysis timed out")
        except Exception as e:
            raise Exception(f"AI analysis failed: {str(e)}")
    
    def _parse_ai_response(
        self, 
        output: str, 
        headers: List[str], 
        rows: List[List[str]],
        explicit_chart_type: Optional[str] = None
    ) -> ChartSpecification:
        """Parse AI response and create ChartSpecification."""
        
        json_str = output
        
        # First, try to parse as z-ai CLI response (outer JSON)
        try:
            outer_data = json.loads(json_str)
            # z-ai returns: {"choices": [{"message": {"content": "..."}}]}
            if 'choices' in outer_data and len(outer_data['choices']) > 0:
                message = outer_data['choices'][0].get('message', {})
                json_str = message.get('content', '')
                print(f"DEBUG: Extracted content from z-ai response: {json_str[:200]}...")
        except json.JSONDecodeError:
            # Not a z-ai response, continue with raw output
            pass
        
        # Strip markdown code blocks if present
        if '```json' in json_str:
            json_str = json_str.split('```json')[1].split('```')[0]
        elif '```' in json_str:
            json_str = json_str.split('```')[1].split('```')[0]
        
        # Find the first { and last }
        start_idx = json_str.find('{')
        end_idx = json_str.rfind('}')
        if start_idx != -1 and end_idx != -1:
            json_str = json_str[start_idx:end_idx + 1]
        
        print(f"DEBUG: Final JSON to parse: {json_str}")
        
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError as e:
            # The string might be escaped for JSON-in-JSON
            # Try to unescape it first
            try:
                unescaped = json_str.encode('utf-8').decode('unicode_escape')
                # Remove any extra escaping of quotes
                unescaped = unescaped.replace('\\"', '"')
                data = json.loads(unescaped)
            except Exception as e2:
                # Fallback to auto-detection
                print(f"DEBUG: JSON decode failed (tried unescape), using auto-detection. Error: {e}, {e2}")
                return self._auto_detect_chart_spec(headers, rows, explicit_chart_type)
        
        # Validate and create spec
        chart_type = data.get('chart_type', 'bar')
        print(f"DEBUG: AI returned chart_type: {chart_type}")
        print(f"DEBUG: explicit_chart_type: {explicit_chart_type}")
        
        if chart_type not in ['bar', 'line', 'pie', 'column', 'area']:
            chart_type = 'bar'
        
        # IMPORTANT: Override with explicit user request if detected
        if explicit_chart_type:
            chart_type = explicit_chart_type
            print(f"DEBUG: Overriding with explicit_chart_type: {chart_type}")
        
        print(f"DEBUG: Final chart_type to use: {chart_type}")
        
        return ChartSpecification(
            chart_type=chart_type,
            title=data.get('title', 'Data Analysis'),
            x_axis_column=data.get('x_axis_column', headers[0] if headers else ''),
            y_axis_columns=data.get('y_axis_columns', []),
            series_names=data.get('series_names'),
            legend_position=data.get('legend_position', 'bottom'),
            insights=data.get('insights', ''),
            confidence=data.get('confidence', 0.8)
        )
    
    def _auto_detect_chart_spec(
        self, 
        headers: List[str], 
        rows: List[List[str]],
        explicit_chart_type: Optional[str] = None
    ) -> ChartSpecification:
        """Auto-detect chart specification when AI fails."""
        
        # Use explicit chart type if provided
        chart_type = explicit_chart_type if explicit_chart_type else 'bar'
        
        # Find first string column for X-axis
        x_column = headers[0] if headers else ''
        numeric_columns = []
        
        for i, header in enumerate(headers):
            # Check if column contains numeric data
            is_numeric = True
            for row in rows[:5]:
                if i < len(row):
                    try:
                        float(row[i].replace(',', '').replace('$', '').replace('%', ''))
                    except (ValueError, AttributeError):
                        is_numeric = False
                        break
                else:
                    is_numeric = False
            
            if is_numeric and header != x_column:
                numeric_columns.append(header)
            elif not is_numeric and x_column == headers[0]:
                x_column = header
        
        # If no numeric columns found, use first non-x column
        if not numeric_columns and len(headers) > 1:
            numeric_columns = [headers[1]]
        
        return ChartSpecification(
            chart_type=chart_type,  # Use the detected or explicit chart type
            title='Data Analysis',
            x_axis_column=x_column,
            y_axis_columns=numeric_columns[:3],  # Limit to 3 series
            insights='Auto-generated chart configuration',
            confidence=0.5
        )
    
    def generate_chart(
        self,
        csv_headers: List[str],
        csv_rows: List[List[str]],
        user_prompt: str,
        output_filename: str
    ) -> AIChartResult:
        """
        Generate a chart from CSV data using AI analysis.
        
        Args:
            csv_headers: Column headers from CSV
            csv_rows: Data rows from CSV  
            user_prompt: User's instructions
            output_filename: Output PPTX filename
            
        Returns:
            AIChartResult with generation status
        """
        errors = []
        
        try:
            # Analyze data with AI
            spec = self.analyze_data_with_ai(csv_headers, csv_rows, user_prompt)
            
            print(f"DEBUG generate_chart: chart_type={spec.chart_type}")
            print(f"DEBUG generate_chart: x_axis_column={spec.x_axis_column}")
            print(f"DEBUG generate_chart: y_axis_columns={spec.y_axis_columns}")
            print(f"DEBUG generate_chart: title={spec.title}")
            
            # Create presentation with chart
            prs = Presentation()
            prs.slide_width = Inches(13.333)
            prs.slide_height = Inches(7.5)
            
            # Add blank slide
            blank_layout = prs.slide_layouts[6]  # Blank layout
            slide = prs.slides.add_slide(blank_layout)
            
            # Prepare chart data
            chart_data = CategoryChartData()
            
            # Get categories from X-axis column
            x_idx = csv_headers.index(spec.x_axis_column) if spec.x_axis_column in csv_headers else 0
            categories = [row[x_idx] if x_idx < len(row) else '' for row in csv_rows]
            chart_data.categories = categories
            
            print(f"DEBUG: Categories = {categories}")
            
            # Get values from Y-axis columns
            colors_applied = []
            
            # For pie charts, we need ONE series with all values
            # The categories (slices) each get a different color
            if spec.chart_type == 'pie':
                # For pie chart: use first y_axis_column only
                y_col = spec.y_axis_columns[0] if spec.y_axis_columns else csv_headers[1] if len(csv_headers) > 1 else csv_headers[0]
                if y_col in csv_headers:
                    y_idx = csv_headers.index(y_col)
                    values = []
                    for row in csv_rows:
                        if y_idx < len(row):
                            try:
                                val = float(str(row[y_idx]).replace(',', '').replace('$', '').replace('%', ''))
                            except (ValueError, AttributeError):
                                val = 0
                            values.append(val)
                        else:
                            values.append(0)
                    
                    print(f"DEBUG: Pie chart values = {values}")
                    chart_data.add_series(y_col, values)
                    # Each slice (category) gets a different color
                    for i in range(len(categories)):
                        colors_applied.append(BTS_COLOR_NAMES[i % len(BTS_COLOR_NAMES)])
            else:
                # For bar/line/area charts: multiple series
                for i, y_col in enumerate(spec.y_axis_columns):
                    if y_col not in csv_headers:
                        continue
                        
                    y_idx = csv_headers.index(y_col)
                    values = []
                    for row in csv_rows:
                        if y_idx < len(row):
                            try:
                                val = float(str(row[y_idx]).replace(',', '').replace('$', '').replace('%', ''))
                            except (ValueError, AttributeError):
                                val = 0
                            values.append(val)
                        else:
                            values.append(0)
                    
                    series_name = spec.series_names[i] if spec.series_names and i < len(spec.series_names) else y_col
                    chart_data.add_series(series_name, values)
                    colors_applied.append(BTS_COLOR_NAMES[i % len(BTS_COLOR_NAMES)])
            
            # Map chart type to PowerPoint enum
            chart_type_map = {
                'bar': XL_CHART_TYPE.COLUMN_CLUSTERED,
                'column': XL_CHART_TYPE.COLUMN_CLUSTERED,
                'line': XL_CHART_TYPE.LINE,
                'pie': XL_CHART_TYPE.PIE,
                'area': XL_CHART_TYPE.AREA,
            }
            
            # DEBUG: Log the chart type being used
            print(f"DEBUG: spec.chart_type = {spec.chart_type}")
            print(f"DEBUG: Using XL_CHART_TYPE = {chart_type_map.get(spec.chart_type, 'COLUMN_CLUSTERED')}")
            
            xl_chart_type = chart_type_map.get(spec.chart_type, XL_CHART_TYPE.COLUMN_CLUSTERED)
            
            # Add chart to slide
            x, y, cx, cy = Inches(1), Inches(1.5), Inches(11.333), Inches(5.5)
            chart = slide.shapes.add_chart(
                xl_chart_type, x, y, cx, cy, chart_data
            ).chart
            
            # Set chart title
            if chart.has_title:
                chart.chart_title.has_text_frame = True
                chart.chart_title.text_frame.paragraphs[0].text = spec.title
                chart.chart_title.text_frame.paragraphs[0].font.size = Pt(24)
                chart.chart_title.text_frame.paragraphs[0].font.bold = True
                chart.chart_title.text_frame.paragraphs[0].font.color.rgb = BTS_COLORS[0]
            
            # Apply BTS colors
            if spec.chart_type == 'pie':
                # For pie charts: each point (slice) gets a different color
                for series in chart.series:
                    if hasattr(series, 'points'):
                        for i, point in enumerate(series.points):
                            color = BTS_COLORS[i % len(BTS_COLORS)]
                            if hasattr(point, 'format') and point.format:
                                point.format.fill.solid()
                                point.format.fill.fore_color.rgb = color
            else:
                # For bar/line/area: each series gets a different color
                for i, series in enumerate(chart.series):
                    color = BTS_COLORS[i % len(BTS_COLORS)]
                    if hasattr(series, 'format') and series.format:
                        series.format.fill.solid()
                        series.format.fill.fore_color.rgb = color
            
            # Set legend position
            if chart.has_legend:
                legend_map = {
                    'bottom': XL_LEGEND_POSITION.BOTTOM,
                    'right': XL_LEGEND_POSITION.RIGHT,
                    'top': XL_LEGEND_POSITION.TOP,
                    'left': XL_LEGEND_POSITION.LEFT,
                }
                chart.legend.position = legend_map.get(spec.legend_position, XL_LEGEND_POSITION.BOTTOM)
                chart.legend.include_in_layout = False
            
            # Save presentation
            output_path = self.output_dir / output_filename
            prs.save(str(output_path))
            
            return AIChartResult(
                success=True,
                message=f"Generated {spec.chart_type} chart: {spec.title}",
                chart_spec=spec,
                download_url=f"/download/{output_filename}",
                errors=errors
            )
            
        except Exception as e:
            errors.append(str(e))
            return AIChartResult(
                success=False,
                message=f"Failed to generate chart: {str(e)}",
                errors=errors
            )


# Convenience function
def generate_ai_chart(
    csv_headers: List[str],
    csv_rows: List[List[str]],
    user_prompt: str,
    output_dir: str = "output"
) -> AIChartResult:
    """Generate chart from CSV data using AI."""
    generator = AIChartGenerator(output_dir=output_dir)
    import uuid
    filename = f"ai_chart_{uuid.uuid4().hex[:8]}.pptx"
    return generator.generate_chart(csv_headers, csv_rows, user_prompt, filename)
