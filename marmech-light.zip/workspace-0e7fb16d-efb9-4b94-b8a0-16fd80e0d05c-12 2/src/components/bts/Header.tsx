'use client';

import React from 'react';
import { BTSLogo } from './BTSLogo';
import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';

interface HeaderProps {
  className?: string;
  onDocumentationClick?: () => void;
}

export function Header({ className = '', onDocumentationClick }: HeaderProps) {
  return (
    <header
      className={`sticky top-0 z-50 w-full border-b border-gray-100 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/80 ${className}`}
    >
      <div className="container mx-auto flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo - Left aligned */}
        <div className="flex items-center">
          <a href="/" className="flex items-center transition-opacity hover:opacity-80">
            <BTSLogo size="md" showText={true} />
          </a>
        </div>

        {/* Navigation - Center (optional for future use) */}
        <nav className="hidden md:flex items-center space-x-8">
          {/* Future navigation items can go here */}
        </nav>

        {/* Actions - Right aligned */}
        <div className="flex items-center space-x-4">
          <Button
            className="text-sm font-medium text-white transition-all hover:opacity-90"
            style={{ backgroundColor: 'var(--bts-navy)' }}
            onClick={onDocumentationClick}
          >
            <FileText className="mr-2 h-4 w-4" />
            Documentation
          </Button>
        </div>
      </div>
    </header>
  );
}

export default Header;
