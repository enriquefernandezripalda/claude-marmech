import { NextRequest, NextResponse } from 'next/server';

const SLIDE_SERVICE_URL = 'http://localhost:3002';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const response = await fetch(`${SLIDE_SERVICE_URL}/charts/ai-generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();

    if (!response.ok) {
      return NextResponse.json(
        { success: false, message: data.detail || 'Failed to generate AI chart', errors: [data.detail] },
        { status: response.status }
      );
    }

    return NextResponse.json(data);
  } catch (error) {
    console.error('AI chart generation error:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to connect to chart generator service', errors: [String(error)] },
      { status: 500 }
    );
  }
}
