"""
BTS MarTech Slide Generator API
================================

FastAPI service for generating BTS-branded PowerPoint presentations.
This service exposes the slide_generator module via REST API.
Includes image generation and aspect-ratio-preserving image injection.

Port: 3002
"""

import os
import io
import uuid
import tempfile
import shutil
import base64
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
from pathlib import Path

from fastapi import FastAPI, HTTPException, UploadFile, File, Form, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from PIL import Image

from slide_generator import (
    BTSSlideGenerator,
    BTSImageSlideGenerator,
    SlideContent,
    InjectionResult,
    SlideGeneratorError,
    TemplateNotFoundError,
    PlaceholderNotFoundError,
    InvalidSlideIndexError,
    create_bts_master_template
)

from chart_generator import (
    BTSChartGenerator,
    ChartData,
    ChartDataSeries,
    ChartGenerationResult,
    BTS_COLOR_NAMES
)

from orchestrator import (
    BTSPresentationOrchestrator,
    PresentationPayload,
    SlidePayload,
    SlideContentPayload,
    ImageInjectionPayload,
    ChartGenerationPayload,
    OrchestratorResult,
    get_orchestrator
)

# Configuration
SERVICE_PORT = 3002
TEMPLATES_DIR = Path("templates")
OUTPUT_DIR = Path("output")
IMAGES_DIR = Path("images")

# Ensure directories exist
TEMPLATES_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)
IMAGES_DIR.mkdir(exist_ok=True)

# FastAPI app
app = FastAPI(
    title="BTS MarTech Slide Generator API",
    description="API for generating BTS-branded PowerPoint presentations. Complete orchestration of text injection, image handling, and chart generation.",
    version="3.1.0"
)

# CORS configuration for Next.js frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict this
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Store active generators (cache loaded templates)
_generators: Dict[str, Union[BTSSlideGenerator, BTSImageSlideGenerator]] = {}
_use_image_generator = True  # Flag to use image-capable generator


# Pydantic Models for API
class TextStyleRequest(BaseModel):
    """Request model for text styling."""
    fontFamily: Optional[str] = Field('Arial', description="Font family")
    fontSize: Optional[int] = Field(18, description="Font size in points")
    bold: Optional[bool] = Field(False, description="Bold style")
    italic: Optional[bool] = Field(False, description="Italic style")
    color: Optional[str] = Field('#0A1A5F', description="Text color as hex")
    useOriginalStyle: Optional[bool] = Field(True, description="Preserve original template style")


class StyledTextContent(BaseModel):
    """Request model for styled text content."""
    text: str = Field(..., description="The text content")
    style: Optional[TextStyleRequest] = Field(None, description="Optional styling")


class SlideContentRequest(BaseModel):
    """Request model for slide content."""
    title: Optional[Union[str, StyledTextContent]] = Field(None, description="Title text for the slide (string or styled object)")
    subtitle: Optional[Union[str, StyledTextContent]] = Field(None, description="Subtitle text for the slide (string or styled object)")
    body_paragraphs: Optional[List[str]] = Field(None, description="List of body paragraphs")
    body: Optional[Union[str, StyledTextContent]] = Field(None, description="Body text (string or styled object)")
    custom_placeholders: Optional[Dict[str, Union[str, StyledTextContent]]] = Field(None, description="Custom placeholder index to text mapping")


class GenerateRequest(BaseModel):
    """Request model for generating a presentation."""
    template_id: str = Field(..., description="ID of the template to use")
    slide_index: int = Field(0, ge=0, description="Zero-based slide index to modify")
    content: SlideContentRequest = Field(..., description="Content to inject")
    use_ai_generation: Optional[bool] = Field(False, description="Whether to use AI text generation")
    global_prompt: Optional[str] = Field(None, description="Global prompt for AI text generation")
    placeholder_styles: Optional[Dict[str, Any]] = Field(None, description="Styles per placeholder idx")


class GenerateResponse(BaseModel):
    """Response model for generation result."""
    success: bool
    message: str
    modified_placeholders: List[str]
    errors: List[str]
    download_url: Optional[str] = None
    file_id: Optional[str] = None


class ImageGenerateRequest(BaseModel):
    """Request model for AI image generation."""
    prompt: str = Field(..., description="Text prompt for image generation")
    size: Optional[str] = Field("1024x1024", description="Image size (e.g., '1024x1024', '1344x768')")


class ImageGenerateResponse(BaseModel):
    """Response model for image generation."""
    success: bool
    message: str
    image_url: Optional[str] = None
    image_id: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None


class ImageInjectRequest(BaseModel):
    """Request model for injecting an image into a placeholder."""
    template_id: str = Field(..., description="ID of the template")
    slide_index: int = Field(0, ge=0, description="Slide index")
    placeholder_idx: int = Field(..., description="Picture placeholder index")
    image_id: Optional[str] = Field(None, description="ID of previously generated image")
    image_base64: Optional[str] = Field(None, description="Base64 encoded image data")


class ImageInjectResponse(BaseModel):
    """Response model for image injection."""
    success: bool
    message: str
    placeholder_idx: int
    original_dimensions: Optional[List[int]] = None
    cropped_dimensions: Optional[List[int]] = None
    placeholder_dimensions: Optional[List[int]] = None
    errors: List[str] = []
    download_url: Optional[str] = None


class TemplateInfo(BaseModel):
    """Information about a template."""
    id: str
    name: str
    path: str
    slide_count: int
    created_at: Optional[str] = None


class PlaceholdersResponse(BaseModel):
    """Response model for placeholder information."""
    slide_index: int
    placeholders: Dict[str, Any]


# Chart Generation Models
class ChartSeriesRequest(BaseModel):
    """Request model for chart data series."""
    name: str = Field(..., description="Series name")
    values: List[float] = Field(..., description="Series values")


class ChartDataRequest(BaseModel):
    """Request model for chart data."""
    labels: List[str] = Field(..., description="X-axis labels")
    series: List[ChartSeriesRequest] = Field(..., description="Data series")


class ChartGenerateRequest(BaseModel):
    """Request model for chart generation."""
    template_id: str = Field(..., description="ID of the template")
    slide_index: int = Field(0, ge=0, description="Target slide index")
    chart_type: str = Field("bar", description="Chart type: bar, line, pie, column, area")
    chart_title: Optional[str] = Field(None, description="Chart title")
    chart_data: ChartDataRequest = Field(..., description="Chart data")


class ChartGenerateResponse(BaseModel):
    """Response model for chart generation."""
    success: bool
    message: str
    chart_type: str
    series_count: int
    colors_applied: List[str]
    errors: List[str] = []
    download_url: Optional[str] = None


# Store chart generators (cache)
_chart_generators: Dict[str, BTSChartGenerator] = {}


# API Endpoints

@app.get("/")
async def root():
    """Health check endpoint."""
    return {
        "service": "BTS MarTech Slide Generator",
        "status": "healthy",
        "version": "3.2.0",
        "features": [
            "text_injection",
            "image_generation",
            "image_injection",
            "chart_generation",
            "template_management",
            "orchestration",
            "ai_text_generation"
        ]
    }


@app.get("/templates", response_model=List[TemplateInfo])
async def list_templates():
    """
    List all available templates.
    
    Returns a list of template metadata including IDs, names, and slide counts.
    """
    templates = []
    
    # Scan templates directory
    for template_file in TEMPLATES_DIR.glob("*.pptx"):
        template_id = template_file.stem
        try:
            generator = _get_or_create_generator(str(template_file))
            templates.append(TemplateInfo(
                id=template_id,
                name=template_file.name,
                path=str(template_file),
                slide_count=generator.get_slide_count(),
                created_at=datetime.fromtimestamp(template_file.stat().st_mtime).isoformat()
            ))
        except Exception as e:
            print(f"Error loading template {template_file}: {e}")
    
    return templates


@app.post("/templates/upload")
async def upload_template(
    file: UploadFile = File(...),
    name: Optional[str] = Form(None)
):
    """
    Upload a new PowerPoint template.
    
    The template will be stored and made available for generation.
    """
    if not file.filename.endswith('.pptx'):
        raise HTTPException(
            status_code=400,
            detail="Invalid file format. Only .pptx files are accepted."
        )
    
    # Generate unique filename
    template_name = name or Path(file.filename).stem
    template_id = f"{template_name}_{uuid.uuid4().hex[:8]}"
    template_path = TEMPLATES_DIR / f"{template_id}.pptx"
    
    # Save uploaded file
    try:
        with open(template_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to save template: {str(e)}"
        )
    
    # Validate template
    try:
        generator = BTSSlideGenerator(str(template_path))
        slide_count = generator.get_slide_count()
    except Exception as e:
        # Clean up invalid template
        os.remove(template_path)
        raise HTTPException(
            status_code=400,
            detail=f"Invalid PowerPoint template: {str(e)}"
        )
    
    return {
        "success": True,
        "template_id": template_id,
        "name": template_name,
        "slide_count": slide_count,
        "message": f"Template uploaded successfully with {slide_count} slides"
    }


@app.get("/templates/default", response_model=TemplateInfo)
async def get_or_create_default_template():
    """
    Get or create the default BTS master template.
    
    If the default template doesn't exist, it will be created.
    """
    template_path = TEMPLATES_DIR / "bts_master_template.pptx"
    
    if not template_path.exists():
        create_bts_master_template(str(template_path))
    
    generator = _get_or_create_generator(str(template_path))
    
    return TemplateInfo(
        id="bts_master_template",
        name="BTS Master Template",
        path=str(template_path),
        slide_count=generator.get_slide_count()
    )


@app.get("/templates/{template_id}/slides/{slide_index}/placeholders", response_model=PlaceholdersResponse)
async def get_slide_placeholders(template_id: str, slide_index: int):
    """
    Get all placeholders on a specific slide.
    
    Returns placeholder indices, types, dimensions, and current content.
    Includes both text and picture placeholders.
    """
    template_path = TEMPLATES_DIR / f"{template_id}.pptx"
    
    if not template_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Template not found: {template_id}"
        )
    
    try:
        generator = _get_or_create_generator(str(template_path), use_image=True)
        placeholders = generator.get_all_placeholders(slide_index)
        
        # Convert to serializable format
        serializable_placeholders = {}
        for idx, info in placeholders.items():
            ph_data = {
                'type': info.get('type', 'unknown'),
                'name': info.get('name', ''),
                'current_text': info.get('current_text', '')
            }
            
            # Add dimension info for picture placeholders
            if info.get('type') == 'picture':
                width_emu = info.get('width_emu')
                height_emu = info.get('height_emu')
                if width_emu and height_emu:
                    # Convert EMU to inches for readability
                    emu_per_inch = 914400
                    ph_data['width_inches'] = width_emu / emu_per_inch
                    ph_data['height_inches'] = height_emu / emu_per_inch
                    ph_data['aspect_ratio'] = float(width_emu) / float(height_emu)
            
            serializable_placeholders[str(idx)] = ph_data
        
        return PlaceholdersResponse(
            slide_index=slide_index,
            placeholders=serializable_placeholders
        )
    except InvalidSlideIndexError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/templates/{template_id}/slides/{slide_index}/picture-placeholders")
async def get_picture_placeholders(template_id: str, slide_index: int):
    """
    Get only picture placeholders on a specific slide.
    
    Returns placeholder indices and their dimensions for image injection.
    """
    template_path = TEMPLATES_DIR / f"{template_id}.pptx"
    
    if not template_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Template not found: {template_id}"
        )
    
    try:
        generator = _get_or_create_generator(str(template_path), use_image=True)
        placeholders = generator.get_picture_placeholders(slide_index)
        
        # Convert to serializable format
        serializable_placeholders = {}
        for idx, info in placeholders.items():
            width_emu = info.get('width_emu')
            height_emu = info.get('height_emu')
            emu_per_inch = 914400
            
            serializable_placeholders[str(idx)] = {
                'name': info.get('name', ''),
                'width_emu': int(width_emu) if width_emu else 0,
                'height_emu': int(height_emu) if height_emu else 0,
                'width_inches': width_emu / emu_per_inch if width_emu else 0,
                'height_inches': height_emu / emu_per_inch if height_emu else 0,
                'aspect_ratio': info.get('aspect_ratio', {}).get('ratio', 1.0) if info.get('aspect_ratio') else 1.0
            }
        
        return {
            "slide_index": slide_index,
            "picture_placeholders": serializable_placeholders
        }
    except InvalidSlideIndexError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/generate", response_model=GenerateResponse)
async def generate_presentation(request: GenerateRequest):
    """
    Generate a presentation by injecting content into a template.
    
    This is the main endpoint for slide generation. It:
    1. Loads the specified template
    2. If use_ai_generation is true, uses MLX to generate text
    3. Injects the content while preserving ALL formatting
    4. Returns a download URL for the generated file
    
    CRITICAL: This method preserves the BTS brand styling by using
    style-preserving text injection at the run/paragraph level.
    """
    template_path = TEMPLATES_DIR / f"{request.template_id}.pptx"
    
    if not template_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Template not found: {request.template_id}"
        )
    
    try:
        # Get or create generator - always use image-capable generator for full placeholder support
        generator = _get_or_create_generator(str(template_path), use_image=True)
        
        # Generate output filename
        file_id = uuid.uuid4().hex
        output_filename = f"generated_{file_id}.pptx"
        output_path = OUTPUT_DIR / output_filename
        
        # Helper functions for extracting content
        def extract_text(item):
            """Extract text from string or StyledTextContent."""
            if isinstance(item, str):
                return item
            elif isinstance(item, StyledTextContent):
                return item.text
            return None
        
        def extract_style(item, check_preserve_original=False):
            """Extract style dict from StyledTextContent or None.
            
            If check_preserve_original is True and useOriginalStyle is True,
            returns None to preserve the original template style.
            """
            if isinstance(item, StyledTextContent) and item.style:
                # If user wants to preserve original style, return None
                if check_preserve_original and item.style.useOriginalStyle:
                    return None
                return {
                    'fontFamily': item.style.fontFamily,
                    'fontSize': item.style.fontSize,
                    'bold': item.style.bold,
                    'italic': item.style.italic,
                    'color': item.style.color,  # Include color field
                    'useOriginalStyle': item.style.useOriginalStyle
                }
            return None
        
        # Check if AI generation is requested
        if request.use_ai_generation and request.global_prompt:
            # Import AI generator
            try:
                from mlx_generator import MLXTextGenerator
                
                mlx_gen = MLXTextGenerator()
                
                # Get total slide count
                total_slides = generator.get_slide_count()
                
                # Process ALL slides
                all_modified = []
                all_errors = []
                
                for slide_idx in range(total_slides):
                    # Get placeholder info for this slide
                    placeholder_info = generator.get_all_placeholders(slide_idx)
                    
                    # Filter out picture placeholders for text generation
                    text_placeholders = {}
                    for idx, info in placeholder_info.items():
                        if info.get('type') != 'picture':
                            text_placeholders[str(idx)] = info
                    
                    if not text_placeholders:
                        continue  # Skip slides with no text placeholders
                    
                    # Determine slide context
                    slide_layout = "Content Slide"
                    if slide_idx == 0:
                        slide_layout = "Title Slide (opening slide)"
                    elif slide_idx == total_slides - 1:
                        slide_layout = "Closing Slide (final slide)"
                    
                    slide_context = f"Slide {slide_idx + 1} of {total_slides} - {slide_layout}"
                    
                    # Generate content for this slide
                    generated = mlx_gen.generate_content_for_slide(
                        user_prompt=request.global_prompt,
                        placeholder_info=text_placeholders,
                        placeholder_styles=request.placeholder_styles,
                        slide_context=slide_context
                    )
                    
                    # Build styles for this slide
                    # IMPORTANT: If useOriginalStyle is True, set style to None to preserve template formatting
                    title_style = None
                    subtitle_style = None
                    body_style = None
                    
                    if request.placeholder_styles:
                        for idx, info in placeholder_info.items():
                            style = request.placeholder_styles.get(str(idx))
                            if style:
                                # Check if user wants to preserve original template style
                                if style.get('useOriginalStyle', False):
                                    # Don't apply any custom style - preserve template formatting
                                    continue
                                
                                if info.get('type') in ['title', 'center_title']:
                                    title_style = style
                                elif info.get('type') == 'subtitle':
                                    subtitle_style = style
                                elif info.get('type') == 'body':
                                    body_style = style
                    
                    # Build content object
                    content = SlideContent(
                        title=generated.title,
                        title_style=title_style,
                        subtitle=generated.subtitle,
                        subtitle_style=subtitle_style,
                        body=generated.body,
                        body_style=body_style,
                        custom_placeholders=None
                    )
                    
                    # Handle custom placeholders
                    if generated.custom_placeholders:
                        custom_ph_dict = {}
                        for idx, text in generated.custom_placeholders.items():
                            style = request.placeholder_styles.get(str(idx)) if request.placeholder_styles else None
                            # If useOriginalStyle is True, don't apply custom style
                            if style and style.get('useOriginalStyle', False):
                                style = None
                            custom_ph_dict[int(idx)] = {'text': text, 'style': style}
                        content.custom_placeholders = custom_ph_dict
                    
                    # Generate this slide
                    slide_result = generator.generate(
                        slide_index=slide_idx,
                        content=content,
                        output_path=str(output_path) if slide_idx == 0 else None  # Only save on first, then modify
                    )
                    
                    if slide_result.success:
                        all_modified.extend([f"Slide {slide_idx + 1}: {ph}" for ph in slide_result.modified_placeholders])
                    all_errors.extend([f"Slide {slide_idx + 1}: {err}" for err in slide_result.errors])
                
                # Final save after all slides
                if hasattr(generator, '_presentation') and generator._presentation:
                    generator._presentation.save(str(output_path))
                
                success = len(all_modified) > 0
                
                return GenerateResponse(
                    success=success,
                    message=f"Generated content for {total_slides} slides, modified {len(all_modified)} placeholders" if success else "No placeholders modified",
                    modified_placeholders=all_modified,
                    errors=all_errors,
                    download_url=f"/download/{output_filename}" if success else None,
                    file_id=file_id if success else None
                )
                
            except ImportError as e:
                # Fallback to manual content if MLX not available
                print(f"MLX not available: {e}")
                # Process manual content
                custom_ph_dict = None
                if request.content.custom_placeholders:
                    custom_ph_dict = {}
                    for idx, value in request.content.custom_placeholders.items():
                        if isinstance(value, str):
                            custom_ph_dict[int(idx)] = {'text': value, 'style': None}
                        elif isinstance(value, StyledTextContent):
                            custom_ph_dict[int(idx)] = {'text': value.text, 'style': extract_style(value)}
                
                content = SlideContent(
                    title=extract_text(request.content.title),
                    title_style=extract_style(request.content.title) or (request.placeholder_styles.get('title') if request.placeholder_styles else None),
                    subtitle=extract_text(request.content.subtitle),
                    subtitle_style=extract_style(request.content.subtitle) or (request.placeholder_styles.get('subtitle') if request.placeholder_styles else None),
                    body_paragraphs=request.content.body_paragraphs,
                    body=extract_text(request.content.body),
                    body_style=extract_style(request.content.body) or (request.placeholder_styles.get('body') if request.placeholder_styles else None),
                    custom_placeholders=custom_ph_dict
                )
        else:
            # Manual content mode - use provided text
            custom_ph_dict = None
            if request.content.custom_placeholders:
                custom_ph_dict = {}
                for idx, value in request.content.custom_placeholders.items():
                    if isinstance(value, str):
                        custom_ph_dict[int(idx)] = {'text': value, 'style': None}
                    elif isinstance(value, StyledTextContent):
                        custom_ph_dict[int(idx)] = {'text': value.text, 'style': extract_style(value)}
            
            # Get styles from placeholder_styles if available, otherwise from content
            title_style = extract_style(request.content.title)
            if not title_style and request.placeholder_styles:
                # Find title placeholder idx
                placeholder_info = generator.get_all_placeholders(request.slide_index)
                for idx, info in placeholder_info.items():
                    if info.get('type') in ['title', 'center_title']:
                        title_style = request.placeholder_styles.get(str(idx))
                        break
            
            subtitle_style = extract_style(request.content.subtitle)
            if not subtitle_style and request.placeholder_styles:
                placeholder_info = generator.get_all_placeholders(request.slide_index)
                for idx, info in placeholder_info.items():
                    if info.get('type') == 'subtitle':
                        subtitle_style = request.placeholder_styles.get(str(idx))
                        break
            
            body_style = extract_style(request.content.body)
            if not body_style and request.placeholder_styles:
                placeholder_info = generator.get_all_placeholders(request.slide_index)
                for idx, info in placeholder_info.items():
                    if info.get('type') == 'body':
                        body_style = request.placeholder_styles.get(str(idx))
                        break
            
            content = SlideContent(
                title=extract_text(request.content.title),
                title_style=title_style,
                subtitle=extract_text(request.content.subtitle),
                subtitle_style=subtitle_style,
                body_paragraphs=request.content.body_paragraphs,
                body=extract_text(request.content.body),
                body_style=body_style,
                custom_placeholders=custom_ph_dict
            )
        
        # Generate presentation
        result = generator.generate(
            slide_index=request.slide_index,
            content=content,
            output_path=str(output_path)
        )
        
        return GenerateResponse(
            success=result.success,
            message=result.message,
            modified_placeholders=result.modified_placeholders,
            errors=result.errors,
            download_url=f"/download/{output_filename}" if result.success else None,
            file_id=file_id if result.success else None
        )
        
    except InvalidSlideIndexError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except SlideGeneratorError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")


@app.post("/images/generate", response_model=ImageGenerateResponse)
async def generate_image(request: ImageGenerateRequest):
    """
    Generate an AI image from a text prompt.
    
    This endpoint calls the z-ai image generation API to create images.
    The generated image is saved locally and can be used for slide injection.
    
    Supported sizes:
    - 1024x1024 (square)
    - 1344x768 (landscape)
    - 768x1344 (portrait)
    - 1440x720 (wide landscape)
    """
    # Image generation is done via the CLI tool in the generate-sdk endpoint
    # This endpoint redirects to that implementation
    raise HTTPException(
        status_code=400,
        detail="Use /images/generate-sdk endpoint for image generation"
    )


@app.post("/images/generate-sdk")
async def generate_image_sdk(request: ImageGenerateRequest):
    """
    Generate an AI image using Node.js SDK via subprocess.
    
    This endpoint uses the z-ai CLI tool for image generation.
    """
    try:
        import subprocess
        import json
        
        # Validate size
        supported_sizes = ['1024x1024', '1344x768', '768x1344', '1440x720', 
                          '1152x864', '864x1152', '720x1440']
        if request.size not in supported_sizes:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported size. Use one of: {', '.join(supported_sizes)}"
            )
        
        # Generate unique ID
        image_id = uuid.uuid4().hex
        image_filename = f"generated_{image_id}.png"
        image_path = IMAGES_DIR / image_filename
        
        # Use z-ai CLI
        result = subprocess.run(
            ['z-ai', 'image', '-p', request.prompt, '-o', str(image_path), '-s', request.size],
            capture_output=True,
            text=True,
            timeout=120
        )
        
        if result.returncode != 0:
            # Create placeholder on failure
            size_parts = request.size.split('x')
            width, height = int(size_parts[0]), int(size_parts[1])
            img = Image.new('RGB', (width, height), color=(10, 26, 95))
            img.save(image_path)
            
            return {
                "success": True,
                "message": "Placeholder image created (generation failed)",
                "image_url": f"/images/{image_filename}",
                "image_id": image_id,
                "width": width,
                "height": height,
                "error": result.stderr
            }
        
        # Get dimensions
        img = Image.open(image_path)
        width, height = img.size
        
        return {
            "success": True,
            "message": "Image generated successfully",
            "image_url": f"/images/{image_filename}",
            "image_id": image_id,
            "width": width,
            "height": height
        }
        
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=504, detail="Image generation timeout")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate image: {str(e)}")


@app.post("/images/upload")
async def upload_image(file: UploadFile = File(...)):
    """
    Upload an image for later use in slide injection.
    
    Accepts PNG, JPEG, and WebP formats.
    """
    if not file.filename.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
        raise HTTPException(
            status_code=400,
            detail="Invalid image format. Accepted: PNG, JPEG, WebP"
        )
    
    image_id = uuid.uuid4().hex
    ext = Path(file.filename).suffix
    image_filename = f"uploaded_{image_id}{ext}"
    image_path = IMAGES_DIR / image_filename
    
    try:
        # Save uploaded image
        content = await file.read()
        with open(image_path, 'wb') as f:
            f.write(content)
        
        # Get dimensions
        img = Image.open(io.BytesIO(content))
        width, height = img.size
        
        return {
            "success": True,
            "message": "Image uploaded successfully",
            "image_url": f"/images/{image_filename}",
            "image_id": image_id,
            "width": width,
            "height": height
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to upload image: {str(e)}")


@app.post("/slides/inject-image", response_model=ImageInjectResponse)
async def inject_image_to_slide(request: ImageInjectRequest):
    """
    Inject an image into a picture placeholder with aspect ratio preservation.
    
    CRITICAL: Images are NEVER distorted. They are center-cropped to match
    the placeholder's aspect ratio exactly.
    
    The process:
    1. Load the image (from ID, base64, or URL)
    2. Read placeholder dimensions from template
    3. Calculate center-crop to match aspect ratio
    4. Insert cropped image into placeholder
    
    Either image_id or image_base64 must be provided.
    """
    template_path = TEMPLATES_DIR / f"{request.template_id}.pptx"
    
    if not template_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Template not found: {request.template_id}"
        )
    
    # Get image source
    image_source = None
    if request.image_id:
        # Find image by ID
        for img_file in IMAGES_DIR.glob(f"*{request.image_id}*"):
            image_source = str(img_file)
            break
        if not image_source:
            raise HTTPException(
                status_code=404,
                detail=f"Image not found: {request.image_id}"
            )
    elif request.image_base64:
        # Decode base64 image
        try:
            # Remove data URL prefix if present
            base64_data = request.image_base64
            if ',' in base64_data:
                base64_data = base64_data.split(',')[1]
            
            image_source = base64.b64decode(base64_data)
        except Exception as e:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid base64 image data: {str(e)}"
            )
    else:
        raise HTTPException(
            status_code=400,
            detail="Either image_id or image_base64 must be provided"
        )
    
    try:
        # Get image-capable generator
        generator = _get_or_create_generator(str(template_path), use_image=True)
        
        # Generate output filename
        file_id = uuid.uuid4().hex
        output_filename = f"with_image_{file_id}.pptx"
        output_path = OUTPUT_DIR / output_filename
        
        # Inject image
        result = generator.inject_image(
            slide_index=request.slide_index,
            placeholder_idx=request.placeholder_idx,
            image_source=image_source,
            output_path=str(output_path)
        )
        
        return ImageInjectResponse(
            success=result.success,
            message=result.message,
            placeholder_idx=result.placeholder_idx or request.placeholder_idx,
            original_dimensions=list(result.original_dimensions) if result.original_dimensions else None,
            cropped_dimensions=list(result.cropped_dimensions) if result.cropped_dimensions else None,
            placeholder_dimensions=list(result.placeholder_dimensions) if result.placeholder_dimensions else None,
            errors=result.errors,
            download_url=f"/download/{output_filename}" if result.success else None
        )
        
    except InvalidSlideIndexError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to inject image: {str(e)}")


@app.post("/generate/simple")
async def generate_simple(
    template_id: str = Form(...),
    slide_index: int = Form(0),
    title: Optional[str] = Form(None),
    subtitle: Optional[str] = Form(None),
    body: Optional[str] = Form(None)
):
    """
    Simplified generation endpoint for basic use cases.
    
    Accepts form data and generates a presentation.
    """
    content = SlideContentRequest(
        title=title,
        subtitle=subtitle,
        body_paragraphs=[body] if body else None
    )
    
    request = GenerateRequest(
        template_id=template_id,
        slide_index=slide_index,
        content=content
    )
    
    return await generate_presentation(request)


@app.get("/download/{filename}")
async def download_presentation(filename: str):
    """
    Download a generated presentation.
    
    Returns the .pptx file as a downloadable attachment.
    """
    file_path = OUTPUT_DIR / filename
    
    if not file_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"File not found: {filename}"
        )
    
    return FileResponse(
        path=file_path,
        media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        filename=filename
    )


@app.get("/images/{filename}")
async def get_image(filename: str):
    """
    Get a generated or uploaded image.
    """
    file_path = IMAGES_DIR / filename
    
    if not file_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Image not found: {filename}"
        )
    
    return FileResponse(
        path=file_path,
        media_type="image/png" if filename.endswith('.png') else "image/jpeg"
    )


@app.delete("/files/{file_id}")
async def delete_generated_file(file_id: str):
    """Delete a generated file to clean up storage."""
    # Find and delete files matching the ID
    deleted = []
    for file_path in OUTPUT_DIR.glob(f"*{file_id}*"):
        try:
            os.remove(file_path)
            deleted.append(file_path.name)
        except Exception as e:
            print(f"Error deleting {file_path}: {e}")
    
    return {
        "success": len(deleted) > 0,
        "deleted": deleted
    }


# =============================================================================
# Chart Generation Endpoints
# =============================================================================

@app.post("/charts/generate", response_model=ChartGenerateResponse)
async def generate_chart(request: ChartGenerateRequest):
    """
    Generate a native PowerPoint chart with BTS brand colors.
    
    CRITICAL: All charts use BTS brand colors exclusively.
    Default MS Office theme colors are STRIPPED and replaced.
    
    Supported chart types: bar, line, pie, column, area
    
    The chart is generated natively using ChartData, allowing the 
    marketing team to right-click and "Edit Data" in PowerPoint.
    """
    template_path = TEMPLATES_DIR / f"{request.template_id}.pptx"
    
    if not template_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Template not found: {request.template_id}"
        )
    
    try:
        # Get or create chart generator
        generator = _get_or_create_chart_generator(str(template_path))
        
        # Generate output filename
        file_id = uuid.uuid4().hex
        output_filename = f"chart_{file_id}.pptx"
        output_path = OUTPUT_DIR / output_filename
        
        # Convert request data to ChartData
        chart_data = ChartData(
            labels=request.chart_data.labels,
            series=[
                ChartDataSeries(name=s.name, values=s.values)
                for s in request.chart_data.series
            ]
        )
        
        # Generate chart
        result = generator.generate_chart(
            slide_index=request.slide_index,
            chart_type=request.chart_type,
            chart_data=chart_data,
            chart_title=request.chart_title,
            output_path=str(output_path)
        )
        
        return ChartGenerateResponse(
            success=result.success,
            message=result.message,
            chart_type=result.chart_type,
            series_count=result.series_count,
            colors_applied=result.colors_applied,
            errors=result.errors,
            download_url=f"/download/{output_filename}" if result.success else None
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate chart: {str(e)}"
        )


@app.get("/charts/colors")
async def get_chart_colors():
    """
    Get the BTS brand color palette used for charts.
    
    Returns the exact hex codes and RGB values applied to chart series.
    """
    from chart_generator import BTS_CHART_COLORS, BTS_COLOR_NAMES
    
    return {
        "colors": [
            {
                "name": BTS_COLOR_NAMES[i],
                "hex": f"#{color._rgb[0]:02X}{color._rgb[1]:02X}{color._rgb[2]:02X}",
                "rgb": [color._rgb[0], color._rgb[1], color._rgb[2]],
                "series_index": i
            }
            for i, color in enumerate(BTS_CHART_COLORS)
        ],
        "usage": "Colors are applied in rotation to chart series. Pie charts apply different colors to each slice."
    }


# AI Chart Generation Models
class AIChartRequest(BaseModel):
    """Request model for AI-powered chart generation."""
    csv_data: str = Field(..., description="Raw CSV data as string")
    csv_headers: List[str] = Field(..., description="CSV column headers")
    csv_rows: List[List[str]] = Field(..., description="CSV data rows")
    user_prompt: str = Field(..., description="User's instructions for chart creation")


class AIChartResponse(BaseModel):
    """Response model for AI chart generation."""
    success: bool
    message: str
    chart_type: Optional[str] = None
    series_count: Optional[int] = None
    colors_applied: List[str] = []
    ai_analysis: Optional[str] = None
    download_url: Optional[str] = None
    errors: List[str] = []


@app.post("/charts/ai-generate", response_model=AIChartResponse)
async def generate_ai_chart(request: AIChartRequest):
    """
    Generate a chart from CSV data using AI analysis.
    
    This endpoint:
    1. Uses AI to analyze the CSV data structure
    2. Determines the best chart type based on user prompt
    3. Creates a professional chart with BTS brand colors
    4. Returns a downloadable PPTX file
    
    The AI intelligently:
    - Identifies numeric vs categorical columns
    - Selects appropriate X and Y axes
    - Chooses the best chart type for the data
    - Creates meaningful titles and labels
    """
    try:
        from chart_generator_ai import AIChartGenerator
        
        # Generate unique filename
        file_id = uuid.uuid4().hex[:8]
        output_filename = f"ai_chart_{file_id}.pptx"
        
        # Create AI chart generator
        generator = AIChartGenerator(
            templates_dir=str(TEMPLATES_DIR),
            output_dir=str(OUTPUT_DIR)
        )
        
        # Generate chart
        result = generator.generate_chart(
            csv_headers=request.csv_headers,
            csv_rows=request.csv_rows,
            user_prompt=request.user_prompt,
            output_filename=output_filename
        )
        
        return AIChartResponse(
            success=result.success,
            message=result.message,
            chart_type=result.chart_spec.chart_type if result.chart_spec else None,
            series_count=len(result.chart_spec.y_axis_columns) if result.chart_spec else 0,
            colors_applied=[BTS_COLOR_NAMES[i % len(BTS_COLOR_NAMES)] for i in range(len(result.chart_spec.y_axis_columns))] if result.chart_spec else [],
            ai_analysis=result.chart_spec.insights if result.chart_spec else None,
            download_url=result.download_url,
            errors=result.errors
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate AI chart: {str(e)}"
        )


def _get_or_create_chart_generator(template_path: str) -> BTSChartGenerator:
    """Get cached chart generator or create new one."""
    if template_path not in _chart_generators:
        _chart_generators[template_path] = BTSChartGenerator(template_path)
    return _chart_generators[template_path]


# Helper Functions

def _get_or_create_generator(
    template_path: str, 
    use_image: bool = False
) -> Union[BTSSlideGenerator, BTSImageSlideGenerator]:
    """Get cached generator or create new one."""
    cache_key = f"{template_path}_image" if use_image else template_path
    
    if cache_key not in _generators:
        if use_image:
            _generators[cache_key] = BTSImageSlideGenerator(template_path)
        else:
            _generators[cache_key] = BTSSlideGenerator(template_path)
    
    return _generators[cache_key]


# =============================================================================
# File Validation Utilities
# =============================================================================

# Valid MIME types for PowerPoint templates
VALID_PPTX_MIME_TYPES = {
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.ms-powerpoint.presentation.macroEnabled.12',  # .pptm
    'application/zip',  # Some systems report .pptx as zip
}

# Valid MIME types for images
VALID_IMAGE_MIME_TYPES = {
    'image/jpeg',
    'image/png',
    'image/webp',
}

# Maximum file sizes (in bytes)
MAX_TEMPLATE_SIZE = 50 * 1024 * 1024  # 50MB
MAX_IMAGE_SIZE = 10 * 1024 * 1024    # 10MB


def validate_pptx_file(file: UploadFile) -> None:
    """
    Validate that uploaded file is a valid .pptx file.
    
    CRITICAL SECURITY CHECK:
    - Validates file extension
    - Validates MIME type
    - Checks file size
    
    Raises HTTPException if validation fails.
    """
    # Check extension
    if not file.filename or not file.filename.lower().endswith('.pptx'):
        raise HTTPException(
            status_code=400,
            detail="Invalid file extension. Only .pptx files are accepted as templates."
        )
    
    # Check MIME type
    content_type = file.content_type or ''
    if content_type not in VALID_PPTX_MIME_TYPES:
        # Try to detect from content
        raise HTTPException(
            status_code=400,
            detail=f"Invalid file type. Expected PowerPoint (.pptx), got {content_type}. "
                   "Only .pptx files are accepted. .ppt, .pdf, .jpg, .png are NOT allowed as templates."
        )


def validate_image_file(file: UploadFile) -> None:
    """Validate that uploaded file is a valid image."""
    # Check extension
    valid_extensions = {'.jpg', '.jpeg', '.png', '.webp'}
    if not file.filename or not any(file.filename.lower().endswith(ext) for ext in valid_extensions):
        raise HTTPException(
            status_code=400,
            detail="Invalid image format. Accepted: JPG, PNG, WebP"
        )
    
    # Check MIME type
    content_type = file.content_type or ''
    if content_type not in VALID_IMAGE_MIME_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid image type: {content_type}. Accepted: image/jpeg, image/png, image/webp"
        )


# =============================================================================
# Orchestrator Endpoints
# =============================================================================

class OrchestratorRequest(BaseModel):
    """Request model for full presentation orchestration."""
    template_id: str = Field(..., description="ID of the master template")
    output_filename: Optional[str] = Field(None, description="Custom output filename")
    slides: List[Dict[str, Any]] = Field(..., description="List of slide payloads")


class OrchestratorResponse(BaseModel):
    """Response model for orchestration result."""
    success: bool
    message: str
    slides_processed: int
    total_operations: int
    text_injections: int
    image_injections: int
    charts_generated: int
    errors: List[str] = []
    download_url: Optional[str] = None


@app.post("/orchestrate", response_model=OrchestratorResponse)
async def orchestrate_presentation(request: OrchestratorRequest):
    """
    THE MAIN ORCHESTRATION ENDPOINT.
    
    This endpoint coordinates all phases to generate a complete presentation:
    1. Loads the master template
    2. Injects text content (Phase 2)
    3. Injects images with center-crop (Phase 3)
    4. Generates charts with BTS colors (Phase 4)
    5. Returns download URL
    
    Payload structure:
    {
        "template_id": "bts_master_template",
        "slides": [
            {
                "slide_index": 0,
                "text_content": {
                    "title": "Title",
                    "subtitle": "Subtitle",
                    "body_paragraphs": ["Para 1", "Para 2"]
                },
                "images": [
                    {
                        "placeholder_idx": 15,
                        "image_id": "abc123"
                    }
                ],
                "chart": {
                    "chart_type": "bar",
                    "chart_title": "Chart Title",
                    "labels": ["Q1", "Q2"],
                    "series": [{"name": "Revenue", "values": [100, 200]}]
                }
            }
        ]
    }
    """
    try:
        orchestrator = get_orchestrator(
            template_dir=str(TEMPLATES_DIR),
            output_dir=str(OUTPUT_DIR),
            images_dir=str(IMAGES_DIR)
        )
        
        # Build payload
        payload_dict = {
            "template_id": request.template_id,
            "output_filename": request.output_filename,
            "slides": request.slides
        }
        
        # Execute orchestration
        result = orchestrator.generate_from_dict(payload_dict)
        
        # Build download URL
        download_url = None
        if result.output_path:
            output_filename = Path(result.output_path).name
            download_url = f"/download/{output_filename}"
        
        return OrchestratorResponse(
            success=result.success,
            message=result.message,
            slides_processed=result.slides_processed,
            total_operations=result.total_operations,
            text_injections=result.text_injections,
            image_injections=result.image_injections,
            charts_generated=result.charts_generated,
            errors=result.errors,
            download_url=download_url
        )
        
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Orchestration failed: {str(e)}"
        )


# =============================================================================
# Enhanced Template Management Endpoints
# =============================================================================

@app.post("/templates/upload-secure")
async def upload_template_secure(
    file: UploadFile = File(...),
    name: Optional[str] = Form(None),
    background_tasks: BackgroundTasks = None
):
    """
    Securely upload a master template with strict validation.
    
    CRITICAL SECURITY:
    - Validates .pptx extension (rejects .ppt, .pdf, images)
    - Validates MIME type
    - Validates file is actually a valid PowerPoint file
    
    Only accepts: application/vnd.openxmlformats-officedocument.presentationml.presentation
    """
    # Validate file
    validate_pptx_file(file)
    
    # Read file content
    content = await file.read()
    
    # Check size
    if len(content) > MAX_TEMPLATE_SIZE:
        raise HTTPException(
            status_code=400,
            detail=f"File too large. Maximum size is {MAX_TEMPLATE_SIZE // (1024*1024)}MB"
        )
    
    # Verify it's a valid PowerPoint file by checking magic bytes
    # PPTX files start with PK (zip signature) and contain specific content
    if not content.startswith(b'PK'):
        raise HTTPException(
            status_code=400,
            detail="Invalid file structure. The file is not a valid .pptx file."
        )
    
    # Generate unique filename
    template_name = name or Path(file.filename).stem
    template_id = f"{template_name}_{uuid.uuid4().hex[:8]}"
    template_path = TEMPLATES_DIR / f"{template_id}.pptx"
    
    # Save file
    try:
        with open(template_path, "wb") as buffer:
            buffer.write(content)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to save template: {str(e)}"
        )
    
    # Validate template can be loaded
    try:
        generator = BTSSlideGenerator(str(template_path))
        slide_count = generator.get_slide_count()
    except Exception as e:
        # Clean up invalid template
        os.remove(template_path)
        raise HTTPException(
            status_code=400,
            detail=f"Invalid PowerPoint template: {str(e)}"
        )
    
    return {
        "success": True,
        "template_id": template_id,
        "name": template_name,
        "slide_count": slide_count,
        "size_bytes": len(content),
        "message": f"Template uploaded successfully with {slide_count} slides"
    }


@app.delete("/templates/{template_id}")
async def delete_template(template_id: str):
    """Delete a template."""
    # Don't allow deleting the default template
    if template_id == 'bts_master_template':
        raise HTTPException(
            status_code=403,
            detail="Cannot delete the default template"
        )
    
    # Find and delete template
    for template_file in TEMPLATES_DIR.glob(f"*{template_id}*.pptx"):
        try:
            os.remove(template_file)
            return {
                "success": True,
                "message": f"Template {template_id} deleted"
            }
        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=f"Failed to delete template: {str(e)}"
            )
    
    raise HTTPException(
        status_code=404,
        detail=f"Template not found: {template_id}"
    )


# =============================================================================
# Image Management Endpoints
# =============================================================================

@app.get("/images/list")
async def list_images():
    """List all uploaded images."""
    images = []
    
    for img_file in IMAGES_DIR.glob("*"):
        if img_file.suffix.lower() in {'.jpg', '.jpeg', '.png', '.webp'}:
            try:
                img = Image.open(img_file)
                width, height = img.size
                img.close()
                
                images.append({
                    "id": img_file.stem.replace('uploaded_', '').replace('generated_', ''),
                    "name": img_file.name,
                    "url": f"/images/{img_file.name}",
                    "width": width,
                    "height": height,
                    "size_bytes": img_file.stat().st_size,
                    "created_at": datetime.fromtimestamp(img_file.stat().st_mtime).isoformat()
                })
            except Exception:
                continue
    
    return {"images": images}


@app.delete("/images/{image_id}")
async def delete_image(image_id: str):
    """Delete an uploaded image."""
    deleted = []
    
    for img_file in IMAGES_DIR.glob(f"*{image_id}*"):
        try:
            os.remove(img_file)
            deleted.append(img_file.name)
        except Exception as e:
            print(f"Error deleting {img_file}: {e}")
    
    if not deleted:
        raise HTTPException(
            status_code=404,
            detail=f"Image not found: {image_id}"
        )
    
    return {
        "success": True,
        "deleted": deleted
    }


# =============================================================================
# Cleanup Endpoints
# =============================================================================

@app.post("/cleanup")
async def cleanup_old_files(max_age_hours: int = 24):
    """
    Clean up old generated files.
    
    Removes output files older than specified age.
    """
    orchestrator = get_orchestrator(
        template_dir=str(TEMPLATES_DIR),
        output_dir=str(OUTPUT_DIR),
        images_dir=str(IMAGES_DIR)
    )
    
    # Run cleanup
    orchestrator.cleanup_old_outputs(max_age_hours)
    
    return {
        "success": True,
        "message": f"Cleaned up files older than {max_age_hours} hours"
    }


@app.post("/cleanup/temp")
async def cleanup_temp_files():
    """Clean up temporary files from generation process."""
    orchestrator = get_orchestrator(
        template_dir=str(TEMPLATES_DIR),
        output_dir=str(OUTPUT_DIR),
        images_dir=str(IMAGES_DIR)
    )
    
    orchestrator.cleanup_temp_files()
    
    return {
        "success": True,
        "message": "Temporary files cleaned up"
    }


# Startup event to create default template
@app.on_event("startup")
async def startup_event():
    """Initialize default template on startup."""
    default_template = TEMPLATES_DIR / "bts_master_template.pptx"
    if not default_template.exists():
        print("Creating default BTS master template...")
        create_bts_master_template(str(default_template))
        print(f"Default template created at: {default_template}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=SERVICE_PORT)
