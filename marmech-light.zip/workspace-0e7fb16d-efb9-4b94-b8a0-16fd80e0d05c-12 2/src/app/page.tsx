'use client';

import { useState, useRef } from 'react';
import { Header } from '@/components/bts/Header';
import { Footer } from '@/components/bts/Footer';
import { BTSLogo } from '@/components/bts/BTSLogo';
import { SlideGeneratorForm } from '@/components/bts/SlideGeneratorForm';
import { ChartStudioForm } from '@/components/bts/ChartStudioForm';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Palette, Zap, Shield, Layers, BarChart3, ImageIcon, Sparkles } from 'lucide-react';

export default function Home() {
  const [activeTab, setActiveTab] = useState('wizard');
  const [showDocs, setShowDocs] = useState(false);
  const tabsRef = useRef<HTMLDivElement>(null);

  const handleDocumentationClick = () => {
    setShowDocs(true);
    // Small delay to ensure the section is rendered before scrolling
    setTimeout(() => {
      document.getElementById('documentation-section')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <Header onDocumentationClick={handleDocumentationClick} />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-10 sm:py-14 lg:py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col items-center text-center">
              {/* Hero Badge */}
              <div
                className="mb-3 inline-flex items-center rounded-full px-4 py-1.5 text-sm font-medium"
                style={{ backgroundColor: 'var(--bts-gray)', color: 'var(--bts-heading)' }}
              >
                <span
                  className="mr-2 h-2 w-2 rounded-full"
                  style={{ backgroundColor: 'var(--bts-cyan)' }}
                />
                MarTech Platform
              </div>

              {/* Main Heading */}
              <h1 className="mb-3 max-w-3xl text-2xl font-bold tracking-tight sm:text-3xl lg:text-4xl" style={{ color: 'var(--bts-heading)' }}>
                AI-Powered{' '}
                <span style={{ color: 'var(--bts-mid-blue)' }}>Presentation</span>
                {' '}Generation
              </h1>

              {/* Subtitle */}
              <p className="mb-5 max-w-2xl text-sm opacity-70 sm:text-base" style={{ color: 'var(--bts-body)' }}>
                Generate pixel-perfect, brand-compliant presentations that strictly adhere to
                BTS brand guidelines. Built for efficiency, designed for consistency.
              </p>
            </div>
          </div>
        </section>

        {/* Main Tabs Section - Three Tabs */}
        <section ref={tabsRef} className="w-full py-4">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full max-w-lg mx-auto grid-cols-3 mb-8">
                <TabsTrigger 
                  value="wizard" 
                  className="data-[state=active]:bg-[var(--bts-navy)] data-[state=active]:text-white text-xs sm:text-sm"
                >
                  <FileText className="mr-1 sm:mr-2 h-3 w-3 sm:h-4 sm:w-4" />
                  <span className="hidden sm:inline">Slide Wizard</span>
                  <span className="sm:hidden">Slides</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="chart" 
                  className="data-[state=active]:bg-[var(--bts-navy)] data-[state=active]:text-white text-xs sm:text-sm"
                >
                  <BarChart3 className="mr-1 sm:mr-2 h-3 w-3 sm:h-4 sm:w-4" />
                  <span className="hidden sm:inline">Chart Studio</span>
                  <span className="sm:hidden">Charts</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="image" 
                  className="data-[state=active]:bg-[var(--bts-navy)] data-[state=active]:text-white text-xs sm:text-sm"
                >
                  <ImageIcon className="mr-1 sm:mr-2 h-3 w-3 sm:h-4 sm:w-4" />
                  <span className="hidden sm:inline">Image Creation</span>
                  <span className="sm:hidden">Images</span>
                </TabsTrigger>
              </TabsList>

              {/* Tab 1: Slide Wizard */}
              <TabsContent value="wizard" className="mt-0">
                <div className="mx-auto max-w-3xl">
                  <Card className="border-0 shadow-lg">
                    <CardHeader className="border-b" style={{ borderColor: 'var(--bts-gray)' }}>
                      <div className="flex items-center gap-3">
                        <BTSLogo size="sm" showText={false} />
                        <div>
                          <CardTitle style={{ color: 'var(--bts-heading)' }}>
                            Slide Generation Wizard
                          </CardTitle>
                          <CardDescription style={{ color: 'var(--bts-body)' }}>
                            Create brand-compliant presentations with style-preserving text injection
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <SlideGeneratorForm />
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Tab 2: Chart Studio (Isolated) */}
              <TabsContent value="chart" className="mt-0">
                <div className="mx-auto max-w-3xl">
                  <Card className="border-0 shadow-lg">
                    <CardHeader className="border-b" style={{ borderColor: 'var(--bts-gray)' }}>
                      <div className="flex items-center gap-3">
                        <div
                          className="flex h-8 w-8 items-center justify-center rounded-lg"
                          style={{ backgroundColor: 'var(--bts-navy)' }}
                        >
                          <BarChart3 className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <CardTitle style={{ color: 'var(--bts-heading)' }}>
                            Chart Studio
                          </CardTitle>
                          <CardDescription style={{ color: 'var(--bts-body)' }}>
                            Generate brand-compliant charts with BTS color palette
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <ChartStudioForm />
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Tab 3: Image Creation (Placeholder) */}
              <TabsContent value="image" className="mt-0">
                <div className="mx-auto max-w-3xl">
                  <Card className="border-0 shadow-lg">
                    <CardHeader className="border-b" style={{ borderColor: 'var(--bts-gray)' }}>
                      <div className="flex items-center gap-3">
                        <div
                          className="flex h-8 w-8 items-center justify-center rounded-lg"
                          style={{ backgroundColor: 'var(--bts-navy)' }}
                        >
                          <ImageIcon className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <CardTitle style={{ color: 'var(--bts-heading)' }}>
                            Image Creation
                          </CardTitle>
                          <CardDescription style={{ color: 'var(--bts-body)' }}>
                            Generate AI-powered images for your presentations
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-6">
                      {/* Placeholder Content - To be built */}
                      <div className="flex flex-col items-center justify-center py-16 text-center">
                        <div
                          className="mb-4 flex h-16 w-16 items-center justify-center rounded-full"
                          style={{ backgroundColor: 'rgba(74, 216, 224, 0.15)' }}
                        >
                          <Sparkles className="h-8 w-8" style={{ color: 'var(--bts-cyan)' }} />
                        </div>
                        <h3 className="mb-2 text-lg font-semibold" style={{ color: 'var(--bts-heading)' }}>
                          Coming Soon
                        </h3>
                        <p className="max-w-md text-sm opacity-70" style={{ color: 'var(--bts-body)' }}>
                          AI-powered image generation for your presentations. 
                          Create custom visuals that match your brand guidelines.
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Documentation Section - Hidden by default, shown after clicking Documentation button */}
        {showDocs && (
          <section id="documentation-section" className="w-full py-10" style={{ backgroundColor: 'var(--bts-gray)' }}>
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="mb-6 flex items-center justify-between">
                <div>
                  <h2 className="mb-2 text-xl font-bold tracking-tight sm:text-2xl" style={{ color: 'var(--bts-heading)' }}>
                    Documentation & Brand Guidelines
                  </h2>
                  <p className="max-w-2xl text-xs opacity-70 sm:text-sm" style={{ color: 'var(--bts-body)' }}>
                    Technical specifications and BTS brand color palette for consistent presentations.
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowDocs(false)}
                  className="text-xs"
                  style={{ color: 'var(--bts-body)' }}
                >
                  Hide
                </Button>
              </div>

            <div className="mx-auto max-w-4xl space-y-6">
              {/* Architecture Overview */}
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2" style={{ color: 'var(--bts-heading)' }}>
                    <Layers className="h-5 w-5" style={{ color: 'var(--bts-mid-blue)' }} />
                    Architecture Overview
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-sm max-w-none">
                  <p style={{ color: 'var(--bts-body)' }}>
                    The BTS MarTech Slide Generator uses a hybrid architecture:
                  </p>
                  <ul className="space-y-2 mt-4" style={{ color: 'var(--bts-body)' }}>
                    <li><strong>Frontend:</strong> Next.js 16 with React 19, Tailwind CSS, and shadcn/ui components</li>
                    <li><strong>Backend:</strong> Python FastAPI service running on port 3002</li>
                    <li><strong>Slide Engine:</strong> python-pptx library for PowerPoint manipulation</li>
                  </ul>
                </CardContent>
              </Card>

              {/* BTS Brand Colors */}
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2" style={{ color: 'var(--bts-heading)' }}>
                    <Palette className="h-5 w-5" style={{ color: 'var(--bts-cyan)' }} />
                    BTS Brand Colors
                  </CardTitle>
                  <CardDescription style={{ color: 'var(--bts-body)' }}>
                    All charts and slides use these exact colors - no default theme colors
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {[
                      { name: 'Deep Navy', hex: '#0A1A5F', usage: 'Primary, Footer' },
                      { name: 'Mid Blue', hex: '#0088C7', usage: 'Secondary, Charts' },
                      { name: 'Light Cyan', hex: '#4AD8E0', usage: 'Accent, Charts' },
                      { name: 'Dark Blue', hex: '#004E8C', usage: 'Tertiary, Charts' },
                      { name: 'Heading', hex: '#1A2A5F', usage: 'Text, Labels' },
                      { name: 'Body Text', hex: '#333333', usage: 'Paragraphs' },
                    ].map((color) => (
                      <div key={color.name} className="flex items-center gap-3">
                        <div
                          className="h-10 w-10 rounded-md shadow-sm ring-1 ring-black/5 shrink-0"
                          style={{ backgroundColor: color.hex }}
                        />
                        <div className="min-w-0">
                          <p className="text-xs font-medium truncate" style={{ color: 'var(--bts-heading)' }}>
                            {color.name}
                          </p>
                          <p className="text-xs opacity-60" style={{ color: 'var(--bts-body)' }}>
                            {color.hex}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Chart Color Override */}
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2" style={{ color: 'var(--bts-heading)' }}>
                    <BarChart3 className="h-5 w-5" style={{ color: 'var(--bts-dark-blue)' }} />
                    Chart Color Override Method
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="rounded-lg p-4 mb-4" style={{ backgroundColor: 'white' }}>
                    <p className="text-sm font-mono" style={{ color: 'var(--bts-heading)' }}>
                      ❌ Default MS Office theme colors are FORBIDDEN
                    </p>
                    <p className="text-sm font-mono mt-2" style={{ color: 'var(--bts-mid-blue)' }}>
                      ✅ Iterate series → Apply BTS RGB colors programmatically
                    </p>
                  </div>
                  <pre className="rounded-lg p-4 text-xs overflow-x-auto" style={{ backgroundColor: '#1e1e1e', color: '#d4d4d4' }}>
{`# BTS Chart Color Palette
BTS_COLORS = [
    RGBColor(0x0A, 0x1A, 0x5F),  # Deep Navy
    RGBColor(0x00, 0x88, 0xC7),  # Mid Blue
    RGBColor(0x4A, 0xD8, 0xE0),  # Light Cyan
    RGBColor(0x00, 0x4E, 0x8C),  # Dark Blue
]

# Apply colors to each series
for i, series in enumerate(chart.series):
    color = BTS_COLORS[i % len(BTS_COLORS)]
    series.format.fill.solid()
    series.format.fill.fore_color.rgb = color`}
                  </pre>
                </CardContent>
              </Card>

              {/* Style Preservation */}
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle style={{ color: 'var(--bts-heading)' }}>
                    Style Preservation Method
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm mb-4" style={{ color: 'var(--bts-body)' }}>
                    Text injection preserves all formatting at run/paragraph level:
                  </p>
                  <ol className="list-decimal list-inside space-y-2 text-sm" style={{ color: 'var(--bts-body)' }}>
                    <li>Access <code className="bg-gray-100 px-1 rounded text-xs">shape.text_frame</code> directly</li>
                    <li>Extract paragraph-level style (alignment, line spacing)</li>
                    <li>Extract run-level style (font family, size, color, bold)</li>
                    <li>Set new text using the preserved style</li>
                  </ol>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
        )}

        {/* Features Section */}
        <section className="w-full py-10 bg-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-6 text-center">
              <h2 className="mb-2 text-xl font-bold tracking-tight sm:text-2xl" style={{ color: 'var(--bts-heading)' }}>
                Platform Features
              </h2>
              <p className="max-w-2xl mx-auto text-xs opacity-70 sm:text-sm" style={{ color: 'var(--bts-body)' }}>
                Designed specifically for BTS brand compliance and efficient presentation workflows.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {/* Feature Cards */}
              <Card className="border-0 shadow-sm transition-shadow hover:shadow-md">
                <CardHeader className="pb-2">
                  <div
                    className="mb-2 flex h-10 w-10 items-center justify-center rounded-lg"
                    style={{ backgroundColor: 'rgba(74, 216, 224, 0.15)' }}
                  >
                    <Palette className="h-5 w-5" style={{ color: 'var(--bts-dark-blue)' }} />
                  </div>
                  <CardTitle className="text-sm" style={{ color: 'var(--bts-heading)' }}>
                    Brand Compliant
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <CardDescription className="text-xs" style={{ color: 'var(--bts-body)' }}>
                    Exact BTS brand colors applied to all slides and charts.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm transition-shadow hover:shadow-md">
                <CardHeader className="pb-2">
                  <div
                    className="mb-2 flex h-10 w-10 items-center justify-center rounded-lg"
                    style={{ backgroundColor: 'rgba(0, 136, 199, 0.15)' }}
                  >
                    <Zap className="h-5 w-5" style={{ color: 'var(--bts-mid-blue)' }} />
                  </div>
                  <CardTitle className="text-sm" style={{ color: 'var(--bts-heading)' }}>
                    Native Charts
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <CardDescription className="text-xs" style={{ color: 'var(--bts-body)' }}>
                    Editable charts with &quot;Edit Data&quot; support in PowerPoint.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm transition-shadow hover:shadow-md">
                <CardHeader className="pb-2">
                  <div
                    className="mb-2 flex h-10 w-10 items-center justify-center rounded-lg"
                    style={{ backgroundColor: 'rgba(0, 78, 140, 0.15)' }}
                  >
                    <Shield className="h-5 w-5" style={{ color: 'var(--bts-dark-blue)' }} />
                  </div>
                  <CardTitle className="text-sm" style={{ color: 'var(--bts-heading)' }}>
                    Style Preservation
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <CardDescription className="text-xs" style={{ color: 'var(--bts-body)' }}>
                    Template formatting preserved during text injection.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm transition-shadow hover:shadow-md">
                <CardHeader className="pb-2">
                  <div
                    className="mb-2 flex h-10 w-10 items-center justify-center rounded-lg"
                    style={{ backgroundColor: 'rgba(10, 26, 95, 0.1)' }}
                  >
                    <FileText className="h-5 w-5" style={{ color: 'var(--bts-navy)' }} />
                  </div>
                  <CardTitle className="text-sm" style={{ color: 'var(--bts-heading)' }}>
                    Image Support
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <CardDescription className="text-xs" style={{ color: 'var(--bts-body)' }}>
                    Aspect-ratio-preserving image injection.
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
