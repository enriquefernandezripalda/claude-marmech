/**
 * Image Generation API Route
 * 
 * Generates AI images using the Python backend service.
 */

import { NextRequest, NextResponse } from 'next/server';

const SLIDE_SERVICE_PORT = 3002;

interface ImageGenerateRequest {
  prompt: string;
  size?: string;
}

/**
 * POST /api/slides/images/generate
 * Generate an AI image from a text prompt
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as ImageGenerateRequest;
    
    if (!body.prompt) {
      return NextResponse.json(
        { error: 'prompt is required' },
        { status: 400 }
      );
    }

    // Call Python service
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/images/generate-sdk`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: body.prompt,
        size: body.size || '1024x1024',
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
      return NextResponse.json(
        { error: errorData.detail || 'Image generation failed' },
        { status: response.status }
      );
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Image generation error:', error);
    return NextResponse.json(
      { error: 'Failed to connect to image generation service' },
      { status: 503 }
    );
  }
}
