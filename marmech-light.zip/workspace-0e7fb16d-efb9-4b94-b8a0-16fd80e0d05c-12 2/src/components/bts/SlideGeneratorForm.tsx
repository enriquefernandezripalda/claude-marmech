'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { FileText, Download, Loader2, AlertCircle, CheckCircle2, Plus, Trash2, Upload, ChevronRight, ChevronDown, Type, Sparkles, Wand2 } from 'lucide-react';
import { TemplateUploader } from './TemplateUploader';
import { Toggle } from '@/components/ui/toggle';

// Top 10 web-safe fonts
const FONT_FAMILIES = [
  { value: 'Arial', label: 'Arial' },
  { value: 'Helvetica', label: 'Helvetica' },
  { value: 'Calibri', label: 'Calibri' },
  { value: 'Roboto', label: 'Roboto' },
  { value: 'Times New Roman', label: 'Times New Roman' },
  { value: 'Open Sans', label: 'Open Sans' },
  { value: 'Verdana', label: 'Verdana' },
  { value: 'Garamond', label: 'Garamond' },
  { value: 'Georgia', label: 'Georgia' },
  { value: 'Futura', label: 'Futura' },
];

// BTS Corporate Colors
const BTS_COLORS = [
  { value: '#0A1A5F', label: 'Deep Navy', description: 'Primary brand color' },
  { value: '#0088C7', label: 'Mid Blue', description: 'Secondary brand color' },
  { value: '#4AD8E0', label: 'Light Cyan', description: 'Accent color' },
  { value: '#004E8C', label: 'Dark Blue', description: 'Professional blue' },
  { value: '#1A2A5F', label: 'Heading Navy', description: 'For headings' },
  { value: '#333333', label: 'Body Gray', description: 'For body text' },
  { value: '#FFFFFF', label: 'White', description: 'For light backgrounds' },
  { value: '#E53935', label: 'Alert Red', description: 'For emphasis' },
  { value: '#43A047', label: 'Success Green', description: 'For positive data' },
  { value: '#FB8C00', label: 'Warning Orange', description: 'For highlights' },
];

interface PlaceholderStyle {
  text: string;
  fontFamily: string;
  fontSize: number;
  bold: boolean;
  italic: boolean;
  color: string;
  // Track if this is using original template style
  useOriginalStyle: boolean;
}

interface Template {
  id: string;
  name: string;
  slide_count: number;
  created_at?: string;
}

interface PlaceholdersResponse {
  slide_index: number;
  placeholders: Record<string, {
    type: string;
    name: string;
    current_text: string;
    width_inches?: number;
    height_inches?: number;
  }>;
}

interface GenerateResult {
  success: boolean;
  message: string;
  modified_placeholders: string[];
  errors: string[];
  download_url?: string;
  file_id?: string;
}

export function SlideGeneratorForm() {
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [templateName, setTemplateName] = useState<string>('');
  const [selectedSlide, setSelectedSlide] = useState<number>(0);
  const [slideCount, setSlideCount] = useState<number>(0);
  const [placeholders, setPlaceholders] = useState<PlaceholdersResponse['placeholders']>({});
  
  // Per-placeholder styles and expanded state
  const [placeholderStyles, setPlaceholderStyles] = useState<Record<string, PlaceholderStyle>>({});
  const [expandedPlaceholders, setExpandedPlaceholders] = useState<Set<string>>(new Set());
  
  // AI generation state
  const [useAiGeneration, setUseAiGeneration] = useState<boolean>(false);
  const [globalPrompt, setGlobalPrompt] = useState<string>('');
  
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingPlaceholders, setLoadingPlaceholders] = useState<boolean>(false);
  const [result, setResult] = useState<GenerateResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Fetch placeholders when template or slide changes
  useEffect(() => {
    if (selectedTemplate) {
      fetchPlaceholders();
    }
  }, [selectedTemplate, selectedSlide]);

  // Initialize placeholder styles when placeholders change
  useEffect(() => {
    const newStyles: Record<string, PlaceholderStyle> = {};
    Object.entries(placeholders).forEach(([idx, info]) => {
      if (info.type !== 'picture') {
        // Keep existing styles if available, otherwise initialize defaults
        if (placeholderStyles[idx]) {
          newStyles[idx] = placeholderStyles[idx];
        } else {
          newStyles[idx] = {
            text: info.current_text || '',
            fontFamily: 'Arial',
            fontSize: info.type === 'title' || info.type === 'center_title' ? 36 : 
                     info.type === 'subtitle' ? 24 : 18,
            bold: info.type === 'title' || info.type === 'center_title',
            italic: false,
            color: '#0A1A5F', // Default to Deep Navy
            useOriginalStyle: true, // Default to using original template style
          };
        }
      }
    });
    setPlaceholderStyles(newStyles);
  }, [placeholders]);

  const fetchPlaceholders = async () => {
    setLoadingPlaceholders(true);
    try {
      const response = await fetch(`/api/slides/placeholders/${selectedTemplate}/${selectedSlide}`);
      if (response.ok) {
        const data: PlaceholdersResponse = await response.json();
        setPlaceholders(data.placeholders);
      }
    } catch (err) {
      console.error('Failed to fetch placeholders:', err);
    } finally {
      setLoadingPlaceholders(false);
    }
  };

  const handleUploadSuccess = (uploadedTemplate: { id: string; name: string; slide_count: number }) => {
    setSelectedTemplate(uploadedTemplate.id);
    setTemplateName(uploadedTemplate.name);
    setSlideCount(uploadedTemplate.slide_count);
    setSelectedSlide(0);
    setError(null);
    setResult(null);
    setPlaceholderStyles({});
    setExpandedPlaceholders(new Set());
    setUseAiGeneration(false);
    setGlobalPrompt('');
  };

  const togglePlaceholderExpand = (idx: string) => {
    setExpandedPlaceholders(prev => {
      const newSet = new Set(prev);
      if (newSet.has(idx)) {
        newSet.delete(idx);
      } else {
        newSet.add(idx);
      }
      return newSet;
    });
  };

  const updatePlaceholderStyle = (idx: string, updates: Partial<PlaceholderStyle>) => {
    setPlaceholderStyles(prev => ({
      ...prev,
      [idx]: { ...prev[idx], ...updates }
    }));
  };

  // Build the payload for the API
  const buildGenerationPayload = useCallback(() => {
    // Find standard placeholders
    const titlePlaceholder = Object.entries(placeholders).find(
      ([_, info]) => info.type === 'title' || info.type === 'center_title'
    );
    const subtitlePlaceholder = Object.entries(placeholders).find(
      ([_, info]) => info.type === 'subtitle'
    );
    const bodyPlaceholder = Object.entries(placeholders).find(
      ([_, info]) => info.type === 'body'
    );

    // Build styles object for all placeholders (for AI generation)
    const placeholderStylesPayload: Record<string, { 
      fontFamily: string; 
      fontSize: number; 
      bold: boolean; 
      italic: boolean; 
      color: string;
      useOriginalStyle: boolean;
    }> = {};
    
    Object.entries(placeholders).forEach(([idx, info]) => {
      if (info.type === 'picture') return;
      if (placeholderStyles[idx]) {
        placeholderStylesPayload[idx] = {
          fontFamily: placeholderStyles[idx].fontFamily,
          fontSize: placeholderStyles[idx].fontSize,
          bold: placeholderStyles[idx].bold,
          italic: placeholderStyles[idx].italic,
          color: placeholderStyles[idx].color,
          useOriginalStyle: placeholderStyles[idx].useOriginalStyle,
        };
      }
    });

    // Build custom placeholders for any non-standard text placeholders
    const customPlaceholders: Record<string, { 
      text: string; 
      style: { 
        fontFamily: string; 
        fontSize: number; 
        bold: boolean; 
        italic: boolean;
        color: string;
        useOriginalStyle: boolean;
      } 
    }> = {};
    
    Object.entries(placeholders).forEach(([idx, info]) => {
      if (info.type === 'picture') return;
      
      const isStandard = 
        (titlePlaceholder && titlePlaceholder[0] === idx) ||
        (subtitlePlaceholder && subtitlePlaceholder[0] === idx) ||
        (bodyPlaceholder && bodyPlaceholder[0] === idx);
      
      if (!isStandard && placeholderStyles[idx]) {
        customPlaceholders[idx] = {
          text: placeholderStyles[idx].text,
          style: {
            fontFamily: placeholderStyles[idx].fontFamily,
            fontSize: placeholderStyles[idx].fontSize,
            bold: placeholderStyles[idx].bold,
            italic: placeholderStyles[idx].italic,
            color: placeholderStyles[idx].color,
            useOriginalStyle: placeholderStyles[idx].useOriginalStyle,
          }
        };
      }
    });

    return {
      template_id: selectedTemplate,
      slide_index: selectedSlide,
      use_ai_generation: useAiGeneration,
      global_prompt: useAiGeneration ? globalPrompt : undefined,
      placeholder_styles: placeholderStylesPayload,
      content: {
        title: titlePlaceholder && placeholderStyles[titlePlaceholder[0]] ? {
          text: placeholderStyles[titlePlaceholder[0]].text,
          style: {
            fontFamily: placeholderStyles[titlePlaceholder[0]].fontFamily,
            fontSize: placeholderStyles[titlePlaceholder[0]].fontSize,
            bold: placeholderStyles[titlePlaceholder[0]].bold,
            italic: placeholderStyles[titlePlaceholder[0]].italic,
            color: placeholderStyles[titlePlaceholder[0]].color,
            useOriginalStyle: placeholderStyles[titlePlaceholder[0]].useOriginalStyle,
          }
        } : undefined,
        subtitle: subtitlePlaceholder && placeholderStyles[subtitlePlaceholder[0]] ? {
          text: placeholderStyles[subtitlePlaceholder[0]].text,
          style: {
            fontFamily: placeholderStyles[subtitlePlaceholder[0]].fontFamily,
            fontSize: placeholderStyles[subtitlePlaceholder[0]].fontSize,
            bold: placeholderStyles[subtitlePlaceholder[0]].bold,
            italic: placeholderStyles[subtitlePlaceholder[0]].italic,
            color: placeholderStyles[subtitlePlaceholder[0]].color,
            useOriginalStyle: placeholderStyles[subtitlePlaceholder[0]].useOriginalStyle,
          }
        } : undefined,
        body: bodyPlaceholder && placeholderStyles[bodyPlaceholder[0]] ? {
          text: placeholderStyles[bodyPlaceholder[0]].text,
          style: {
            fontFamily: placeholderStyles[bodyPlaceholder[0]].fontFamily,
            fontSize: placeholderStyles[bodyPlaceholder[0]].fontSize,
            bold: placeholderStyles[bodyPlaceholder[0]].bold,
            italic: placeholderStyles[bodyPlaceholder[0]].italic,
            color: placeholderStyles[bodyPlaceholder[0]].color,
            useOriginalStyle: placeholderStyles[bodyPlaceholder[0]].useOriginalStyle,
          }
        } : undefined,
        custom_placeholders: Object.keys(customPlaceholders).length > 0 ? customPlaceholders : undefined,
      }
    };
  }, [selectedTemplate, selectedSlide, placeholders, placeholderStyles, useAiGeneration, globalPrompt]);

  const handleGenerate = async () => {
    if (!selectedTemplate) {
      setError('Please upload a template first');
      return;
    }
    
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const payload = buildGenerationPayload();
      
      const response = await fetch('/api/slides/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data: GenerateResult = await response.json();
      
      if (!response.ok) {
        setError(data.message || 'Failed to generate presentation');
      } else {
        setResult(data);
      }
    } catch (err) {
      console.error('Generation error:', err);
      setError('Failed to connect to slide generator service.');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (result?.download_url) {
      const filename = result.download_url.split('/').pop();
      const downloadUrl = `/api/slides/download/${filename}`;
      window.open(downloadUrl, '_blank');
    }
  };

  // Get placeholder icon
  const getPlaceholderIcon = (type: string) => {
    switch (type) {
      case 'picture': return '📷';
      case 'title':
      case 'center_title': return '📌';
      case 'subtitle': return '📝';
      case 'body': return '📄';
      default: return '✏️';
    }
  };

  // Render a text placeholder with expandable styling controls
  const renderPlaceholder = (idx: string, info: { type: string; name: string; current_text: string }) => {
    if (info.type === 'picture') return null;
    
    const isExpanded = expandedPlaceholders.has(idx);
    const style = placeholderStyles[idx] || {
      text: '',
      fontFamily: 'Arial',
      fontSize: 18,
      bold: false,
      italic: false,
      color: '#0A1A5F',
      useOriginalStyle: true,
    };

    return (
      <div 
        key={idx} 
        className="rounded-lg border border-gray-200 overflow-hidden"
        style={{ backgroundColor: 'white' }}
      >
        {/* Header - Always visible */}
        <button
          type="button"
          onClick={() => togglePlaceholderExpand(idx)}
          className="w-full flex items-center justify-between p-3 hover:bg-gray-50 transition-colors"
        >
          <div className="flex items-center gap-2">
            <span className="text-lg">{getPlaceholderIcon(info.type)}</span>
            <span className="text-sm font-medium" style={{ color: 'var(--bts-heading)' }}>
              {info.name || `${info.type.charAt(0).toUpperCase() + info.type.slice(1)} ${idx}`}
            </span>
            <Badge variant="outline" className="text-xs">
              {info.type}
            </Badge>
            {style.useOriginalStyle && (
              <Badge variant="secondary" className="text-xs bg-green-100 text-green-700 border-green-200">
                Original Style
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            {style.text && (
              <span className="text-xs text-gray-500 truncate max-w-[100px]">
                "{style.text.substring(0, 20)}{style.text.length > 20 ? '...' : ''}"
              </span>
            )}
            {isExpanded ? (
              <ChevronDown className="h-4 w-4 text-gray-400" />
            ) : (
              <ChevronRight className="h-4 w-4 text-gray-400" />
            )}
          </div>
        </button>

        {/* Expanded Content - Styling Controls */}
        {isExpanded && (
          <div className="border-t border-gray-200 p-4 space-y-4" style={{ backgroundColor: 'var(--bts-gray)' }}>
            {/* Text Input */}
            <div className="space-y-1.5">
              <Label className="text-xs" style={{ color: 'var(--bts-heading)' }}>Text Content</Label>
              <Textarea
                placeholder="Enter text..."
                value={style.text}
                onChange={(e) => updatePlaceholderStyle(idx, { text: e.target.value })}
                className="min-h-[60px] text-sm"
                rows={2}
              />
            </div>

            {/* Preserve Original Style Toggle */}
            <div className="flex items-center gap-2 p-2 bg-white rounded border border-gray-200">
              <input
                type="checkbox"
                id={`preserve-${idx}`}
                checked={style.useOriginalStyle}
                onChange={(e) => updatePlaceholderStyle(idx, { useOriginalStyle: e.target.checked })}
                className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <Label htmlFor={`preserve-${idx}`} className="text-xs cursor-pointer" style={{ color: 'var(--bts-heading)' }}>
                Preserve original template style (font, size, color)
              </Label>
            </div>

            {/* Styling Controls - Disabled if preserving original style */}
            <div className={`grid grid-cols-2 sm:grid-cols-4 gap-3 ${style.useOriginalStyle ? 'opacity-50 pointer-events-none' : ''}`}>
              {/* Font Family */}
              <div className="space-y-1.5">
                <Label className="text-xs" style={{ color: 'var(--bts-heading)' }}>Font</Label>
                <Select
                  value={style.fontFamily}
                  onValueChange={(value) => updatePlaceholderStyle(idx, { fontFamily: value })}
                >
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FONT_FAMILIES.map((font) => (
                      <SelectItem key={font.value} value={font.value} className="text-xs">
                        <span style={{ fontFamily: font.value }}>{font.label}</span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Font Size */}
              <div className="space-y-1.5">
                <Label className="text-xs" style={{ color: 'var(--bts-heading)' }}>Size</Label>
                <div className="flex items-center gap-1">
                  <Input
                    type="number"
                    value={style.fontSize}
                    onChange={(e) => updatePlaceholderStyle(idx, { fontSize: parseInt(e.target.value) || 12 })}
                    className="h-8 w-full text-xs"
                    min={8}
                    max={200}
                  />
                  <span className="text-xs text-gray-500">pt</span>
                </div>
              </div>

              {/* Bold Toggle */}
              <div className="space-y-1.5">
                <Label className="text-xs" style={{ color: 'var(--bts-heading)' }}>Bold</Label>
                <Toggle
                  pressed={style.bold}
                  onPressedChange={(pressed) => updatePlaceholderStyle(idx, { bold: pressed })}
                  className="h-8 w-full justify-start text-xs font-bold"
                  style={{ fontWeight: 700 }}
                >
                  B
                </Toggle>
              </div>

              {/* Italic Toggle */}
              <div className="space-y-1.5">
                <Label className="text-xs" style={{ color: 'var(--bts-heading)' }}>Italic</Label>
                <Toggle
                  pressed={style.italic}
                  onPressedChange={(pressed) => updatePlaceholderStyle(idx, { italic: pressed })}
                  className="h-8 w-full justify-start text-xs"
                  style={{ fontStyle: 'italic' }}
                >
                  I
                </Toggle>
              </div>
            </div>

            {/* Color Picker - BTS Corporate Colors */}
            <div className={`space-y-2 ${style.useOriginalStyle ? 'opacity-50 pointer-events-none' : ''}`}>
              <Label className="text-xs" style={{ color: 'var(--bts-heading)' }}>Text Color</Label>
              <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
                {BTS_COLORS.map((color) => (
                  <button
                    key={color.value}
                    type="button"
                    onClick={() => updatePlaceholderStyle(idx, { color: color.value })}
                    className={`group relative h-8 w-8 rounded-md border-2 transition-all ${
                      style.color === color.value 
                        ? 'border-blue-500 ring-2 ring-blue-200' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    style={{ backgroundColor: color.value }}
                    title={`${color.label} - ${color.description}`}
                  >
                    {style.color === color.value && (
                      <span className="absolute inset-0 flex items-center justify-center">
                        <span className={`text-xs font-bold ${color.value === '#FFFFFF' ? 'text-gray-800' : 'text-white'}`}>✓</span>
                      </span>
                    )}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-xs text-gray-500">Selected:</span>
                <div 
                  className="h-5 w-5 rounded border border-gray-300" 
                  style={{ backgroundColor: style.color }}
                />
                <span className="text-xs font-mono" style={{ color: 'var(--bts-body)' }}>
                  {style.color} ({BTS_COLORS.find(c => c.value === style.color)?.label || 'Custom'})
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  // Get text placeholders only
  const textPlaceholders = Object.entries(placeholders).filter(
    ([_, info]) => info.type !== 'picture'
  );

  const picturePlaceholders = Object.entries(placeholders).filter(
    ([_, info]) => info.type === 'picture'
  );

  return (
    <div className="space-y-6">
      {/* Template Upload - Always Visible */}
      <TemplateUploader onUploadSuccess={handleUploadSuccess} />

      {/* Template Info & Slide Selection - Only show after upload */}
      {selectedTemplate && (
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2" style={{ color: 'var(--bts-heading)' }}>
              <FileText className="h-5 w-5" style={{ color: 'var(--bts-mid-blue)' }} />
              {templateName}
            </CardTitle>
            <CardDescription style={{ color: 'var(--bts-body)' }}>
              Select which slide to modify
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Label style={{ color: 'var(--bts-heading)' }} className="text-sm">Slide:</Label>
                <Select 
                  value={selectedSlide.toString()} 
                  onValueChange={(v) => setSelectedSlide(parseInt(v))}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: slideCount }, (_, i) => (
                      <SelectItem key={i} value={i.toString()}>
                        Slide {i + 1}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <span className="text-sm" style={{ color: 'var(--bts-body)' }}>
                {slideCount} slides total
              </span>
            </div>

            {/* Placeholders List */}
            {loadingPlaceholders ? (
              <div className="flex items-center gap-2 text-sm py-4" style={{ color: 'var(--bts-body)' }}>
                <Loader2 className="h-4 w-4 animate-spin" />
                Loading placeholders...
              </div>
            ) : textPlaceholders.length > 0 ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2 mb-2">
                  <Type className="h-4 w-4" style={{ color: 'var(--bts-mid-blue)' }} />
                  <span className="text-xs font-medium" style={{ color: 'var(--bts-heading)' }}>
                    Text Placeholders (click to customize)
                  </span>
                </div>
                <div className="space-y-2">
                  {textPlaceholders.map(([idx, info]) => renderPlaceholder(idx, info))}
                </div>
              </div>
            ) : (
              <div className="rounded-lg p-4 text-center" style={{ backgroundColor: 'var(--bts-gray)' }}>
                <AlertCircle className="h-6 w-6 mx-auto mb-2 text-gray-400" />
                <p className="text-xs" style={{ color: 'var(--bts-body)' }}>
                  No text placeholders found on this slide
                </p>
              </div>
            )}

            {/* Picture Placeholders - Just show count */}
            {picturePlaceholders.length > 0 && (
              <div className="text-xs" style={{ color: 'var(--bts-body)' }}>
                📷 {picturePlaceholders.length} image placeholder(s) on this slide
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Error Display */}
      {error && (
        <div className="flex items-start gap-3 rounded-lg border border-red-200 bg-red-50 p-4">
          <AlertCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
          <div>
            <p className="font-medium text-red-800">Error</p>
            <p className="text-sm text-red-600">{error}</p>
          </div>
        </div>
      )}

      {/* Result Display */}
      {result && (
        <div className={`flex items-start gap-3 rounded-lg border p-4 ${
          result.success 
            ? 'border-green-200 bg-green-50' 
            : 'border-yellow-200 bg-yellow-50'
        }`}>
          {result.success ? (
            <CheckCircle2 className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="h-5 w-5 text-yellow-500 shrink-0 mt-0.5" />
          )}
          <div className="flex-1">
            <p className={`font-medium ${result.success ? 'text-green-800' : 'text-yellow-800'}`}>
              {result.success ? 'Success!' : 'Partial Success'}
            </p>
            <p className={`text-sm ${result.success ? 'text-green-600' : 'text-yellow-600'}`}>
              {result.message}
            </p>
            {result.modified_placeholders.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {result.modified_placeholders.map((ph) => (
                  <Badge key={ph} variant="secondary" className="text-xs">
                    {ph}
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* AI Instructions Panel - Only show after upload */}
      {selectedTemplate && textPlaceholders.length > 0 && (
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2" style={{ color: 'var(--bts-heading)' }}>
                <Sparkles className="h-5 w-5" style={{ color: 'var(--bts-cyan)' }} />
                AI Text Generation
              </CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setUseAiGeneration(!useAiGeneration)}
                className={useAiGeneration ? 'bg-green-50 border-green-300 text-green-700' : ''}
              >
                <Wand2 className="h-4 w-4 mr-1" />
                {useAiGeneration ? 'AI Mode On' : 'Enable AI'}
              </Button>
            </div>
            <CardDescription style={{ color: 'var(--bts-body)' }}>
              Let AI generate text content based on your instructions
            </CardDescription>
          </CardHeader>
          {useAiGeneration && (
            <CardContent>
              <div className="space-y-2">
                <Label className="text-sm font-medium" style={{ color: 'var(--bts-heading)' }}>
                  Custom AI Instructions
                </Label>
                <Textarea
                  placeholder="Describe the content you want for your presentation...&#10;&#10;Example: Create a professional presentation about Q4 sales results for a tech company. Include key metrics, challenges overcome, and future outlook. Tone should be corporate but engaging."
                  value={globalPrompt}
                  onChange={(e) => setGlobalPrompt(e.target.value)}
                  className="min-h-[100px] text-sm"
                  rows={4}
                />
                <p className="text-xs" style={{ color: 'var(--bts-body)' }}>
                  The AI will generate text for all placeholders based on your instructions. Styling settings will be preserved.
                </p>
              </div>
            </CardContent>
          )}
        </Card>
      )}

      {/* Action Buttons - Only show after upload */}
      {selectedTemplate && textPlaceholders.length > 0 && (
        <div className="flex flex-col gap-3 sm:flex-row">
          <Button
            onClick={handleGenerate}
            disabled={loading || (useAiGeneration && !globalPrompt.trim())}
            className="flex-1 text-white"
            style={{ backgroundColor: 'var(--bts-navy)' }}
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                {useAiGeneration ? 'AI Generating...' : 'Generating...'}
              </>
            ) : (
              <>
                {useAiGeneration ? (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Generate with AI
                  </>
                ) : (
                  <>
                    <FileText className="h-4 w-4 mr-2" />
                    Generate Presentation
                  </>
                )}
              </>
            )}
          </Button>

          {result?.download_url && (
            <Button
              onClick={handleDownload}
              variant="outline"
              className="flex-1"
              style={{ borderColor: 'var(--bts-mid-blue)', color: 'var(--bts-mid-blue)' }}
            >
              <Download className="h-4 w-4 mr-2" />
              Download PPTX
            </Button>
          )}
        </div>
      )}

      {/* Instructions */}
      {!selectedTemplate && (
        <div className="rounded-lg p-4 text-sm text-center" style={{ backgroundColor: 'var(--bts-gray)', color: 'var(--bts-body)' }}>
          <Upload className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p style={{ color: 'var(--bts-heading)' }} className="font-medium mb-1">
            Upload a template to get started
          </p>
          <p className="text-xs">
            Click placeholders to customize fonts, sizes, and styles
          </p>
        </div>
      )}
    </div>
  );
}

export default SlideGeneratorForm;
