"""
BTS MarTech Presentation Orchestrator
=====================================

This module provides the central orchestration engine that coordinates
all phases (text injection, image handling, chart generation) to produce
a complete BTS-branded presentation.

Author: BTS MarTech Team
"""

import os
import uuid
import tempfile
import shutil
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Union
from pathlib import Path
from datetime import datetime

from pptx import Presentation
from pptx.util import Inches, Pt

# Import all phase modules
from slide_generator import (
    BTSSlideGenerator,
    BTSImageSlideGenerator,
    SlideContent,
    InjectionResult,
    ImageInjectionResult,
    SlideGeneratorError
)
from image_processor import BTSImageProcessor
from chart_generator import (
    BTSChartGenerator,
    ChartData,
    ChartDataSeries,
    ChartGenerationResult
)


@dataclass
class SlideContentPayload:
    """Payload for text content injection."""
    title: Optional[str] = None
    subtitle: Optional[str] = None
    body_paragraphs: Optional[List[str]] = None
    custom_placeholders: Optional[Dict[int, str]] = None


@dataclass
class ImageInjectionPayload:
    """Payload for image injection."""
    placeholder_idx: int
    image_source: Union[str, bytes]  # Path or bytes
    image_id: Optional[str] = None


@dataclass
class ChartGenerationPayload:
    """Payload for chart generation."""
    chart_type: str = 'bar'
    chart_title: Optional[str] = None
    labels: List[str] = field(default_factory=list)
    series: List[Dict[str, Any]] = field(default_factory=list)
    position: Optional[Dict[str, float]] = None  # left, top
    size: Optional[Dict[str, float]] = None  # width, height


@dataclass
class SlidePayload:
    """Complete payload for a single slide."""
    slide_index: int
    text_content: Optional[SlideContentPayload] = None
    images: Optional[List[ImageInjectionPayload]] = None
    chart: Optional[ChartGenerationPayload] = None


@dataclass
class PresentationPayload:
    """Complete payload for generating a presentation."""
    template_id: str
    output_filename: Optional[str] = None
    slides: List[SlidePayload] = field(default_factory=list)


@dataclass
class OrchestratorResult:
    """Result of the orchestration process."""
    success: bool
    message: str
    slides_processed: int
    total_operations: int
    text_injections: int
    image_injections: int
    charts_generated: int
    errors: List[str]
    output_path: Optional[str] = None
    download_url: Optional[str] = None


class BTSPresentationOrchestrator:
    """
    BTS MarTech Presentation Orchestrator
    
    This is the central engine that coordinates all generation phases:
    - Phase 2: Text injection with style preservation
    - Phase 3: Image injection with aspect ratio preservation
    - Phase 4: Chart generation with BTS brand colors
    
    Usage:
    ------
    >>> orchestrator = BTSPresentationOrchestrator(template_dir, output_dir)
    >>> result = orchestrator.generate_presentation(payload)
    """
    
    def __init__(
        self,
        template_dir: str = "templates",
        output_dir: str = "output",
        images_dir: str = "images"
    ):
        """
        Initialize the orchestrator.
        
        Args:
            template_dir: Directory containing templates
            output_dir: Directory for output files
            images_dir: Directory for uploaded images
        """
        self.template_dir = Path(template_dir)
        self.output_dir = Path(output_dir)
        self.images_dir = Path(images_dir)
        
        # Ensure directories exist
        self.template_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.images_dir.mkdir(parents=True, exist_ok=True)
        
        # Cached generators
        self._generators: Dict[str, BTSImageSlideGenerator] = {}
        self._chart_generators: Dict[str, BTSChartGenerator] = {}
        self._image_processor = BTSImageProcessor()
        
        # Track temp files for cleanup
        self._temp_files: List[str] = []
    
    def _get_template_path(self, template_id: str) -> Path:
        """Get the full path to a template file."""
        # Try exact match first
        template_path = self.template_dir / f"{template_id}.pptx"
        if template_path.exists():
            return template_path
        
        # Try partial match
        for f in self.template_dir.glob("*.pptx"):
            if template_id in f.stem:
                return f
        
        raise FileNotFoundError(f"Template not found: {template_id}")
    
    def _get_generator(self, template_path: str) -> BTSImageSlideGenerator:
        """Get or create a generator for the template."""
        if template_path not in self._generators:
            self._generators[template_path] = BTSImageSlideGenerator(template_path)
        return self._generators[template_path]
    
    def _get_chart_generator(self, template_path: str) -> BTSChartGenerator:
        """Get or create a chart generator for the template."""
        if template_path not in self._chart_generators:
            self._chart_generators[template_path] = BTSChartGenerator(template_path)
        return self._chart_generators[template_path]
    
    def _get_image_source(self, image_payload: ImageInjectionPayload) -> Union[str, bytes]:
        """Get image source from payload."""
        if isinstance(image_payload.image_source, bytes):
            return image_payload.image_source
        
        if image_payload.image_id:
            # Look up image by ID
            for img_file in self.images_dir.glob(f"*{image_payload.image_id}*"):
                return str(img_file)
        
        # Assume it's a path
        if os.path.exists(image_payload.image_source):
            return image_payload.image_source
        
        raise FileNotFoundError(f"Image not found: {image_payload.image_id or image_payload.image_source}")
    
    def _process_text_content(
        self,
        generator: BTSImageSlideGenerator,
        slide_index: int,
        text_content: SlideContentPayload
    ) -> InjectionResult:
        """
        Process text content injection (Phase 2).
        
        Args:
            generator: The slide generator
            slide_index: Target slide index
            text_content: Text content payload
            
        Returns:
            InjectionResult
        """
        content = SlideContent(
            title=text_content.title,
            subtitle=text_content.subtitle,
            body_paragraphs=text_content.body_paragraphs,
            custom_placeholders=text_content.custom_placeholders
        )
        
        return generator.generate(slide_index=slide_index, content=content)
    
    def _process_image_injection(
        self,
        generator: BTSImageSlideGenerator,
        slide_index: int,
        image_payload: ImageInjectionPayload
    ) -> ImageInjectionResult:
        """
        Process image injection (Phase 3).
        
        Images are center-cropped to match placeholder aspect ratio.
        
        Args:
            generator: The slide generator
            slide_index: Target slide index
            image_payload: Image injection payload
            
        Returns:
            ImageInjectionResult
        """
        image_source = self._get_image_source(image_payload)
        
        return generator.inject_image(
            slide_index=slide_index,
            placeholder_idx=image_payload.placeholder_idx,
            image_source=image_source
        )
    
    def _process_chart_generation(
        self,
        generator: BTSChartGenerator,
        slide_index: int,
        chart_payload: ChartGenerationPayload
    ) -> ChartGenerationResult:
        """
        Process chart generation (Phase 4).
        
        Charts use native ChartData and BTS brand colors.
        
        Args:
            generator: The chart generator
            slide_index: Target slide index
            chart_payload: Chart generation payload
            
        Returns:
            ChartGenerationResult
        """
        chart_data = ChartData(
            labels=chart_payload.labels,
            series=[
                ChartDataSeries(name=s.get('name', f'Series {i+1}'), values=s.get('values', []))
                for i, s in enumerate(chart_payload.series)
            ]
        )
        
        position = chart_payload.position or {}
        size = chart_payload.size or {}
        
        return generator.generate_chart(
            slide_index=slide_index,
            chart_type=chart_payload.chart_type,
            chart_data=chart_data,
            chart_title=chart_payload.chart_title,
            left=position.get('left'),
            top=position.get('top'),
            width=size.get('width'),
            height=size.get('height')
        )
    
    def generate_presentation(
        self,
        payload: PresentationPayload,
        save_to_file: bool = True
    ) -> OrchestratorResult:
        """
        THE MAIN ORCHESTRATION METHOD.
        
        This coordinates all phases to generate a complete presentation:
        1. Load the master template
        2. For each slide in payload:
           a. Inject text content (Phase 2)
           b. Inject images with center-crop (Phase 3)
           c. Generate charts with BTS colors (Phase 4)
        3. Save the final presentation
        4. Return download path
        
        Args:
            payload: Complete presentation payload
            save_to_file: Whether to save to a file
            
        Returns:
            OrchestratorResult with all operation details
        """
        errors = []
        total_operations = 0
        text_injections = 0
        image_injections = 0
        charts_generated = 0
        
        try:
            # Step 1: Load template
            template_path = self._get_template_path(payload.template_id)
            generator = self._get_generator(str(template_path))
            chart_generator = self._get_chart_generator(str(template_path))
            
            # Step 2: Process each slide
            for slide_payload in payload.slides:
                slide_index = slide_payload.slide_index
                
                # Step 2a: Text injection (Phase 2)
                if slide_payload.text_content:
                    text_result = self._process_text_content(
                        generator, slide_index, slide_payload.text_content
                    )
                    if text_result.success:
                        text_injections += len(text_result.modified_placeholders)
                        total_operations += 1
                    else:
                        errors.extend(text_result.errors)
                
                # Step 2b: Image injection (Phase 3)
                if slide_payload.images:
                    for image_payload in slide_payload.images:
                        try:
                            image_result = self._process_image_injection(
                                generator, slide_index, image_payload
                            )
                            if image_result.success:
                                image_injections += 1
                                total_operations += 1
                            else:
                                errors.extend(image_result.errors)
                        except FileNotFoundError as e:
                            errors.append(f"Image not found: {str(e)}")
                
                # Step 2c: Chart generation (Phase 4)
                if slide_payload.chart:
                    chart_result = self._process_chart_generation(
                        chart_generator, slide_index, slide_payload.chart
                    )
                    if chart_result.success:
                        charts_generated += 1
                        total_operations += 1
                    else:
                        errors.extend(chart_result.errors)
            
            # Step 3: Save output
            output_path = None
            if save_to_file:
                output_filename = payload.output_filename or f"bts_presentation_{uuid.uuid4().hex[:8]}.pptx"
                output_path = str(self.output_dir / output_filename)
                
                try:
                    generator._presentation.save(output_path)
                except Exception as e:
                    errors.append(f"Failed to save presentation: {str(e)}")
            
            # Determine success
            success = total_operations > 0
            
            return OrchestratorResult(
                success=success,
                message=f"Generated presentation with {total_operations} operations" if success else "No operations completed",
                slides_processed=len(payload.slides),
                total_operations=total_operations,
                text_injections=text_injections,
                image_injections=image_injections,
                charts_generated=charts_generated,
                errors=errors,
                output_path=output_path
            )
            
        except FileNotFoundError as e:
            return OrchestratorResult(
                success=False,
                message=f"Template not found: {str(e)}",
                slides_processed=0,
                total_operations=0,
                text_injections=0,
                image_injections=0,
                charts_generated=0,
                errors=[str(e)]
            )
        except Exception as e:
            return OrchestratorResult(
                success=False,
                message=f"Orchestration failed: {str(e)}",
                slides_processed=0,
                total_operations=0,
                text_injections=0,
                image_injections=0,
                charts_generated=0,
                errors=[str(e)]
            )
    
    def generate_from_dict(
        self,
        payload_dict: Dict[str, Any],
        save_to_file: bool = True
    ) -> OrchestratorResult:
        """
        Generate presentation from a dictionary payload.
        
        Args:
            payload_dict: Dictionary with complete payload
            save_to_file: Whether to save to file
            
        Returns:
            OrchestratorResult
        """
        # Parse slides
        slides = []
        for slide_data in payload_dict.get('slides', []):
            # Parse text content
            text_content = None
            if slide_data.get('text_content'):
                tc = slide_data['text_content']
                text_content = SlideContentPayload(
                    title=tc.get('title'),
                    subtitle=tc.get('subtitle'),
                    body_paragraphs=tc.get('body_paragraphs'),
                    custom_placeholders=tc.get('custom_placeholders')
                )
            
            # Parse images
            images = None
            if slide_data.get('images'):
                images = [
                    ImageInjectionPayload(
                        placeholder_idx=img['placeholder_idx'],
                        image_source=img.get('image_source', ''),
                        image_id=img.get('image_id')
                    )
                    for img in slide_data['images']
                ]
            
            # Parse chart
            chart = None
            if slide_data.get('chart'):
                ch = slide_data['chart']
                chart = ChartGenerationPayload(
                    chart_type=ch.get('chart_type', 'bar'),
                    chart_title=ch.get('chart_title'),
                    labels=ch.get('labels', []),
                    series=ch.get('series', []),
                    position=ch.get('position'),
                    size=ch.get('size')
                )
            
            slides.append(SlidePayload(
                slide_index=slide_data['slide_index'],
                text_content=text_content,
                images=images,
                chart=chart
            ))
        
        payload = PresentationPayload(
            template_id=payload_dict['template_id'],
            output_filename=payload_dict.get('output_filename'),
            slides=slides
        )
        
        return self.generate_presentation(payload, save_to_file)
    
    def cleanup_temp_files(self):
        """Clean up temporary files created during generation."""
        for temp_file in self._temp_files:
            try:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
            except Exception as e:
                print(f"Warning: Failed to delete temp file {temp_file}: {e}")
        self._temp_files.clear()
    
    def cleanup_old_outputs(self, max_age_hours: int = 24):
        """
        Clean up output files older than specified age.
        
        Args:
            max_age_hours: Maximum age in hours
        """
        cutoff = datetime.now().timestamp() - (max_age_hours * 3600)
        
        for output_file in self.output_dir.glob("*.pptx"):
            try:
                if output_file.stat().st_mtime < cutoff:
                    os.remove(output_file)
                    print(f"Cleaned up old output: {output_file}")
            except Exception as e:
                print(f"Warning: Failed to clean up {output_file}: {e}")


# Singleton instance
_orchestrator_instance: Optional[BTSPresentationOrchestrator] = None

def get_orchestrator(
    template_dir: str = "templates",
    output_dir: str = "output",
    images_dir: str = "images"
) -> BTSPresentationOrchestrator:
    """Get or create the orchestrator singleton."""
    global _orchestrator_instance
    if _orchestrator_instance is None:
        _orchestrator_instance = BTSPresentationOrchestrator(template_dir, output_dir, images_dir)
    return _orchestrator_instance


if __name__ == "__main__":
    print("BTS MarTech Presentation Orchestrator")
    print("=" * 40)
    
    # Create orchestrator
    orchestrator = BTSPresentationOrchestrator()
    
    # Example payload
    example_payload = {
        "template_id": "bts_master_template",
        "slides": [
            {
                "slide_index": 0,
                "text_content": {
                    "title": "Q1 Business Review",
                    "subtitle": "January - March 2026"
                }
            },
            {
                "slide_index": 1,
                "text_content": {
                    "title": "Revenue Overview",
                    "body_paragraphs": ["Strong growth across all segments"]
                },
                "chart": {
                    "chart_type": "bar",
                    "chart_title": "Quarterly Revenue",
                    "labels": ["Q1", "Q2", "Q3", "Q4"],
                    "series": [
                        {"name": "Revenue", "values": [100, 150, 200, 180]},
                        {"name": "Target", "values": [120, 140, 160, 170]}
                    ]
                }
            }
        ]
    }
    
    print("\nExample payload structure:")
    import json
    print(json.dumps(example_payload, indent=2))
    
    print("\nOrchestrator ready.")
