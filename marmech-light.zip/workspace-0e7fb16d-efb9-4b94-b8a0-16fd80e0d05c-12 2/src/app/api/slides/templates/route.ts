/**
 * BTS MarTech Templates API Route
 * 
 * Proxies requests to the Python FastAPI service for template management.
 */

import { NextRequest, NextResponse } from 'next/server';

const SLIDE_SERVICE_PORT = 3002;

/**
 * GET /api/slides/templates
 * List all available templates
 */
export async function GET() {
  try {
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/templates`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      return NextResponse.json(
        { error: 'Failed to fetch templates' },
        { status: response.status }
      );
    }

    const templates = await response.json();
    return NextResponse.json(templates);
  } catch (error) {
    console.error('Templates fetch error:', error);
    return NextResponse.json(
      { error: 'Failed to connect to slide generator service' },
      { status: 503 }
    );
  }
}

/**
 * POST /api/slides/templates
 * Upload a new template
 */
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/templates/upload`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
      return NextResponse.json(
        { error: errorData.detail || 'Upload failed' },
        { status: response.status }
      );
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Template upload error:', error);
    return NextResponse.json(
      { error: 'Failed to upload template' },
      { status: 500 }
    );
  }
}
