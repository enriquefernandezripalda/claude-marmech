"""
BTS MarTech Chart Generator Module
====================================

This module provides native chart generation for PowerPoint slides.
The CRITICAL requirement is that ALL charts MUST use BTS brand colors.
Default MS Office theme colors are strictly FORBIDDEN.

Author: BTS MarTech Team
"""

import os
from dataclasses import dataclass
from typing import Optional, Dict, Any, List, Tuple, Union
from enum import Enum

from pptx import Presentation
from pptx.util import Pt, Inches, Emu
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
from pptx.chart.data import CategoryChartData
from pptx.enum.shapes import MSO_SHAPE_TYPE

# =============================================================================
# BTS BRAND COLOR PALETTE (From Phase 1)
# =============================================================================
# These colors were extracted from bts.io and are MANDATORY for all charts.
# NEVER use default MS Office theme colors.

BTS_CHART_COLORS = [
    RGBColor(0x0A, 0x1A, 0x5F),  # Deep Navy - Primary
    RGBColor(0x00, 0x88, 0xC7),  # Mid Blue - Secondary
    RGBColor(0x4A, 0xD8, 0xE0),  # Light Cyan - Tertiary
    RGBColor(0x00, 0x4E, 0x8C),  # Dark Blue - Quaternary
    RGBColor(0x1A, 0x2A, 0x5F),  # Heading Color - Quinary
]

BTS_COLOR_NAMES = [
    'Deep Navy (#0A1A5F)',
    'Mid Blue (#0088C7)',
    'Light Cyan (#4AD8E0)',
    'Dark Blue (#004E8C)',
    'Heading (#1A2A5F)',
]

# BTS Typography
BTS_FONT_FAMILY = 'Arial'  # Clean sans-serif matching BTS style
BTS_FONT_SIZE_TITLE = Pt(18)
BTS_FONT_SIZE_AXIS = Pt(12)
BTS_FONT_SIZE_LABEL = Pt(10)


class ChartType(Enum):
    """Supported chart types."""
    BAR = 'bar'
    LINE = 'line'
    PIE = 'pie'
    COLUMN = 'column'
    AREA = 'area'
    SCATTER = 'scatter'


@dataclass
class ChartDataSeries:
    """Represents a single data series for a chart."""
    name: str
    values: List[float]


@dataclass
class ChartData:
    """Represents complete chart data with labels and series."""
    labels: List[str]
    series: List[ChartDataSeries]


@dataclass
class ChartGenerationResult:
    """Result of chart generation operation."""
    success: bool
    message: str
    chart_type: str
    series_count: int
    colors_applied: List[str]
    errors: List[str]
    output_path: Optional[str] = None


class BTSChartGenerator:
    """
    BTS MarTech Chart Generator
    
    This class generates native PowerPoint charts with BTS brand colors.
    
    CRITICAL DESIGN PRINCIPLES:
    ===========================
    1. NEVER use default MS Office theme colors
    2. ALWAYS apply BTS brand colors to ALL series
    3. Use native ChartData for editable charts (right-click "Edit Data")
    4. Apply BTS typography to all chart text elements
    
    Usage:
    ------
    >>> generator = BTSChartGenerator("bts_master_template.pptx")
    >>> result = generator.generate_chart(
    ...     slide_index=0,
    ...     chart_type='bar',
    ...     chart_data=ChartData(
    ...         labels=['Q1', 'Q2', 'Q3', 'Q4'],
    ...         series=[ChartDataSeries('Revenue', [100, 150, 200, 180])]
    ...     )
    ... )
    """
    
    def __init__(self, template_path: str):
        """
        Initialize the chart generator with a template.
        
        Args:
            template_path: Path to the .pptx template file
        """
        self.template_path = template_path
        self._presentation: Optional[Presentation] = None
        
        if not os.path.exists(template_path):
            raise FileNotFoundError(f"Template not found: {template_path}")
    
    def load_template(self) -> Presentation:
        """Load the PowerPoint template."""
        if self._presentation is None:
            self._presentation = Presentation(self.template_path)
        return self._presentation
    
    def get_slide_count(self) -> int:
        """Return the number of slides in the template."""
        if self._presentation is None:
            self.load_template()
        return len(self._presentation.slides)
    
    def _get_chart_type_enum(self, chart_type: str) -> XL_CHART_TYPE:
        """
        Map chart type string to XL_CHART_TYPE enum.
        
        Args:
            chart_type: String representation of chart type
            
        Returns:
            XL_CHART_TYPE enum value
        """
        chart_map = {
            'bar': XL_CHART_TYPE.BAR_CLUSTERED,
            'line': XL_CHART_TYPE.LINE,
            'pie': XL_CHART_TYPE.PIE,
            'column': XL_CHART_TYPE.COLUMN_CLUSTERED,
            'area': XL_CHART_TYPE.AREA,
            'scatter': XL_CHART_TYPE.XY_SCATTER,
        }
        
        if chart_type.lower() not in chart_map:
            raise ValueError(f"Unsupported chart type: {chart_type}")
        
        return chart_map[chart_type.lower()]
    
    def _apply_bts_color_to_series(self, series, color_index: int) -> str:
        """
        Apply BTS brand color to a chart series.
        
        THE GOLDEN METHOD FOR CHART COLORS:
        ====================================
        This method ensures that NO default theme colors are used.
        We programmatically override the fill color of each series.
        
        Args:
            series: python-pptx Series object
            color_index: Index into BTS_CHART_COLORS palette
            
        Returns:
            Name of the color applied
        """
        # Get the BTS color for this series
        color_idx = color_index % len(BTS_CHART_COLORS)
        bts_color = BTS_CHART_COLORS[color_idx]
        color_name = BTS_COLOR_NAMES[color_idx]
        
        # CRITICAL: Apply solid fill with BTS color
        # This strips away any default theme colors
        series.format.fill.solid()
        series.format.fill.fore_color.rgb = bts_color
        
        # Also apply to border/line for line charts
        if hasattr(series.format, 'line'):
            series.format.line.color.rgb = bts_color
            series.format.line.width = Pt(2)
        
        return color_name
    
    def _apply_bts_typography(self, chart, chart_title: Optional[str] = None) -> None:
        """
        Apply BTS typography to all chart text elements.
        
        Args:
            chart: python-pptx Chart object
            chart_title: Optional chart title
        """
        # Apply title
        if chart_title:
            chart.has_title = True
            chart.chart_title.text_frame.paragraphs[0].text = chart_title
            title_para = chart.chart_title.text_frame.paragraphs[0]
            title_para.font.name = BTS_FONT_FAMILY
            title_para.font.size = BTS_FONT_SIZE_TITLE
            title_para.font.bold = True
            title_para.font.color.rgb = BTS_CHART_COLORS[0]  # Deep Navy
        
        # Apply typography to value axis
        if chart.has_value_axis:
            value_axis = chart.value_axis
            if hasattr(value_axis, 'tick_labels'):
                for tick_label in value_axis.tick_labels:
                    tick_label.font.name = BTS_FONT_FAMILY
                    tick_label.font.size = BTS_FONT_SIZE_AXIS
                    tick_label.font.color.rgb = RGBColor(0x33, 0x33, 0x33)  # Body text color
        
        # Apply typography to category axis
        if chart.has_category_axis:
            category_axis = chart.category_axis
            if hasattr(category_axis, 'tick_labels'):
                for tick_label in category_axis.tick_labels:
                    tick_label.font.name = BTS_FONT_FAMILY
                    tick_label.font.size = BTS_FONT_SIZE_AXIS
                    tick_label.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
        
        # Apply typography to legend
        if chart.has_legend:
            legend = chart.legend
            legend.position = XL_LEGEND_POSITION.BOTTOM
            legend.include_in_layout = False
            # Legend text formatting
            if hasattr(legend, 'text_frame'):
                for paragraph in legend.text_frame.paragraphs:
                    paragraph.font.name = BTS_FONT_FAMILY
                    paragraph.font.size = BTS_FONT_SIZE_LABEL
    
    def _apply_pie_chart_colors(self, chart, series_count: int) -> List[str]:
        """
        Apply BTS colors to pie chart slices.
        
        For pie charts, each point (slice) gets a different color.
        
        Args:
            chart: python-pptx Chart object
            series_count: Number of data points
            
        Returns:
            List of color names applied
        """
        colors_applied = []
        
        # For pie charts, we need to color each point
        if chart.series:
            series = chart.series[0]  # Pie charts have one series
            
            for i, point in enumerate(series.points):
                color_idx = i % len(BTS_CHART_COLORS)
                bts_color = BTS_CHART_COLORS[color_idx]
                
                # Apply color to the point (slice)
                point.format.fill.solid()
                point.format.fill.fore_color.rgb = bts_color
                
                colors_applied.append(BTS_COLOR_NAMES[color_idx])
        
        return colors_applied
    
    def generate_chart(
        self,
        slide_index: int,
        chart_type: str,
        chart_data: ChartData,
        chart_title: Optional[str] = None,
        left: Optional[Union[int, float, Emu]] = None,
        top: Optional[Union[int, float, Emu]] = None,
        width: Optional[Union[int, float, Emu]] = None,
        height: Optional[Union[int, float, Emu]] = None,
        output_path: Optional[str] = None
    ) -> ChartGenerationResult:
        """
        Generate a native PowerPoint chart with BTS brand colors.
        
        THE GOLDEN METHOD FOR CHARTS:
        =============================
        1. Create ChartData object with user data
        2. Add chart to slide at specified position
        3. Iterate through ALL series and apply BTS colors
        4. Apply BTS typography to all text elements
        5. Configure legend position
        
        This ensures charts are editable (right-click "Edit Data") and
        100% brand compliant.
        
        Args:
            slide_index: Zero-based index of target slide
            chart_type: Type of chart ('bar', 'line', 'pie', etc.)
            chart_data: ChartData object with labels and series
            chart_title: Optional title for the chart
            left: Left position (inches or Emu)
            top: Top position (inches or Emu)
            width: Width (inches or Emu)
            height: Height (inches or Emu)
            output_path: Path to save the output
            
        Returns:
            ChartGenerationResult with status and applied colors
        """
        errors = []
        colors_applied = []
        
        # Load template
        if self._presentation is None:
            self.load_template()
        
        # Validate slide index
        if slide_index < 0 or slide_index >= len(self._presentation.slides):
            return ChartGenerationResult(
                success=False,
                message=f"Invalid slide index {slide_index}",
                chart_type=chart_type,
                series_count=0,
                colors_applied=[],
                errors=[f"Slide index must be between 0 and {len(self._presentation.slides) - 1}"]
            )
        
        slide = self._presentation.slides[slide_index]
        
        try:
            # Get chart type enum
            xl_chart_type = self._get_chart_type_enum(chart_type)
            
            # Create ChartData object
            chart_data_obj = CategoryChartData()
            chart_data_obj.categories = chart_data.labels
            
            # Add series data
            for series in chart_data.series:
                chart_data_obj.add_series(series.name, series.values)
            
            # Set default dimensions if not provided
            if left is None:
                left = Inches(1)
            if top is None:
                top = Inches(1.5)
            if width is None:
                width = Inches(8)
            if height is None:
                height = Inches(5)
            
            # Convert numeric values to Inches if needed
            if isinstance(left, (int, float)):
                left = Inches(left)
            if isinstance(top, (int, float)):
                top = Inches(top)
            if isinstance(width, (int, float)):
                width = Inches(width)
            if isinstance(height, (int, float)):
                height = Inches(height)
            
            # Add chart to slide
            chart = slide.shapes.add_chart(
                xl_chart_type,
                left,
                top,
                width,
                height,
                chart_data_obj
            ).chart
            
            # CRITICAL: Apply BTS brand colors to ALL series
            # This strips away default MS Office theme colors
            if chart_type.lower() == 'pie':
                # Pie charts: color each slice
                colors_applied = self._apply_pie_chart_colors(chart, len(chart_data.labels))
            else:
                # Bar, Line, etc.: color each series
                for i, series in enumerate(chart.series):
                    color_name = self._apply_bts_color_to_series(series, i)
                    colors_applied.append(color_name)
            
            # Apply BTS typography
            self._apply_bts_typography(chart, chart_title)
            
            # Enable legend
            chart.has_legend = True
            
            # Save output
            if output_path:
                try:
                    self._presentation.save(output_path)
                except Exception as e:
                    errors.append(f"Failed to save presentation: {str(e)}")
            
            return ChartGenerationResult(
                success=True,
                message=f"Successfully created {chart_type} chart with {len(chart.series)} series",
                chart_type=chart_type,
                series_count=len(chart.series),
                colors_applied=colors_applied,
                errors=errors,
                output_path=output_path if output_path and not errors else None
            )
            
        except Exception as e:
            return ChartGenerationResult(
                success=False,
                message=f"Failed to generate chart: {str(e)}",
                chart_type=chart_type,
                series_count=len(chart_data.series),
                colors_applied=colors_applied,
                errors=[str(e)]
            )
    
    def generate_from_dict(
        self,
        slide_index: int,
        config: Dict[str, Any],
        output_path: Optional[str] = None
    ) -> ChartGenerationResult:
        """
        Generate a chart from a dictionary configuration.
        
        Args:
            slide_index: Zero-based slide index
            config: Dictionary with chart_type, chart_title, chart_data
            output_path: Path to save output
            
        Returns:
            ChartGenerationResult
        """
        chart_type = config.get('chart_type', 'bar')
        chart_title = config.get('chart_title')
        data = config.get('chart_data', {})
        
        # Parse chart data
        labels = data.get('labels', [])
        series_data = data.get('series', [])
        
        series = [
            ChartDataSeries(
                name=s.get('name', f'Series {i+1}'),
                values=s.get('values', [])
            )
            for i, s in enumerate(series_data)
        ]
        
        chart_data = ChartData(labels=labels, series=series)
        
        # Optional position and size
        position = config.get('position', {})
        size = config.get('size', {})
        
        return self.generate_chart(
            slide_index=slide_index,
            chart_type=chart_type,
            chart_data=chart_data,
            chart_title=chart_title,
            left=position.get('left'),
            top=position.get('top'),
            width=size.get('width'),
            height=size.get('height'),
            output_path=output_path
        )


# Convenience function
def create_bts_chart(
    template_path: str,
    slide_index: int,
    chart_type: str,
    labels: List[str],
    series: List[Dict[str, Any]],
    output_path: str,
    chart_title: Optional[str] = None
) -> ChartGenerationResult:
    """
    Convenience function to create a BTS-branded chart.
    
    Args:
        template_path: Path to template
        slide_index: Target slide index
        chart_type: Type of chart
        labels: X-axis labels
        series: List of {name, values} dicts
        output_path: Output file path
        chart_title: Optional title
        
    Returns:
        ChartGenerationResult
    """
    generator = BTSChartGenerator(template_path)
    
    chart_data = ChartData(
        labels=labels,
        series=[
            ChartDataSeries(name=s['name'], values=s['values'])
            for s in series
        ]
    )
    
    return generator.generate_chart(
        slide_index=slide_index,
        chart_type=chart_type,
        chart_data=chart_data,
        chart_title=chart_title,
        output_path=output_path
    )


if __name__ == "__main__":
    # Test the chart generator
    print("BTS MarTech Chart Generator")
    print("=" * 40)
    
    # Create test data
    test_data = ChartData(
        labels=['Q1', 'Q2', 'Q3', 'Q4'],
        series=[
            ChartDataSeries('Revenue', [100, 150, 200, 180]),
            ChartDataSeries('Expenses', [80, 90, 110, 95]),
            ChartDataSeries('Profit', [20, 60, 90, 85]),
        ]
    )
    
    print(f"\nTest Data:")
    print(f"  Labels: {test_data.labels}")
    for s in test_data.series:
        print(f"  {s.name}: {s.values}")
    
    print(f"\nBTS Brand Colors for Charts:")
    for i, color in enumerate(BTS_COLOR_NAMES):
        print(f"  Series {i+1}: {color}")
    
    print("\nChart generator module loaded successfully.")
