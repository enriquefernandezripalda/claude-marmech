/**
 * BTS MarTech Slide Generator API Route
 * 
 * This route proxies requests to the Python FastAPI slide generator service.
 * The Python service runs on port 3002 and handles the actual PowerPoint generation.
 */

import { NextRequest, NextResponse } from 'next/server';

// Python service port
const SLIDE_SERVICE_PORT = 3002;

interface TextStyle {
  fontFamily?: string;
  fontSize?: number;
  bold?: boolean;
  italic?: boolean;
}

interface SlideContent {
  title?: string | { text: string; style?: TextStyle };
  subtitle?: string | { text: string; style?: TextStyle };
  body_paragraphs?: string[];
  body?: string | { text: string; style?: TextStyle };
  custom_placeholders?: Record<string, string | { text: string; style?: TextStyle }>;
}

interface GenerateRequest {
  template_id: string;
  slide_index: number;
  content: SlideContent;
  use_ai_generation?: boolean;
  global_prompt?: string;
  placeholder_styles?: Record<string, TextStyle>;
}

/**
 * GET /api/slides/generate
 * Check if the slide generator service is running
 */
export async function GET() {
  try {
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      return NextResponse.json(
        { error: 'Slide generator service not available' },
        { status: 503 }
      );
    }

    const data = await response.json();
    return NextResponse.json(data);
  } catch (error) {
    console.error('Slide generator service error:', error);
    return NextResponse.json(
      { error: 'Failed to connect to slide generator service' },
      { status: 503 }
    );
  }
}

/**
 * POST /api/slides/generate
 * Generate a presentation by injecting content into a template
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const { 
      template_id, 
      slide_index, 
      content, 
      use_ai_generation, 
      global_prompt, 
      placeholder_styles 
    } = body as GenerateRequest;

    // Validate required fields
    if (!template_id) {
      return NextResponse.json(
        { error: 'template_id is required' },
        { status: 400 }
      );
    }

    // Build request payload for Python service
    const pythonPayload: Record<string, unknown> = {
      template_id,
      slide_index: slide_index ?? 0,
      content: content || {},
    };

    // Add AI generation fields if provided
    if (use_ai_generation !== undefined) {
      pythonPayload.use_ai_generation = use_ai_generation;
    }
    if (global_prompt) {
      pythonPayload.global_prompt = global_prompt;
    }
    if (placeholder_styles) {
      pythonPayload.placeholder_styles = placeholder_styles;
    }

    // Call Python service
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(pythonPayload),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
      return NextResponse.json(
        { error: errorData.detail || 'Generation failed' },
        { status: response.status }
      );
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Generation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate presentation' },
      { status: 500 }
    );
  }
}
