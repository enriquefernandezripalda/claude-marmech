"""
BTS MarTech AI Text Generator
================================

This module provides AI-powered text generation using z-ai SDK.
It generates slide content based on user prompts while respecting placeholder types.

CRITICAL: This module uses z-ai chat for text generation, not MLX (which is unavailable).

Author: BTS MarTech Team
"""

import subprocess
import json
import re
from dataclasses import dataclass
from typing import Optional, Dict, Any, List


@dataclass
class GeneratedContent:
    """Container for AI-generated slide content."""
    title: Optional[str] = None
    subtitle: Optional[str] = None
    body: Optional[str] = None
    custom_placeholders: Optional[Dict[str, str]] = None
    raw_response: Optional[str] = None


class MLXTextGenerator:
    """
    AI-based text generator for slide content.
    
    Uses z-ai chat command for text generation.
    Falls back to placeholder content if AI is unavailable.
    """
    
    def __init__(self, model: Optional[str] = None):
        """
        Initialize the text generator.
        
        Args:
            model: Optional model identifier (ignored, uses default z-ai model)
        """
        self.model = model
        self._verify_ai_available()
    
    def _verify_ai_available(self) -> bool:
        """Verify that z-ai is available."""
        try:
            result = subprocess.run(
                ["z-ai", "chat", "--help"],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except Exception:
            return False
    
    def _build_prompt(
        self,
        user_prompt: str,
        placeholder_info: Dict[str, Dict[str, Any]],
        placeholder_styles: Optional[Dict[str, Dict[str, Any]]] = None,
        slide_context: Optional[str] = None
    ) -> str:
        """
        Build the system prompt for slide content generation.
        
        Args:
            user_prompt: User's custom instructions
            placeholder_info: Dict mapping placeholder idx to type/name info
            placeholder_styles: Optional dict of placeholder styles
            slide_context: Optional context about which slide this is (e.g., "Slide 1 of 4 - Title Slide")
            
        Returns:
            Formatted prompt string
        """
        # Build placeholder descriptions
        placeholder_descriptions = []
        custom_ph_list = []
        
        for idx, info in placeholder_info.items():
            ph_type = info.get('type', 'unknown')
            ph_name = info.get('name', f'Placeholder {idx}')
            
            if ph_type in ['title', 'center_title']:
                placeholder_descriptions.append(f"- title: The main slide title (keep it impactful, 3-8 words)")
            elif ph_type == 'subtitle':
                placeholder_descriptions.append(f"- subtitle: The subtitle text (5-15 words, descriptive)")
            elif ph_type == 'body':
                placeholder_descriptions.append(f"- body: The main body content (2-4 sentences or bullet points)")
            else:
                custom_ph_list.append(f"- placeholder_{idx} ({ph_name}): Custom text content")
        
        all_placeholders = "\n".join(placeholder_descriptions + custom_ph_list)
        
        slide_context_str = f"\n\nTHIS IS: {slide_context}" if slide_context else ""
        
        prompt = f"""You are a professional presentation content writer for BTS, a leading consulting company. Generate compelling, business-appropriate content for a PowerPoint slide.

USER'S REQUEST:
{user_prompt}{slide_context_str}

PLACEHOLDERS TO FILL:
{all_placeholders}

REQUIREMENTS:
1. Create professional, engaging content suitable for business presentations
2. Titles should be impactful and concise (3-8 words)
3. Subtitles should be descriptive but brief (5-15 words)
4. Body text should be informative but concise (2-4 sentences)
5. Use a professional but engaging tone
6. Avoid clichés and generic phrases
7. Make content relevant to the slide's position in the presentation

Respond ONLY with valid JSON in this exact format:
{{
  "title": "Your Generated Title Here",
  "subtitle": "Your Generated Subtitle Here",
  "body": "Your generated body content here. Can be multiple sentences.",
  "custom_placeholders": {{
    "placeholder_idx": "Content for that placeholder"
  }}
}}

Only include keys for placeholders that exist. If a placeholder type doesn't exist, omit it from the response.
Generate the JSON response now:"""

        return prompt
    
    def generate_content_for_slide(
        self,
        user_prompt: str,
        placeholder_info: Dict[str, Dict[str, Any]],
        placeholder_styles: Optional[Dict[str, Dict[str, Any]]] = None,
        slide_context: Optional[str] = None,
        max_tokens: int = 1024
    ) -> GeneratedContent:
        """
        Generate slide content for a single slide.
        
        Args:
            user_prompt: User's custom instructions for content generation
            placeholder_info: Dict mapping placeholder idx to type/name info
            placeholder_styles: Optional dict of placeholder styles (used for context)
            slide_context: Context about this slide (e.g., "Slide 1 of 4 - Title Slide")
            max_tokens: Maximum tokens to generate (not used in z-ai, kept for compatibility)
            
        Returns:
            GeneratedContent with AI-generated text for each placeholder
        """
        # Build the prompt
        full_prompt = self._build_prompt(user_prompt, placeholder_info, placeholder_styles, slide_context)
        
        try:
            # Call z-ai chat for generation
            result = subprocess.run(
                [
                    "z-ai", "chat",
                    "-p", full_prompt
                ],
                capture_output=True,
                text=True,
                timeout=60  # 1 minute timeout
            )
            
            if result.returncode != 0:
                print(f"z-ai generation error: {result.stderr}")
                return self._fallback_generation(user_prompt, placeholder_info)
            
            # Parse the response
            output = result.stdout
            generated_content = self._parse_ai_output(output)
            
            return generated_content
            
        except subprocess.TimeoutExpired:
            print("z-ai generation timed out")
            return self._fallback_generation(user_prompt, placeholder_info)
        except Exception as e:
            print(f"z-ai generation failed: {str(e)}")
            return self._fallback_generation(user_prompt, placeholder_info)

    def generate_content(
        self,
        user_prompt: str,
        placeholder_info: Dict[str, Dict[str, Any]],
        placeholder_styles: Optional[Dict[str, Dict[str, Any]]] = None,
        max_tokens: int = 1024
    ) -> GeneratedContent:
        """
        Generate slide content using z-ai chat. (Backward compatible single-slide version)
        
        Args:
            user_prompt: User's custom instructions for content generation
            placeholder_info: Dict mapping placeholder idx to type/name info
            placeholder_styles: Optional dict of placeholder styles (used for context)
            max_tokens: Maximum tokens to generate (not used in z-ai, kept for compatibility)
            
        Returns:
            GeneratedContent with AI-generated text for each placeholder
        """
        return self.generate_content_for_slide(
            user_prompt=user_prompt,
            placeholder_info=placeholder_info,
            placeholder_styles=placeholder_styles,
            slide_context=None,
            max_tokens=max_tokens
        )
    
    def _parse_ai_output(self, output: str) -> GeneratedContent:
        """
        Parse the AI output to extract generated content.
        
        z-ai chat returns output like:
        🚀 Initializing Z-AI SDK...
        🚀 Sending chat request...
        {
          "choices": [
            {
              "message": {
                "content": "```json\n{...}\n```"
              }
            }
          ]
        }
        
        Args:
            output: Raw output from z-ai chat command
            
        Returns:
            GeneratedContent with parsed values
        """
        # First, extract the JSON from the output (there may be log lines before it)
        json_start = output.find('{\n  "choices"')
        if json_start == -1:
            json_start = output.find('{"choices"')
        if json_start == -1:
            json_start = output.find('{')
        
        if json_start == -1:
            print("No JSON found in output")
            return GeneratedContent()
        
        json_output = output[json_start:]
        
        try:
            # Parse the outer z-ai response format
            outer_data = json.loads(json_output)
            if 'choices' in outer_data and len(outer_data['choices']) > 0:
                message = outer_data['choices'][0].get('message', {})
                content_str = message.get('content', '')
                
                # Now parse the inner JSON string
                if content_str:
                    # Strip markdown code blocks if present
                    content_str = content_str.strip()
                    if content_str.startswith('```'):
                        # Remove code block markers
                        lines = content_str.split('\n')
                        # Remove first line (```json or ```) and last line (```)
                        content_str = '\n'.join(lines[1:-1]) if len(lines) > 2 else content_str
                    
                    try:
                        inner_data = json.loads(content_str)
                        return GeneratedContent(
                            title=inner_data.get('title'),
                            subtitle=inner_data.get('subtitle'),
                            body=inner_data.get('body'),
                            custom_placeholders=inner_data.get('custom_placeholders'),
                            raw_response=output
                        )
                    except json.JSONDecodeError as je:
                        print(f"Failed to parse inner JSON: {je}")
                        print(f"Content string was: {content_str[:200]}")
        except json.JSONDecodeError as je:
            print(f"Failed to parse outer JSON: {je}")
        
        # Fallback: try to find JSON in the output directly
        try:
            json_match = re.search(r'\{[\s\S]*\}', output)
            if json_match:
                json_str = json_match.group(0)
                data = json.loads(json_str)
                
                return GeneratedContent(
                    title=data.get('title'),
                    subtitle=data.get('subtitle'),
                    body=data.get('body'),
                    custom_placeholders=data.get('custom_placeholders'),
                    raw_response=output
                )
        except json.JSONDecodeError as e:
            print(f"JSON decode error: {e}")
        
        return GeneratedContent()
    
    def _fallback_generation(
        self,
        user_prompt: str,
        placeholder_info: Dict[str, Dict[str, Any]]
    ) -> GeneratedContent:
        """
        Generate fallback content when AI fails.
        
        Creates meaningful placeholder text based on the prompt.
        
        Args:
            user_prompt: User's instructions
            placeholder_info: Dict of placeholder info
            
        Returns:
            GeneratedContent with fallback values
        """
        # Extract key topic from prompt
        topic = user_prompt[:100] if len(user_prompt) > 100 else user_prompt
        
        content = GeneratedContent()
        
        for idx, info in placeholder_info.items():
            ph_type = info.get('type', 'unknown')
            
            if ph_type in ['title', 'center_title']:
                content.title = f"Presentation: {topic[:50]}"
            elif ph_type == 'subtitle':
                content.subtitle = "AI-generated content based on your instructions"
            elif ph_type == 'body':
                content.body = f"Content for: {topic}\n\nPlease customize this text with your specific information."
        
        return content


# Convenience function for direct usage
def generate_slide_content(
    user_prompt: str,
    placeholder_info: Dict[str, Dict[str, Any]],
    placeholder_styles: Optional[Dict[str, Dict[str, Any]]] = None,
    model: Optional[str] = None
) -> GeneratedContent:
    """
    Generate slide content using AI.
    
    Args:
        user_prompt: User's instructions for content
        placeholder_info: Dict of placeholder type/name info
        placeholder_styles: Optional styling info
        model: Optional model override (ignored)
        
    Returns:
        GeneratedContent with AI-generated text
    """
    generator = MLXTextGenerator(model=model)
    return generator.generate_content(
        user_prompt=user_prompt,
        placeholder_info=placeholder_info,
        placeholder_styles=placeholder_styles
    )
