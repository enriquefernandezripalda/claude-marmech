'use client';

import React from 'react';
import { BTSLogo } from './BTSLogo';
import { Separator } from '@/components/ui/separator';

interface FooterProps {
  className?: string;
}

export function Footer({ className = '' }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer
      className={`w-full text-white ${className}`}
      style={{ backgroundColor: 'var(--bts-navy)' }}
    >
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-4">
          {/* Brand Column */}
          <div className="md:col-span-2">
            <BTSLogo size="lg" showText={true} className="text-white [&_span]:text-white" />
            <p className="mt-4 max-w-md text-sm leading-relaxed opacity-80">
              BTS MarTech Platform — Empowering businesses with AI-driven presentation generation
              that strictly adheres to brand guidelines.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider opacity-90">
              Platform
            </h3>
            <ul className="space-y-3 text-sm opacity-80">
              <li>
                <a href="#" className="transition-opacity hover:opacity-100">
                  Slide Generator
                </a>
              </li>
              <li>
                <a href="#" className="transition-opacity hover:opacity-100">
                  Brand Assets
                </a>
              </li>
              <li>
                <a href="#" className="transition-opacity hover:opacity-100">
                  Templates
                </a>
              </li>
              <li>
                <a href="#" className="transition-opacity hover:opacity-100">
                  Documentation
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider opacity-90">
              Company
            </h3>
            <ul className="space-y-3 text-sm opacity-80">
              <li>
                <a href="https://bts.io" className="transition-opacity hover:opacity-100" target="_blank" rel="noopener noreferrer">
                  bts.io
                </a>
              </li>
              <li>
                <a href="#" className="transition-opacity hover:opacity-100">
                  About
                </a>
              </li>
              <li>
                <a href="#" className="transition-opacity hover:opacity-100">
                  Careers
                </a>
              </li>
              <li>
                <a href="#" className="transition-opacity hover:opacity-100">
                  Contact
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="container mx-auto flex flex-col items-center justify-between gap-4 px-4 py-6 sm:flex-row sm:px-6 lg:px-8">
          <p className="text-sm opacity-70">
            © {currentYear} BTS. All rights reserved.
          </p>
          
          {/* Tagline */}
          <div className="flex items-center">
            <span className="text-sm font-medium opacity-90">
              Innovation starts here
            </span>
            <div className="ml-3 flex items-end gap-1">
              <div
                className="rounded-sm"
                style={{ width: '3px', height: '12px', backgroundColor: 'var(--bts-cyan)' }}
              />
              <div
                className="rounded-sm"
                style={{ width: '3px', height: '9px', backgroundColor: 'var(--bts-mid-blue)' }}
              />
              <div
                className="rounded-sm"
                style={{ width: '3px', height: '6px', backgroundColor: 'var(--bts-dark-blue)' }}
              />
            </div>
          </div>

          <div className="flex gap-6 text-sm opacity-70">
            <a href="#" className="transition-opacity hover:opacity-100">
              Privacy
            </a>
            <a href="#" className="transition-opacity hover:opacity-100">
              Terms
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
