import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "BTS MarTech - AI-Powered Presentation Generation",
  description: "Generate pixel-perfect, brand-compliant presentations that strictly adhere to BTS brand guidelines. Built for efficiency, designed for consistency.",
  keywords: ["BTS", "MarTech", "Presentation", "AI", "Brand Guidelines", "PPTX", "bts.io"],
  authors: [{ name: "BTS Team" }],
  icons: {
    icon: "/favicon.ico",
  },
  openGraph: {
    title: "BTS MarTech Platform",
    description: "AI-Powered Presentation Generation with Brand Compliance",
    url: "https://bts.io",
    siteName: "BTS",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "BTS MarTech Platform",
    description: "AI-Powered Presentation Generation with Brand Compliance",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
