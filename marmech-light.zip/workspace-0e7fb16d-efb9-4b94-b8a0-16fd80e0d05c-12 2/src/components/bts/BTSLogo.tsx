'use client';

import React from 'react';

interface BTSLogoProps {
  className?: string;
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export function BTSLogo({ className = '', showText = true, size = 'md' }: BTSLogoProps) {
  const sizeConfig = {
    sm: { barHeight: 20, barWidth: 4, gap: 2, textSize: 'text-lg', spacing: 'ml-2' },
    md: { barHeight: 28, barWidth: 5, gap: 2.5, textSize: 'text-xl', spacing: 'ml-2.5' },
    lg: { barHeight: 36, barWidth: 6, gap: 3, textSize: 'text-2xl', spacing: 'ml-3' },
  };

  const config = sizeConfig[size];

  return (
    <div className={`flex items-center ${className}`}>
      {/* Three vertical bars */}
      <div className="flex items-end" style={{ gap: `${config.gap}px` }}>
        {/* Light Cyan Bar - Tallest */}
        <div
          className="bts-logo-bar rounded-sm"
          style={{
            width: `${config.barWidth}px`,
            height: `${config.barHeight}px`,
            backgroundColor: 'var(--bts-cyan)',
          }}
        />
        {/* Mid Blue Bar - Medium */}
        <div
          className="bts-logo-bar rounded-sm"
          style={{
            width: `${config.barWidth}px`,
            height: `${config.barHeight * 0.75}px`,
            backgroundColor: 'var(--bts-mid-blue)',
          }}
        />
        {/* Dark Blue Bar - Shortest */}
        <div
          className="bts-logo-bar rounded-sm"
          style={{
            width: `${config.barWidth}px`,
            height: `${config.barHeight * 0.55}px`,
            backgroundColor: 'var(--bts-dark-blue)',
          }}
        />
      </div>

      {/* BTS Text */}
      {showText && (
        <span
          className={`font-bold tracking-tight ${config.textSize} ${config.spacing}`}
          style={{ color: 'var(--bts-heading)' }}
        >
          BTS
        </span>
      )}
    </div>
  );
}

export default BTSLogo;
