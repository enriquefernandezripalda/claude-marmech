'use client';

import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Upload, FileText, Loader2, CheckCircle2, AlertCircle, X } from 'lucide-react';

interface TemplateUploaderProps {
  onUploadSuccess?: (template: UploadedTemplate) => void;
}

interface UploadedTemplate {
  id: string;
  name: string;
  slide_count: number;
  message?: string;
}

export function TemplateUploader({ onUploadSuccess }: TemplateUploaderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadResult, setUploadResult] = useState<UploadedTemplate | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const validateFile = (file: File): string | null => {
    // Check file extension
    if (!file.name.toLowerCase().endsWith('.pptx')) {
      return 'Invalid file type. Only .pptx files are accepted.';
    }
    
    // Check MIME type
    const validTypes = [
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'application/vnd.ms-powerpoint.presentation.macroEnabled.12',
      'application/zip', // Some systems report .pptx as zip
    ];
    
    if (file.type && !validTypes.includes(file.type)) {
      return `Invalid MIME type: ${file.type}. Expected PowerPoint file.`;
    }
    
    // Check file size (max 50MB)
    const maxSize = 50 * 1024 * 1024;
    if (file.size > maxSize) {
      return 'File too large. Maximum size is 50MB.';
    }
    
    return null;
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      const validationError = validateFile(file);
      if (validationError) {
        setError(validationError);
        setSelectedFile(null);
      } else {
        setError(null);
        setSelectedFile(file);
        setUploadResult(null);
      }
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      const validationError = validateFile(file);
      if (validationError) {
        setError(validationError);
        setSelectedFile(null);
      } else {
        setError(null);
        setSelectedFile(file);
        setUploadResult(null);
      }
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;
    
    setIsUploading(true);
    setError(null);
    setUploadProgress(0);
    
    try {
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('name', selectedFile.name.replace('.pptx', ''));
      
      // Simulate progress for better UX
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => Math.min(prev + 10, 90));
      }, 100);
      
      const response = await fetch('/api/slides/templates/upload-secure', {
        method: 'POST',
        body: formData,
      });
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || result.detail || 'Upload failed');
      }
      
      setUploadResult({
        id: result.template_id,
        name: result.name || selectedFile.name,
        slide_count: result.slide_count,
        message: result.message,
      });
      
      // Notify parent component
      if (onUploadSuccess) {
        onUploadSuccess({
          id: result.template_id,
          name: result.name || selectedFile.name,
          slide_count: result.slide_count,
        });
      }
      
      // Clear selected file after successful upload
      setSelectedFile(null);
      
    } catch (err) {
      console.error('Upload error:', err);
      setError(err instanceof Error ? err.message : 'Failed to upload template');
    } finally {
      setIsUploading(false);
    }
  };

  const clearSelection = () => {
    setSelectedFile(null);
    setError(null);
    setUploadResult(null);
    setUploadProgress(0);
  };

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2" style={{ color: 'var(--bts-heading)' }}>
          <Upload className="h-5 w-5" style={{ color: 'var(--bts-mid-blue)' }} />
          Upload Template
        </CardTitle>
        <CardDescription style={{ color: 'var(--bts-body)' }}>
          Upload a .pptx template with styled placeholders for text injection
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Drop Zone */}
        <div
          className={`relative border-2 border-dashed rounded-lg p-6 transition-all duration-200 ${
            isDragging 
              ? 'border-[var(--bts-mid-blue)] bg-blue-50' 
              : 'border-gray-300 hover:border-gray-400'
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <input
            type="file"
            accept=".pptx"
            onChange={handleFileSelect}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            disabled={isUploading}
          />
          
          <div className="flex flex-col items-center text-center">
            <div 
              className="mb-3 p-3 rounded-full"
              style={{ backgroundColor: 'var(--bts-gray)' }}
            >
              <FileText className="h-8 w-8" style={{ color: 'var(--bts-mid-blue)' }} />
            </div>
            <p className="text-sm font-medium mb-1" style={{ color: 'var(--bts-heading)' }}>
              {isDragging ? 'Drop your template here' : 'Drag & drop your .pptx template'}
            </p>
            <p className="text-xs" style={{ color: 'var(--bts-body)' }}>
              or click to browse • Max 50MB
            </p>
          </div>
        </div>

        {/* Selected File Preview */}
        {selectedFile && (
          <div 
            className="flex items-center gap-3 p-3 rounded-lg"
            style={{ backgroundColor: 'var(--bts-gray)' }}
          >
            <FileText className="h-5 w-5 shrink-0" style={{ color: 'var(--bts-mid-blue)' }} />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate" style={{ color: 'var(--bts-heading)' }}>
                {selectedFile.name}
              </p>
              <p className="text-xs" style={{ color: 'var(--bts-body)' }}>
                {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
              </p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={clearSelection}
              className="h-8 w-8"
              disabled={isUploading}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}

        {/* Upload Progress */}
        {isUploading && (
          <div className="space-y-2">
            <Progress value={uploadProgress} className="h-2" />
            <p className="text-xs text-center" style={{ color: 'var(--bts-body)' }}>
              Uploading... {uploadProgress}%
            </p>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="flex items-start gap-2 p-3 rounded-lg bg-red-50 border border-red-200">
            <AlertCircle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        {/* Success Display */}
        {uploadResult && (
          <div className="flex items-start gap-2 p-3 rounded-lg bg-green-50 border border-green-200">
            <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-green-800">Template uploaded successfully!</p>
              <p className="text-xs text-green-600">
                {uploadResult.name} ({uploadResult.slide_count} slides)
              </p>
            </div>
          </div>
        )}

        {/* Upload Button */}
        {selectedFile && !isUploading && (
          <Button
            onClick={handleUpload}
            className="w-full text-white"
            style={{ backgroundColor: 'var(--bts-navy)' }}
          >
            <Upload className="h-4 w-4 mr-2" />
            Upload Template
          </Button>
        )}

        {/* Instructions */}
        <div className="text-xs space-y-1 p-3 rounded-lg" style={{ backgroundColor: 'var(--bts-gray)', color: 'var(--bts-body)' }}>
          <p className="font-medium" style={{ color: 'var(--bts-heading)' }}>Template Requirements:</p>
          <ul className="list-disc list-inside space-y-0.5 ml-1">
            <li>Must be a .pptx file (PowerPoint 2007+)</li>
            <li>Use text placeholders (Title, Subtitle, Body)</li>
            <li>Apply your brand fonts and colors in the template</li>
            <li>The generator will preserve your template styling</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}

export default TemplateUploader;
