/**
 * Chart Generation API Route
 * 
 * Generates native PowerPoint charts with BTS brand colors.
 */

import { NextRequest, NextResponse } from 'next/server';

const SLIDE_SERVICE_PORT = 3002;

interface ChartSeries {
  name: string;
  values: number[];
}

interface ChartData {
  labels: string[];
  series: ChartSeries[];
}

interface ChartGenerateRequest {
  template_id: string;
  slide_index: number;
  chart_type: string;
  chart_title?: string;
  chart_data: ChartData;
}

/**
 * POST /api/slides/charts/generate
 * Generate a native PowerPoint chart with BTS brand colors
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as ChartGenerateRequest;
    
    if (!body.template_id) {
      return NextResponse.json(
        { error: 'template_id is required' },
        { status: 400 }
      );
    }

    if (!body.chart_data || !body.chart_data.labels || !body.chart_data.series) {
      return NextResponse.json(
        { error: 'chart_data with labels and series is required' },
        { status: 400 }
      );
    }

    // Call Python service
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/charts/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        template_id: body.template_id,
        slide_index: body.slide_index ?? 0,
        chart_type: body.chart_type || 'bar',
        chart_title: body.chart_title,
        chart_data: body.chart_data,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
      return NextResponse.json(
        { error: errorData.detail || 'Chart generation failed' },
        { status: response.status }
      );
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Chart generation error:', error);
    return NextResponse.json(
      { error: 'Failed to connect to chart generator service' },
      { status: 503 }
    );
  }
}

/**
 * GET /api/slides/charts/generate
 * Get BTS brand color palette for charts
 */
export async function GET() {
  try {
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/charts/colors`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      return NextResponse.json(
        { error: 'Failed to fetch chart colors' },
        { status: response.status }
      );
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Chart colors fetch error:', error);
    return NextResponse.json(
      { error: 'Failed to connect to chart generator service' },
      { status: 503 }
    );
  }
}
