/**
 * Image Injection API Route
 * 
 * Injects images into picture placeholders with aspect ratio preservation.
 */

import { NextRequest, NextResponse } from 'next/server';

const SLIDE_SERVICE_PORT = 3002;

interface ImageInjectRequest {
  template_id: string;
  slide_index: number;
  placeholder_idx: number;
  image_id?: string;
  image_base64?: string;
}

/**
 * POST /api/slides/images/inject
 * Inject an image into a picture placeholder
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as ImageInjectRequest;
    
    if (!body.template_id) {
      return NextResponse.json(
        { error: 'template_id is required' },
        { status: 400 }
      );
    }

    if (body.placeholder_idx === undefined || body.placeholder_idx === null) {
      return NextResponse.json(
        { error: 'placeholder_idx is required' },
        { status: 400 }
      );
    }

    if (!body.image_id && !body.image_base64) {
      return NextResponse.json(
        { error: 'Either image_id or image_base64 is required' },
        { status: 400 }
      );
    }

    // Call Python service
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/slides/inject-image`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        template_id: body.template_id,
        slide_index: body.slide_index ?? 0,
        placeholder_idx: body.placeholder_idx,
        image_id: body.image_id,
        image_base64: body.image_base64,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
      return NextResponse.json(
        { error: errorData.detail || 'Image injection failed' },
        { status: response.status }
      );
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Image injection error:', error);
    return NextResponse.json(
      { error: 'Failed to connect to slide generator service' },
      { status: 503 }
    );
  }
}
