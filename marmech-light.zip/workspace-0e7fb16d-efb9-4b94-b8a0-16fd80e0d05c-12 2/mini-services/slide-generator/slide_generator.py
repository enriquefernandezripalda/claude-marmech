"""
BTS MarTech Slide Generator Module
====================================

This module provides style-preserving text injection into PowerPoint templates.
The CRITICAL requirement is to NEVER override template typography, colors, or alignment.

Author: BTS MarTech Team
"""

import os
import copy
from dataclasses import dataclass
from typing import Optional, Dict, Any, List, Tuple, Union
from enum import Enum

from pptx import Presentation
from pptx.util import Pt, Inches
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE_TYPE, PP_PLACEHOLDER
from pptx.enum.text import PP_PARAGRAPH_ALIGNMENT
from pptx.oxml.ns import nsmap


class PlaceholderType(Enum):
    """Enum for common placeholder types in PowerPoint."""
    TITLE = PP_PLACEHOLDER.TITLE
    SUBTITLE = PP_PLACEHOLDER.SUBTITLE
    BODY = PP_PLACEHOLDER.BODY
    CENTER_TITLE = PP_PLACEHOLDER.CENTER_TITLE
    # Note: CENTER_SUBTITLE may not exist in all python-pptx versions
    # We handle this dynamically in the code


@dataclass
class TextStyle:
    """
    Captures the complete style of text from a placeholder.
    This is used to preserve formatting when injecting new text.
    """
    font_name: Optional[str] = None
    font_size: Optional[Pt] = None
    font_bold: Optional[bool] = None
    font_italic: Optional[bool] = None
    font_underline: Optional[bool] = None
    font_color: Optional[RGBColor] = None
    alignment: Optional[PP_PARAGRAPH_ALIGNMENT] = None
    line_spacing: Optional[float] = None
    space_before: Optional[Pt] = None
    space_after: Optional[Pt] = None

    def __repr__(self) -> str:
        return (
            f"TextStyle(font={self.font_name}, size={self.font_size}, "
            f"bold={self.font_bold}, italic={self.font_italic}, "
            f"color={self.font_color}, align={self.alignment})"
        )


@dataclass
class SlideContent:
    """
    Data class representing content to inject into a slide.
    Supports both simple strings and styled content with custom fonts/sizes.
    """
    title: Optional[str] = None
    title_style: Optional[Dict[str, Any]] = None
    subtitle: Optional[str] = None
    subtitle_style: Optional[Dict[str, Any]] = None
    body_paragraphs: Optional[List[str]] = None
    body: Optional[str] = None
    body_style: Optional[Dict[str, Any]] = None
    custom_placeholders: Optional[Dict[int, Dict[str, Any]]] = None  # {idx: {'text': str, 'style': dict}}


@dataclass
class InjectionResult:
    """
    Result of a text injection operation.
    """
    success: bool
    message: str
    modified_placeholders: List[str]
    errors: List[str]
    output_path: Optional[str] = None


class SlideGeneratorError(Exception):
    """Base exception for slide generator errors."""
    pass


class TemplateNotFoundError(SlideGeneratorError):
    """Raised when template file cannot be found."""
    pass


class PlaceholderNotFoundError(SlideGeneratorError):
    """Raised when a target placeholder doesn't exist in the slide."""
    pass


class InvalidSlideIndexError(SlideGeneratorError):
    """Raised when an invalid slide index is provided."""
    pass


class BTSSlideGenerator:
    """
    BTS MarTech Slide Generator
    
    This class handles loading PowerPoint templates and injecting text
    while preserving all original formatting from the master template.
    
    CRITICAL DESIGN PRINCIPLES:
    ===========================
    1. NEVER use shape.text = "New Text" directly - this clears formatting
    2. ALWAYS read the existing style before modification
    3. ALWAYS use text_frame.paragraphs[0].runs[0] for text manipulation
    4. NEVER create new runs without copying style from existing runs
    5. NEVER override font properties that are defined in the master slide
    
    Usage:
    ------
    >>> generator = BTSSlideGenerator("bts_master_template.pptx")
    >>> result = generator.generate(
    ...     slide_index=0,
    ...     content=SlideContent(title="Q1 Report", body_paragraphs=["Content here"])
    ... )
    """

    def __init__(self, template_path: str):
        """
        Initialize the generator with a template file.
        
        Args:
            template_path: Path to the .pptx template file
            
        Raises:
            TemplateNotFoundError: If template file doesn't exist
        """
        self.template_path = template_path
        self._presentation: Optional[Presentation] = None
        self._validate_template()

    def _validate_template(self) -> None:
        """Validate that the template file exists and is readable."""
        if not os.path.exists(self.template_path):
            raise TemplateNotFoundError(
                f"Template file not found: {self.template_path}"
            )
        if not self.template_path.endswith('.pptx'):
            raise SlideGeneratorError(
                f"Invalid template format. Expected .pptx file: {self.template_path}"
            )

    def load_template(self) -> Presentation:
        """
        Load the PowerPoint template file.
        
        Returns:
            Presentation: The loaded PowerPoint presentation object
            
        Note:
            This loads the template WITHOUT modifying the original file.
            All modifications are done in memory.
        """
        try:
            self._presentation = Presentation(self.template_path)
            return self._presentation
        except Exception as e:
            raise SlideGeneratorError(
                f"Failed to load template: {str(e)}"
            ) from e

    def get_slide_count(self) -> int:
        """Return the number of slides in the template."""
        if self._presentation is None:
            self.load_template()
        return len(self._presentation.slides)

    def get_slide_placeholders(self, slide_index: int) -> Dict[int, Dict[str, Any]]:
        """
        Get information about all placeholders in a specific slide.
        
        Args:
            slide_index: Zero-based index of the slide
            
        Returns:
            Dict mapping placeholder indices to their info
        """
        if self._presentation is None:
            self.load_template()
        
        if slide_index < 0 or slide_index >= len(self._presentation.slides):
            raise InvalidSlideIndexError(
                f"Invalid slide index {slide_index}. "
                f"Template has {len(self._presentation.slides)} slides."
            )
        
        slide = self._presentation.slides[slide_index]
        placeholders = {}
        
        for shape in slide.shapes:
            if shape.has_text_frame and shape.is_placeholder:
                ph_type = shape.placeholder_format.type
                ph_idx = shape.placeholder_format.idx
                placeholders[ph_idx] = {
                    'type': str(ph_type),
                    'type_enum': ph_type,
                    'name': shape.name,
                    'position': (shape.left, shape.top),
                    'size': (shape.width, shape.height),
                    'current_text': shape.text_frame.text if shape.has_text_frame else ''
                }
        
        return placeholders

    def _extract_run_style(self, run) -> TextStyle:
        """
        Extract complete style information from a text run.
        
        This is the CORE function for style preservation.
        It reads ALL formatting properties from an existing run.
        
        Args:
            run: A python-pptx TextRun object
            
        Returns:
            TextStyle object containing all formatting properties
        """
        style = TextStyle()
        
        # Font properties
        font = run.font
        
        # Font name (typeface)
        if font.name:
            style.font_name = font.name
        
        # Font size - convert to Pt if it's set
        if font.size:
            style.font_size = font.size
        
        # Font styling
        if font.bold is not None:
            style.font_bold = font.bold
        if font.italic is not None:
            style.font_italic = font.italic
        if font.underline is not None:
            style.font_underline = font.underline
        
        # Font color - this is CRITICAL for brand compliance
        # Handle both RGB colors and theme colors
        if font.color and font.color.type is not None:
            try:
                # Check if it's an RGB color
                if hasattr(font.color, 'rgb') and font.color.rgb:
                    style.font_color = font.color.rgb
                # Check if it's a theme color - resolve it
                elif hasattr(font.color, 'theme_color') and font.color.theme_color is not None:
                    # Theme colors need to be resolved from the theme
                    # We'll try to get the actual RGB value
                    try:
                        rgb_val = font.color.rgb  # This might work after accessing theme_color
                        if rgb_val:
                            style.font_color = rgb_val
                    except Exception:
                        # If we can't resolve theme color, we'll preserve it differently
                        # Store the theme color index for later use
                        style.font_color = None  # Will fall back to template style
                        pass
            except Exception:
                # Color might be theme-based, which is fine
                pass
        
        return style

    def _extract_paragraph_style(self, paragraph) -> TextStyle:
        """
        Extract paragraph-level style information.
        
        This includes BOTH paragraph formatting (alignment, spacing) AND
        paragraph-level font properties which can serve as defaults for runs.
        
        Args:
            paragraph: A python-pptx Paragraph object
            
        Returns:
            TextStyle object with paragraph-level properties
        """
        style = TextStyle()
        
        # Alignment - CRITICAL for brand compliance
        if paragraph.alignment is not None:
            style.alignment = paragraph.alignment
        
        # Line spacing
        if paragraph.line_spacing is not None:
            style.line_spacing = paragraph.line_spacing
        
        # Space before/after paragraphs
        if paragraph.space_before is not None:
            style.space_before = paragraph.space_before
        if paragraph.space_after is not None:
            style.space_after = paragraph.space_after
        
        # IMPORTANT: Also check paragraph-level font properties
        # These serve as defaults when run-level properties are None
        # This is needed for templates where fonts were set at paragraph level
        try:
            para_font = paragraph.font
            if para_font.name:
                style.font_name = para_font.name
            if para_font.size:
                style.font_size = para_font.size
            if para_font.bold is not None:
                style.font_bold = para_font.bold
            if para_font.italic is not None:
                style.font_italic = para_font.italic
            if para_font.underline is not None:
                style.font_underline = para_font.underline
            # Check paragraph-level font color
            if para_font.color and hasattr(para_font.color, 'rgb') and para_font.color.rgb:
                style.font_color = para_font.color.rgb
        except Exception:
            pass
        
        return style

    def _extract_placeholder_style(self, shape) -> TextStyle:
        """
        Extract the complete style from a placeholder shape.
        
        This combines run-level and paragraph-level styles.
        It prioritizes existing content styles, then falls back to
        placeholder defaults.
        
        CRITICAL: We check BOTH run-level AND paragraph-level fonts.
        Run-level takes priority, but paragraph-level serves as fallback.
        This handles templates where fonts might be set at either level.
        
        Args:
            shape: A placeholder shape with text_frame
            
        Returns:
            Combined TextStyle from the placeholder
        """
        combined_style = TextStyle()
        
        if not shape.has_text_frame:
            return combined_style
        
        text_frame = shape.text_frame
        
        # Get paragraph-level style from first paragraph
        # This includes paragraph-level font properties as fallback
        if text_frame.paragraphs:
            para_style = self._extract_paragraph_style(text_frame.paragraphs[0])
            combined_style.alignment = para_style.alignment
            combined_style.line_spacing = para_style.line_spacing
            combined_style.space_before = para_style.space_before
            combined_style.space_after = para_style.space_after
            
            # IMPORTANT: Start with paragraph-level font as defaults
            # These will be overridden by run-level styles if available
            combined_style.font_name = para_style.font_name
            combined_style.font_size = para_style.font_size
            combined_style.font_bold = para_style.font_bold
            combined_style.font_italic = para_style.font_italic
            combined_style.font_underline = para_style.font_underline
            combined_style.font_color = para_style.font_color
            
            # Get run-level style from first run with formatting
            # Run-level takes priority over paragraph-level
            for paragraph in text_frame.paragraphs:
                if paragraph.runs:
                    for run in paragraph.runs:
                        run_style = self._extract_run_style(run)
                        # Merge styles - run-level overrides paragraph-level
                        if run_style.font_name:
                            combined_style.font_name = run_style.font_name
                        if run_style.font_size:
                            combined_style.font_size = run_style.font_size
                        if run_style.font_bold is not None:
                            combined_style.font_bold = run_style.font_bold
                        if run_style.font_italic is not None:
                            combined_style.font_italic = run_style.font_italic
                        if run_style.font_underline is not None:
                            combined_style.font_underline = run_style.font_underline
                        if run_style.font_color:
                            combined_style.font_color = run_style.font_color
                        break
                    break
        
        # If still no font properties, try to get default placeholder style
        if not any([combined_style.font_name, combined_style.font_size]):
            default_style = self._get_placeholder_default_style(shape)
            if default_style.font_name:
                combined_style.font_name = default_style.font_name
            if default_style.font_size:
                combined_style.font_size = default_style.font_size
            if default_style.font_bold is not None:
                combined_style.font_bold = default_style.font_bold
            if default_style.font_color:
                combined_style.font_color = default_style.font_color
        
        return combined_style

    def _get_placeholder_default_style(self, shape) -> TextStyle:
        """
        Get the default style from a placeholder when no text exists.
        
        This handles the case where a placeholder is empty or has no runs.
        We need to access the placeholder's default text properties.
        
        Args:
            shape: A placeholder shape
            
        Returns:
            Default TextStyle for the placeholder
        """
        style = TextStyle()
        
        try:
            # Access the placeholder's text frame
            if not shape.has_text_frame:
                return style
            
            text_frame = shape.text_frame
            
            # Try to get default paragraph properties
            # These are stored in the p:txBody element
            if hasattr(text_frame, '_txBody') and text_frame._txBody is not None:
                txBody = text_frame._txBody
                
                # Get default paragraph properties (p:lstStyle)
                lstStyle = txBody.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}lstStyle')
                if lstStyle is not None:
                    # Get defPPr (default paragraph properties)
                    defPPr = lstStyle.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}defPPr')
                    if defPPr is not None:
                        # Extract alignment
                        algn = defPPr.get('algn')
                        if algn:
                            style.alignment = self._convert_alignment_from_xml(algn)
            
            # If we have paragraphs, check for default run properties
            if text_frame.paragraphs:
                para = text_frame.paragraphs[0]
                
                # Check if paragraph has default run properties
                # This is in the p:rPr element within p:pPr
                if hasattr(para, '_p') and para._p is not None:
                    pPr = para._p.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}pPr')
                    if pPr is not None:
                        defRPr = pPr.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}defRPr')
                        if defRPr is not None:
                            # Extract font properties from defRPr
                            style.font_name = defRPr.get('typeface')
                            sz = defRPr.get('sz')
                            if sz:
                                # Size is in hundredths of a point
                                style.font_size = Pt(int(sz) / 100)
                            
                            b = defRPr.get('b')
                            if b:
                                style.font_bold = b == '1'
                            
                            i = defRPr.get('i')
                            if i:
                                style.font_italic = i == '1'
        
        except Exception:
            # If we can't extract defaults, return empty style
            pass
        
        return style

    def _convert_alignment_from_xml(self, algn: str):
        """Convert XML alignment string to PP_PARAGRAPH_ALIGNMENT enum."""
        alignment_map = {
            'l': PP_PARAGRAPH_ALIGNMENT.LEFT,
            'r': PP_PARAGRAPH_ALIGNMENT.RIGHT,
            'ctr': PP_PARAGRAPH_ALIGNMENT.CENTER,
            'just': PP_PARAGRAPH_ALIGNMENT.JUSTIFY,
            'dist': PP_PARAGRAPH_ALIGNMENT.DISTRIBUTE,
        }
        return alignment_map.get(algn)

    def _apply_style_to_run(self, run, style: TextStyle, placeholder_type=None) -> None:
        """
        Apply a TextStyle to a text run.
        
        CRITICAL: This applies properties that are defined in the style.
        If no style is defined, BTS brand defaults are applied.
        
        Args:
            run: A python-pptx TextRun object
            style: TextStyle to apply
            placeholder_type: Optional placeholder type for default styling
        """
        font = run.font
        
        # BTS Brand Defaults (applied when no style is provided)
        BTS_DEFAULT_FONT = 'Arial'
        BTS_NAVY = RGBColor(0x0A, 0x1A, 0x5F)
        BTS_HEADING = RGBColor(0x1A, 0x2A, 0x5F)
        BTS_BODY = RGBColor(0x33, 0x33, 0x33)
        
        # Check if we have any style to apply
        has_style = any([
            style.font_name,
            style.font_size,
            style.font_bold is not None,
            style.font_italic is not None,
            style.font_underline is not None,
            style.font_color
        ])
        
        # Apply font name
        if style.font_name:
            font.name = style.font_name
        elif not has_style:
            # Apply BTS default
            font.name = BTS_DEFAULT_FONT
        
        # Apply font size
        if style.font_size:
            font.size = style.font_size
        elif not has_style:
            # Apply BTS default based on placeholder type
            if placeholder_type == PP_PLACEHOLDER.TITLE or placeholder_type == PP_PLACEHOLDER.CENTER_TITLE:
                font.size = Pt(36)
            elif placeholder_type == PP_PLACEHOLDER.SUBTITLE:
                font.size = Pt(24)
            else:
                font.size = Pt(18)
        
        # Apply font styling
        if style.font_bold is not None:
            font.bold = style.font_bold
        elif not has_style:
            # Default bold for titles
            if placeholder_type in [PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.CENTER_TITLE]:
                font.bold = True
        
        if style.font_italic is not None:
            font.italic = style.font_italic
        if style.font_underline is not None:
            font.underline = style.font_underline
        
        # Apply font color - CRITICAL for brand compliance
        if style.font_color:
            font.color.rgb = style.font_color
        elif not has_style:
            # Apply BTS brand color based on placeholder type
            if placeholder_type in [PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.CENTER_TITLE]:
                font.color.rgb = BTS_NAVY
            elif placeholder_type == PP_PLACEHOLDER.SUBTITLE:
                font.color.rgb = BTS_HEADING
            else:
                font.color.rgb = BTS_BODY

    def _apply_style_to_paragraph(self, paragraph, style: TextStyle) -> None:
        """
        Apply paragraph-level style.
        
        Args:
            paragraph: A python-pptx Paragraph object
            style: TextStyle with paragraph properties
        """
        if style.alignment is not None:
            paragraph.alignment = style.alignment
        
        if style.line_spacing is not None:
            paragraph.line_spacing = style.line_spacing
        
        if style.space_before is not None:
            paragraph.space_before = style.space_before
        
        if style.space_after is not None:
            paragraph.space_after = style.space_after

    def _style_dict_to_text_style(self, style_dict: Optional[Dict[str, Any]]) -> Optional[TextStyle]:
        """
        Convert a style dictionary from the API to a TextStyle object.
        
        Args:
            style_dict: Dictionary with fontFamily, fontSize, bold, italic, color
            
        Returns:
            TextStyle object or None
        """
        if not style_dict:
            return None
        
        style = TextStyle()
        
        if style_dict.get('fontFamily'):
            style.font_name = style_dict['fontFamily']
        
        if style_dict.get('fontSize'):
            style.font_size = Pt(style_dict['fontSize'])
        
        if style_dict.get('bold') is not None:
            style.font_bold = style_dict['bold']
        
        if style_dict.get('italic') is not None:
            style.font_italic = style_dict['italic']
        
        # Handle color - convert hex string to RGBColor
        if style_dict.get('color'):
            try:
                color_hex = style_dict['color'].lstrip('#')
                r = int(color_hex[0:2], 16)
                g = int(color_hex[2:4], 16)
                b = int(color_hex[4:6], 16)
                style.font_color = RGBColor(r, g, b)
            except Exception:
                pass  # If color parsing fails, skip it
        
        return style

    def _inject_text_preserve_style(
        self, 
        shape, 
        text: str, 
        is_multi_paragraph: bool = False,
        custom_style: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        THE GOLDEN METHOD: Inject text while preserving ALL formatting.
        
        This is the CORE function that ensures BTS brand compliance.
        
        METHOD EXPLANATION:
        ===================
        1. Extract the COMPLETE style from existing placeholder content
        2. Store paragraph-level properties (alignment, spacing)
        3. Store run-level properties (font, size, color, style)
        4. Clear existing text content
        5. Add new text using the preserved style (or BTS defaults if empty)
        
        WHY NOT shape.text = "New Text"?
        --------------------------------
        The `shape.text` setter completely replaces the text_frame content,
        destroying all formatting information including:
        - Font family
        - Font size
        - Font color (CRITICAL for brand)
        - Text alignment
        - Paragraph spacing
        
        OUR APPROACH:
        -------------
        1. Access shape.text_frame directly
        2. Work with paragraphs and runs at the lowest level
        3. Preserve style before ANY modifications
        4. Apply preserved style to new content
        5. If no style found, apply BTS brand defaults
        6. If custom_style provided, override specific properties
        
        Args:
            shape: Placeholder shape to inject text into
            text: New text content
            is_multi_paragraph: Whether to split text into multiple paragraphs
            custom_style: Optional dict with fontFamily, fontSize, bold, italic to override
            
        Returns:
            True if injection was successful
        """
        if not shape.has_text_frame:
            return False
        
        text_frame = shape.text_frame
        
        # Get placeholder type for default styling
        placeholder_type = None
        try:
            if shape.is_placeholder:
                placeholder_type = shape.placeholder_format.type
        except Exception:
            pass
        
        # STEP 1: Extract the complete style BEFORE any modifications
        # This is the CRITICAL step for brand compliance
        preserved_style = self._extract_placeholder_style(shape)
        
        # STEP 1b: Apply custom style overrides if provided
        if custom_style:
            custom_text_style = self._style_dict_to_text_style(custom_style)
            if custom_text_style:
                # Override preserved style with custom values
                if custom_text_style.font_name:
                    preserved_style.font_name = custom_text_style.font_name
                if custom_text_style.font_size:
                    preserved_style.font_size = custom_text_style.font_size
                if custom_text_style.font_bold is not None:
                    preserved_style.font_bold = custom_text_style.font_bold
                if custom_text_style.font_italic is not None:
                    preserved_style.font_italic = custom_text_style.font_italic
                # CRITICAL: Apply custom color if provided
                if custom_text_style.font_color:
                    preserved_style.font_color = custom_text_style.font_color
        
        # STEP 2: Handle the text content
        if is_multi_paragraph and '\n' in text:
            # Split into multiple paragraphs
            paragraphs_text = text.split('\n')
            
            # Clear all existing paragraphs first
            while len(text_frame.paragraphs) > 1:
                p = text_frame.paragraphs[-1]._p
                p.getparent().remove(p)
            
            # Process each paragraph
            for i, para_text in enumerate(paragraphs_text):
                if i == 0:
                    # Use existing first paragraph
                    paragraph = text_frame.paragraphs[0]
                else:
                    # Add new paragraph
                    paragraph = text_frame.add_paragraph()
                
                # Clear existing runs
                while len(paragraph.runs) > 1:
                    # Remove extra runs
                    r = paragraph.runs[-1]._r
                    r.getparent().remove(r)
                
                # Create or use existing run
                if paragraph.runs:
                    run = paragraph.runs[0]
                else:
                    run = paragraph.add_run()
                
                # Set the text
                run.text = para_text
                
                # Apply preserved style (with BTS defaults if empty)
                self._apply_style_to_run(run, preserved_style, placeholder_type)
                self._apply_style_to_paragraph(paragraph, preserved_style)
        else:
            # Single paragraph - simpler case
            paragraph = text_frame.paragraphs[0]
            
            # Clear all but first run
            while len(paragraph.runs) > 1:
                r = paragraph.runs[-1]._r
                r.getparent().remove(r)
            
            # Use existing run or create new one
            if paragraph.runs:
                run = paragraph.runs[0]
            else:
                run = paragraph.add_run()
            
            # STEP 3: Set the new text
            run.text = text
            
            # STEP 4: Apply preserved style to ensure brand compliance
            # Pass placeholder type for BTS brand defaults if style is empty
            self._apply_style_to_run(run, preserved_style, placeholder_type)
            self._apply_style_to_paragraph(paragraph, preserved_style)
        
        return True

    def _find_placeholder_by_type(
        self, 
        slide, 
        placeholder_type: PP_PLACEHOLDER
    ) -> Optional[Any]:
        """
        Find a placeholder by its type on a slide.
        
        Args:
            slide: A python-pptx Slide object
            placeholder_type: The type of placeholder to find
            
        Returns:
            The placeholder shape if found, None otherwise
        """
        for shape in slide.shapes:
            if shape.is_placeholder:
                try:
                    if shape.placeholder_format.type == placeholder_type:
                        return shape
                except Exception:
                    continue
        return None

    def _find_placeholder_by_idx(self, slide, idx: int) -> Optional[Any]:
        """
        Find a placeholder by its index on a slide.
        
        Args:
            slide: A python-pptx Slide object
            idx: The placeholder index to find
            
        Returns:
            The placeholder shape if found, None otherwise
        """
        for shape in slide.shapes:
            if shape.is_placeholder:
                try:
                    if shape.placeholder_format.idx == idx:
                        return shape
                except Exception:
                    continue
        return None

    def generate(
        self,
        slide_index: int,
        content: SlideContent,
        output_path: Optional[str] = None
    ) -> InjectionResult:
        """
        Generate a presentation by injecting content into a template slide.
        
        This is the main entry point for slide generation.
        
        Args:
            slide_index: Zero-based index of the slide to modify
            content: SlideContent object with text to inject
            output_path: Path to save the output file (optional)
            
        Returns:
            InjectionResult with success status and details
        """
        errors = []
        modified = []
        
        # Load template if not already loaded
        if self._presentation is None:
            try:
                self.load_template()
            except Exception as e:
                return InjectionResult(
                    success=False,
                    message=f"Failed to load template: {str(e)}",
                    modified_placeholders=[],
                    errors=[str(e)]
                )
        
        # Validate slide index
        if slide_index < 0 or slide_index >= len(self._presentation.slides):
            return InjectionResult(
                success=False,
                message=f"Invalid slide index {slide_index}",
                modified_placeholders=[],
                errors=[f"Slide index must be between 0 and {len(self._presentation.slides) - 1}"]
            )
        
        slide = self._presentation.slides[slide_index]
        
        # Inject Title
        if content.title is not None:
            title_shape = self._find_placeholder_by_type(slide, PP_PLACEHOLDER.TITLE)
            if title_shape:
                if self._inject_text_preserve_style(title_shape, content.title, custom_style=content.title_style):
                    modified.append("title")
            else:
                # Try center title
                title_shape = self._find_placeholder_by_type(slide, PP_PLACEHOLDER.CENTER_TITLE)
                if title_shape:
                    if self._inject_text_preserve_style(title_shape, content.title, custom_style=content.title_style):
                        modified.append("title (center)")
                else:
                    errors.append("Title placeholder not found on slide")
        
        # Inject Subtitle
        if content.subtitle is not None:
            subtitle_shape = self._find_placeholder_by_type(slide, PP_PLACEHOLDER.SUBTITLE)
            if subtitle_shape:
                if self._inject_text_preserve_style(subtitle_shape, content.subtitle, custom_style=content.subtitle_style):
                    modified.append("subtitle")
            else:
                # Try CENTER_SUBTITLE if it exists
                try:
                    center_subtitle_type = getattr(PP_PLACEHOLDER, 'CENTER_SUBTITLE', None)
                    if center_subtitle_type:
                        subtitle_shape = self._find_placeholder_by_type(slide, center_subtitle_type)
                        if subtitle_shape:
                            if self._inject_text_preserve_style(subtitle_shape, content.subtitle, custom_style=content.subtitle_style):
                                modified.append("subtitle (center)")
                            else:
                                errors.append("Subtitle placeholder not found on slide")
                        else:
                            errors.append("Subtitle placeholder not found on slide")
                    else:
                        errors.append("Subtitle placeholder not found on slide")
                except Exception:
                    errors.append("Subtitle placeholder not found on slide")
        
        # Inject Body Text (support both body_paragraphs and body with style)
        if content.body_paragraphs:
            body_shape = self._find_placeholder_by_type(slide, PP_PLACEHOLDER.BODY)
            if body_shape:
                body_text = '\n'.join(content.body_paragraphs)
                if self._inject_text_preserve_style(body_shape, body_text, is_multi_paragraph=True, custom_style=content.body_style):
                    modified.append("body")
            else:
                errors.append("Body placeholder not found on slide")
        elif content.body is not None:
            # Single body text with optional style
            body_shape = self._find_placeholder_by_type(slide, PP_PLACEHOLDER.BODY)
            if body_shape:
                if self._inject_text_preserve_style(body_shape, content.body, custom_style=content.body_style):
                    modified.append("body")
            else:
                errors.append("Body placeholder not found on slide")
        
        # Inject Custom Placeholders by Index (with optional styles)
        if content.custom_placeholders:
            for ph_idx, ph_data in content.custom_placeholders.items():
                shape = self._find_placeholder_by_idx(slide, ph_idx)
                if shape:
                    # ph_data is now a dict with 'text' and 'style' keys
                    text = ph_data.get('text', '') if isinstance(ph_data, dict) else ph_data
                    style = ph_data.get('style') if isinstance(ph_data, dict) else None
                    if self._inject_text_preserve_style(shape, text, custom_style=style):
                        modified.append(f"placeholder_{ph_idx}")
                else:
                    errors.append(f"Placeholder with index {ph_idx} not found on slide")
        
        # Save output
        if output_path:
            try:
                self._presentation.save(output_path)
            except Exception as e:
                errors.append(f"Failed to save presentation: {str(e)}")
        
        success = len(modified) > 0
        
        return InjectionResult(
            success=success,
            message=f"Successfully modified {len(modified)} placeholder(s)" if success else "No placeholders modified",
            modified_placeholders=modified,
            errors=errors,
            output_path=output_path if output_path and not errors else None
        )

    def generate_from_dict(
        self,
        slide_index: int,
        content_dict: Dict[str, Any],
        output_path: Optional[str] = None
    ) -> InjectionResult:
        """
        Convenience method to generate from a dictionary.
        
        Args:
            slide_index: Zero-based index of the slide
            content_dict: Dictionary with 'title', 'subtitle', 'body_paragraphs', etc.
            output_path: Path to save output
            
        Returns:
            InjectionResult
        """
        content = SlideContent(
            title=content_dict.get('title'),
            subtitle=content_dict.get('subtitle'),
            body_paragraphs=content_dict.get('body_paragraphs'),
            custom_placeholders=content_dict.get('custom_placeholders')
        )
        return self.generate(slide_index, content, output_path)


# Utility function for creating a simple BTS-branded template
def create_bts_master_template(output_path: str) -> str:
    """
    Create a basic BTS-branded PowerPoint template.
    
    This creates a simple template with proper placeholders for testing.
    In production, you would use a professionally designed template.
    
    CRITICAL: Font properties MUST be set at the RUN level, not paragraph level.
    Setting fonts at paragraph level (para.font.name) does NOT persist when
    the file is saved and reloaded. Always use run.font to ensure persistence.
    
    Args:
        output_path: Where to save the template
        
    Returns:
        Path to the created template
    """
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.dml.color import RGBColor
    
    # BTS Brand Colors
    BTS_NAVY = RGBColor(0x0A, 0x1A, 0x5F)
    BTS_CYAN = RGBColor(0x4A, 0xD8, 0xE0)
    BTS_MID_BLUE = RGBColor(0x00, 0x88, 0xC7)
    BTS_DARK_BLUE = RGBColor(0x00, 0x4E, 0x8C)
    BTS_HEADING = RGBColor(0x1A, 0x2A, 0x5F)
    BTS_BODY = RGBColor(0x33, 0x33, 0x33)
    
    prs = Presentation()
    prs.slide_width = Inches(13.333)  # 16:9 widescreen
    prs.slide_height = Inches(7.5)
    
    # Add a title slide layout
    slide_layout = prs.slide_layouts[0]  # Title slide layout
    slide = prs.slides.add_slide(slide_layout)
    
    # Style the title placeholder - MUST use run-level font setting
    if slide.shapes.title:
        title = slide.shapes.title
        title.text = "BTS Presentation"  # This creates a run
        # Get the run and set font at RUN level (critical for persistence!)
        run = title.text_frame.paragraphs[0].runs[0]
        run.font.name = "Arial"
        run.font.size = Pt(44)
        run.font.bold = True
        run.font.color.rgb = BTS_NAVY
    
    # Add a content slide
    content_layout = prs.slide_layouts[1]  # Title and content layout
    content_slide = prs.slides.add_slide(content_layout)
    
    if content_slide.shapes.title:
        title = content_slide.shapes.title
        title.text = "Content Title"  # This creates a run
        # Set font at RUN level
        run = title.text_frame.paragraphs[0].runs[0]
        run.font.name = "Arial"
        run.font.size = Pt(36)
        run.font.bold = True
        run.font.color.rgb = BTS_HEADING
    
    # Find and style body placeholder
    for shape in content_slide.shapes:
        if shape.has_text_frame and hasattr(shape, 'placeholder_format') and shape.is_placeholder:
            try:
                if shape.placeholder_format.type == PP_PLACEHOLDER.BODY:
                    shape.text = "Body content goes here"  # This creates a run
                    # Set font at RUN level
                    run = shape.text_frame.paragraphs[0].runs[0]
                    run.font.name = "Arial"
                    run.font.size = Pt(18)
                    run.font.color.rgb = BTS_BODY
            except Exception:
                continue
    
    prs.save(output_path)
    return output_path


@dataclass
class ImageInjectionResult:
    """
    Result of an image injection operation.
    """
    success: bool
    message: str
    placeholder_idx: Optional[int]
    image_path: Optional[str]
    original_dimensions: Optional[Tuple[int, int]]
    cropped_dimensions: Optional[Tuple[int, int]]
    placeholder_dimensions: Optional[Tuple[int, int]]
    errors: List[str]
    output_path: Optional[str] = None


class BTSImageSlideGenerator(BTSSlideGenerator):
    """
    Extended BTS Slide Generator with Image Support.
    
    This class extends BTSSlideGenerator to handle image insertion
    into picture placeholders while preserving aspect ratios.
    
    CRITICAL: Images are NEVER distorted. They are center-cropped
    to match placeholder aspect ratios exactly.
    
    Usage:
    ------
    >>> generator = BTSImageSlideGenerator("bts_master_template.pptx")
    >>> result = generator.inject_image(
    ...     slide_index=0,
    ...     placeholder_idx=15,
    ...     image_path="generated_image.png"
    ... )
    """
    
    def __init__(self, template_path: str):
        """
        Initialize the image-capable generator.
        
        Args:
            template_path: Path to the .pptx template file
        """
        super().__init__(template_path)
        from image_processor import BTSImageProcessor
        self._image_processor = BTSImageProcessor()
    
    def get_picture_placeholders(self, slide_index: int) -> Dict[int, Dict[str, Any]]:
        """
        Get all picture placeholders on a specific slide.
        
        Args:
            slide_index: Zero-based index of the slide
            
        Returns:
            Dict mapping placeholder indices to their info
        """
        if self._presentation is None:
            self.load_template()
        
        if slide_index < 0 or slide_index >= len(self._presentation.slides):
            raise InvalidSlideIndexError(
                f"Invalid slide index {slide_index}. "
                f"Template has {len(self._presentation.slides)} slides."
            )
        
        slide = self._presentation.slides[slide_index]
        picture_placeholders = {}
        
        for shape in slide.shapes:
            if shape.is_placeholder:
                try:
                    ph_format = shape.placeholder_format
                    # Check if this is a picture placeholder
                    # PP_PLACEHOLDER.PICTURE = 18
                    if ph_format.type == PP_PLACEHOLDER.PICTURE:
                        picture_placeholders[ph_format.idx] = {
                            'type': 'picture',
                            'name': shape.name,
                            'position': (shape.left, shape.top),
                            'size': (shape.width, shape.height),
                            'width_emu': shape.width,
                            'height_emu': shape.height,
                            'aspect_ratio': self._image_processor.calculate_emu_aspect_ratio(
                                shape.width, shape.height
                            )
                        }
                except Exception as e:
                    print(f"Error checking placeholder: {e}")
                    continue
        
        return picture_placeholders
    
    def get_all_placeholders(self, slide_index: int) -> Dict[int, Dict[str, Any]]:
        """
        Get all placeholders (text and picture) on a specific slide.
        
        Args:
            slide_index: Zero-based index of the slide
            
        Returns:
            Dict mapping placeholder indices to their info
        """
        if self._presentation is None:
            self.load_template()
        
        if slide_index < 0 or slide_index >= len(self._presentation.slides):
            raise InvalidSlideIndexError(
                f"Invalid slide index {slide_index}. "
                f"Template has {len(self._presentation.slides)} slides."
            )
        
        slide = self._presentation.slides[slide_index]
        all_placeholders = {}
        
        for shape in slide.shapes:
            if shape.is_placeholder:
                try:
                    ph_format = shape.placeholder_format
                    ph_type = ph_format.type
                    
                    # Determine placeholder type
                    type_name = 'unknown'
                    if ph_type == PP_PLACEHOLDER.TITLE:
                        type_name = 'title'
                    elif ph_type == PP_PLACEHOLDER.SUBTITLE:
                        type_name = 'subtitle'
                    elif ph_type == PP_PLACEHOLDER.BODY:
                        type_name = 'body'
                    elif ph_type == PP_PLACEHOLDER.CENTER_TITLE:
                        type_name = 'center_title'
                    elif ph_type == PP_PLACEHOLDER.PICTURE:
                        type_name = 'picture'
                    elif hasattr(shape, 'has_text_frame') and shape.has_text_frame:
                        type_name = 'text'
                    
                    all_placeholders[ph_format.idx] = {
                        'type': type_name,
                        'type_enum': ph_type,
                        'name': shape.name,
                        'position': (shape.left, shape.top),
                        'size': (shape.width, shape.height),
                        'width_emu': shape.width,
                        'height_emu': shape.height,
                        'current_text': shape.text_frame.text if shape.has_text_frame else ''
                    }
                    
                    # Add aspect ratio for picture placeholders
                    if type_name == 'picture':
                        all_placeholders[ph_format.idx]['aspect_ratio'] = \
                            self._image_processor.calculate_emu_aspect_ratio(
                                shape.width, shape.height
                            )
                except Exception as e:
                    print(f"Error checking placeholder: {e}")
                    continue
        
        return all_placeholders
    
    def _find_picture_placeholder(self, slide, placeholder_idx: int) -> Optional[Any]:
        """
        Find a picture placeholder by its index on a slide.
        
        Args:
            slide: A python-pptx Slide object
            placeholder_idx: The placeholder index to find
            
        Returns:
            The placeholder shape if found, None otherwise
        """
        for shape in slide.shapes:
            if shape.is_placeholder:
                try:
                    ph_format = shape.placeholder_format
                    if (ph_format.idx == placeholder_idx and 
                        ph_format.type == PP_PLACEHOLDER.PICTURE):
                        return shape
                except Exception:
                    continue
        return None
    
    def inject_image(
        self,
        slide_index: int,
        placeholder_idx: int,
        image_source: Union[str, bytes],
        output_path: Optional[str] = None,
        temp_crop_path: Optional[str] = None
    ) -> ImageInjectionResult:
        """
        Inject an image into a picture placeholder with aspect ratio preservation.
        
        THE GOLDEN METHOD FOR IMAGES:
        =============================
        1. Load the source image
        2. Read placeholder dimensions (width, height in EMU)
        3. Calculate placeholder aspect ratio
        4. Calculate image aspect ratio
        5. Center-crop image to match placeholder aspect ratio
        6. Insert cropped image into placeholder
        7. Image fills placeholder without distortion
        
        Args:
            slide_index: Zero-based index of the slide
            placeholder_idx: Index of the picture placeholder
            image_source: Path to image file or image bytes
            output_path: Path to save the output presentation
            temp_crop_path: Optional path to save the cropped image
            
        Returns:
            ImageInjectionResult with status and details
        """
        errors = []
        
        # Load template if not already loaded
        if self._presentation is None:
            try:
                self.load_template()
            except Exception as e:
                return ImageInjectionResult(
                    success=False,
                    message=f"Failed to load template: {str(e)}",
                    placeholder_idx=placeholder_idx,
                    image_path=None,
                    original_dimensions=None,
                    cropped_dimensions=None,
                    placeholder_dimensions=None,
                    errors=[str(e)]
                )
        
        # Validate slide index
        if slide_index < 0 or slide_index >= len(self._presentation.slides):
            return ImageInjectionResult(
                success=False,
                message=f"Invalid slide index {slide_index}",
                placeholder_idx=placeholder_idx,
                image_path=None,
                original_dimensions=None,
                cropped_dimensions=None,
                placeholder_dimensions=None,
                errors=[f"Slide index must be between 0 and {len(self._presentation.slides) - 1}"]
            )
        
        slide = self._presentation.slides[slide_index]
        
        # Find the picture placeholder
        placeholder = self._find_picture_placeholder(slide, placeholder_idx)
        if placeholder is None:
            return ImageInjectionResult(
                success=False,
                message=f"Picture placeholder {placeholder_idx} not found on slide",
                placeholder_idx=placeholder_idx,
                image_path=None,
                original_dimensions=None,
                cropped_dimensions=None,
                placeholder_dimensions=None,
                errors=[f"Picture placeholder with index {placeholder_idx} not found"]
            )
        
        # Get placeholder dimensions
        placeholder_width_emu = placeholder.width
        placeholder_height_emu = placeholder.height
        placeholder_dims = (int(placeholder_width_emu), int(placeholder_height_emu))
        
        try:
            # Load the source image
            source_image = self._image_processor.load_image(image_source)
            original_dims = source_image.size
            
            # Center-crop to match placeholder aspect ratio
            cropped_image = self._image_processor.center_crop_to_target(
                source_image,
                int(placeholder_width_emu),
                int(placeholder_height_emu),
                target_unit='emu'
            )
            cropped_dims = cropped_image.size
            
            # Save cropped image temporarily
            if temp_crop_path is None:
                import tempfile
                temp_dir = tempfile.gettempdir()
                temp_crop_path = os.path.join(temp_dir, f"cropped_{placeholder_idx}.png")
            
            self._image_processor.save_image(cropped_image, temp_crop_path)
            
            # Insert image into placeholder
            # Using the placeholder's position and size
            left = placeholder.left
            top = placeholder.top
            width = placeholder.width
            height = placeholder.height
            
            # Add the picture at the placeholder position
            # Note: We add a new picture shape and remove/hide the placeholder
            slide.shapes.add_picture(
                temp_crop_path,
                left,
                top,
                width,
                height
            )
            
            # Remove the original placeholder
            # Note: In python-pptx, we can't truly "replace" a placeholder
            # We add the image over it. For cleaner output, we could delete the placeholder.
            sp = placeholder._element
            sp.getparent().remove(sp)
            
            # Save output
            if output_path:
                try:
                    self._presentation.save(output_path)
                except Exception as e:
                    errors.append(f"Failed to save presentation: {str(e)}")
            
            return ImageInjectionResult(
                success=True,
                message=f"Image successfully inserted into placeholder {placeholder_idx}",
                placeholder_idx=placeholder_idx,
                image_path=temp_crop_path,
                original_dimensions=original_dims,
                cropped_dimensions=cropped_dims,
                placeholder_dimensions=placeholder_dims,
                errors=errors,
                output_path=output_path if output_path and not errors else None
            )
            
        except Exception as e:
            return ImageInjectionResult(
                success=False,
                message=f"Failed to process image: {str(e)}",
                placeholder_idx=placeholder_idx,
                image_path=None,
                original_dimensions=None,
                cropped_dimensions=None,
                placeholder_dimensions=placeholder_dims,
                errors=[str(e)]
            )
    
    def generate_with_images(
        self,
        slide_index: int,
        content: SlideContent,
        images: Optional[Dict[int, Union[str, bytes]]] = None,
        output_path: Optional[str] = None
    ) -> InjectionResult:
        """
        Generate a presentation with both text and images.
        
        Args:
            slide_index: Zero-based index of the slide
            content: SlideContent object with text
            images: Dict mapping placeholder indices to image sources
            output_path: Path to save output
            
        Returns:
            InjectionResult
        """
        # First, inject text content
        result = self.generate(slide_index, content, output_path)
        
        if not result.success:
            return result
        
        # Then inject images
        if images:
            for placeholder_idx, image_source in images.items():
                image_result = self.inject_image(
                    slide_index,
                    placeholder_idx,
                    image_source
                )
                if image_result.success:
                    result.modified_placeholders.append(f"image_{placeholder_idx}")
                else:
                    result.errors.append(f"Image placeholder {placeholder_idx}: {image_result.message}")
        
        # Save final output
        if output_path and result.modified_placeholders:
            try:
                self._presentation.save(output_path)
                result.output_path = output_path
            except Exception as e:
                result.errors.append(f"Failed to save presentation: {str(e)}")
        
        return result


if __name__ == "__main__":
    # Example usage and testing
    import sys
    
    print("BTS MarTech Slide Generator")
    print("=" * 40)
    
    # Create a test template
    template_path = "templates/bts_master_template.pptx"
    os.makedirs("templates", exist_ok=True)
    
    print(f"\nCreating BTS master template at: {template_path}")
    create_bts_master_template(template_path)
    
    # Test the generator
    print("\nInitializing generator...")
    generator = BTSSlideGenerator(template_path)
    
    print(f"Template loaded. Slide count: {generator.get_slide_count()}")
    
    # Get placeholder info
    print("\nPlaceholders on slide 1:")
    placeholders = generator.get_slide_placeholders(1)
    for idx, info in placeholders.items():
        print(f"  Index {idx}: {info['name']} ({info['type']})")
    
    # Test injection
    print("\nTesting text injection...")
    content = SlideContent(
        title="Q1 2026 Business Review",
        body_paragraphs=[
            "Key achievements this quarter",
            "Revenue growth of 15%",
            "Customer satisfaction at 98%"
        ]
    )
    
    result = generator.generate(
        slide_index=1,
        content=content,
        output_path="output/test_presentation.pptx"
    )
    
    print(f"\nResult: {result.message}")
    print(f"Modified: {result.modified_placeholders}")
    if result.errors:
        print(f"Errors: {result.errors}")
    print(f"Output: {result.output_path}")
