"""
BTS MarTech Image Processor Module
====================================

This module provides image processing utilities for PowerPoint slide generation.
The CRITICAL requirement is to NEVER distort, stretch, or squash images.

Core Principle: Center-Crop to match placeholder aspect ratio exactly.

Author: BTS MarTech Team
"""

import os
import io
import base64
import math
from dataclasses import dataclass
from typing import Optional, Tuple, Union
from pathlib import Path

from PIL import Image
from pptx.util import Emu, Inches
from pptx.dml.color import RGBColor


@dataclass
class AspectRatio:
    """
    Represents an aspect ratio as width:height.
    """
    width: int
    height: int
    
    @property
    def ratio(self) -> float:
        """Return the width/height ratio."""
        return self.width / self.height if self.height > 0 else 0
    
    @property
    def is_landscape(self) -> bool:
        """Return True if landscape orientation."""
        return self.width > self.height
    
    @property
    def is_portrait(self) -> bool:
        """Return True if portrait orientation."""
        return self.height > self.width
    
    @property
    def is_square(self) -> bool:
        """Return True if square."""
        return self.width == self.height
    
    def __repr__(self) -> str:
        return f"AspectRatio({self.width}:{self.height} = {self.ratio:.4f})"


@dataclass
class ImageDimensions:
    """
    Represents image dimensions in pixels.
    """
    width: int
    height: int
    
    @property
    def aspect_ratio(self) -> AspectRatio:
        """Calculate aspect ratio."""
        # Simplify to lowest terms
        gcd = math.gcd(self.width, self.height)
        return AspectRatio(self.width // gcd, self.height // gcd)
    
    @property
    def center(self) -> Tuple[int, int]:
        """Return center coordinates."""
        return (self.width // 2, self.height // 2)


@dataclass
class CropBox:
    """
    Represents a crop box (left, top, right, bottom).
    Used for PIL.Image.crop()
    """
    left: int
    top: int
    right: int
    bottom: int
    
    @property
    def width(self) -> int:
        return self.right - self.left
    
    @property
    def height(self) -> int:
        return self.bottom - self.top
    
    def to_tuple(self) -> Tuple[int, int, int, int]:
        return (self.left, self.top, self.right, self.bottom)


class ImageProcessingError(Exception):
    """Base exception for image processing errors."""
    pass


class AspectRatioMismatchError(ImageProcessingError):
    """Raised when aspect ratio cannot be matched."""
    pass


class BTSImageProcessor:
    """
    BTS MarTech Image Processor
    
    This class handles all image processing for PowerPoint slide generation.
    
    CRITICAL DESIGN PRINCIPLES:
    ===========================
    1. NEVER stretch or squash images to fit
    2. ALWAYS preserve original aspect ratio
    3. Use CENTER-CROP to match target dimensions
    4. Calculate crop math precisely to avoid floating point errors
    
    Usage:
    ------
    >>> processor = BTSImageProcessor()
    >>> # Crop image to match placeholder dimensions
    >>> cropped = processor.center_crop_to_target(image, target_width_emu, target_height_emu)
    >>> # Insert into slide
    >>> processor.insert_image_to_placeholder(slide, image_path, placeholder_idx)
    """
    
    # EMU (English Metric Units) conversion factors
    # 1 inch = 914400 EMU
    # 1 pixel at 96 DPI = 9525 EMU
    EMU_PER_INCH = 914400
    EMU_PER_PIXEL_96DPI = 9525
    DEFAULT_DPI = 96
    
    def __init__(self, default_dpi: int = 96):
        """
        Initialize the image processor.
        
        Args:
            default_dpi: Default DPI for pixel-to-EMU conversions
        """
        self.default_dpi = default_dpi
    
    # ========================
    # ASPECT RATIO CALCULATIONS
    # ========================
    
    def calculate_aspect_ratio(self, width: int, height: int) -> AspectRatio:
        """
        Calculate aspect ratio from dimensions.
        
        Args:
            width: Width in any unit
            height: Height in any unit
            
        Returns:
            AspectRatio object
        """
        gcd = math.gcd(width, height)
        return AspectRatio(width // gcd, height // gcd)
    
    def calculate_emu_aspect_ratio(self, width_emu: Emu, height_emu: Emu) -> AspectRatio:
        """
        Calculate aspect ratio from EMU dimensions.
        
        Args:
            width_emu: Width in English Metric Units
            height_emu: Height in English Metric Units
            
        Returns:
            AspectRatio object
        """
        return self.calculate_aspect_ratio(int(width_emu), int(height_emu))
    
    def calculate_pixel_aspect_ratio(self, width_px: int, height_px: int) -> AspectRatio:
        """
        Calculate aspect ratio from pixel dimensions.
        
        Args:
            width_px: Width in pixels
            height_px: Height in pixels
            
        Returns:
            AspectRatio object
        """
        return self.calculate_aspect_ratio(width_px, height_px)
    
    # ========================
    # CENTER CROP MATH (CRITICAL)
    # ========================
    
    def calculate_center_crop_box(
        self,
        source_width: int,
        source_height: int,
        target_width: int,
        target_height: int
    ) -> CropBox:
        """
        THE GOLDEN METHOD: Calculate center-crop box with NO distortion.
        
        This is the CORE function for aspect ratio preservation.
        
        MATHEMATICAL EXPLANATION:
        =========================
        Given:
        - Source image dimensions (Sw, Sh)
        - Target placeholder dimensions (Tw, Th)
        
        We need to crop the source so its aspect ratio matches the target.
        
        Step 1: Calculate both aspect ratios
            source_ratio = Sw / Sh
            target_ratio = Tw / Th
        
        Step 2: Determine crop strategy
            - If source_ratio > target_ratio: Source is "wider", crop WIDTH
            - If source_ratio < target_ratio: Source is "taller", crop HEIGHT
            - If equal: No crop needed (rare due to floating point)
        
        Step 3: Calculate new dimensions that preserve target aspect ratio
            Case A (crop width): new_width = Sh * target_ratio, new_height = Sh
            Case B (crop height): new_width = Sw, new_height = Sw / target_ratio
        
        Step 4: Calculate center crop box
            - Crop from center: left = (Sw - new_width) / 2
            - Ensure integer values for PIL
        
        WHY NOT RESIZE?
        ===============
        Resizing without cropping would require either:
        1. Stretching/squashing → DISTORTION (FORBIDDEN)
        2. Letterboxing/pillarboxing → Empty space in placeholder
        
        Center-cropping ensures:
        - No distortion (aspect ratio preserved)
        - No empty space (fills placeholder completely)
        - Aesthetically pleasing (center crop keeps main subject)
        
        Args:
            source_width: Source image width in pixels
            source_height: Source image height in pixels
            target_width: Target placeholder width in ANY unit
            target_height: Target placeholder height in ANY unit
            
        Returns:
            CropBox with (left, top, right, bottom) in pixels
        """
        # Step 1: Calculate aspect ratios
        source_ratio = source_width / source_height
        target_ratio = target_width / target_height
        
        # Tolerance for floating point comparison
        EPSILON = 0.0001
        
        # Step 2: Check if crop is needed
        if abs(source_ratio - target_ratio) < EPSILON:
            # Aspect ratios match - no crop needed
            return CropBox(0, 0, source_width, source_height)
        
        # Step 3: Calculate crop dimensions
        if source_ratio > target_ratio:
            # Source is WIDER than target - crop WIDTH
            # Keep full height, reduce width
            new_width = int(source_height * target_ratio)
            new_height = source_height
        else:
            # Source is TALLER than target - crop HEIGHT
            # Keep full width, reduce height
            new_width = source_width
            new_height = int(source_width / target_ratio)
        
        # Step 4: Calculate center crop position
        # Crop from center for aesthetic result
        left = (source_width - new_width) // 2
        top = (source_height - new_height) // 2
        right = left + new_width
        bottom = top + new_height
        
        return CropBox(left, top, right, bottom)
    
    def center_crop_to_target(
        self,
        image: Image.Image,
        target_width: int,
        target_height: int,
        target_unit: str = 'pixels'
    ) -> Image.Image:
        """
        Center-crop an image to match target dimensions.
        
        Args:
            image: PIL Image object
            target_width: Target width
            target_height: Target height
            target_unit: Unit of target dimensions ('pixels', 'emu', 'inches')
            
        Returns:
            Cropped PIL Image
        """
        source_width, source_height = image.size
        
        # Convert target dimensions to pixels if needed
        if target_unit == 'emu':
            target_width_px = int(target_width / self.EMU_PER_PIXEL_96DPI)
            target_height_px = int(target_height / self.EMU_PER_PIXEL_96DPI)
        elif target_unit == 'inches':
            target_width_px = int(target_width * self.default_dpi)
            target_height_px = int(target_height * self.default_dpi)
        else:
            target_width_px = target_width
            target_height_px = target_height
        
        # Calculate crop box
        crop_box = self.calculate_center_crop_box(
            source_width, source_height,
            target_width_px, target_height_px
        )
        
        # Perform the crop
        cropped_image = image.crop(crop_box.to_tuple())
        
        return cropped_image
    
    def center_crop_to_aspect_ratio(
        self,
        image: Image.Image,
        target_aspect_ratio: AspectRatio
    ) -> Image.Image:
        """
        Center-crop an image to match a specific aspect ratio.
        
        Args:
            image: PIL Image object
            target_aspect_ratio: Target AspectRatio object
            
        Returns:
            Cropped PIL Image
        """
        source_width, source_height = image.size
        
        crop_box = self.calculate_center_crop_box(
            source_width, source_height,
            target_aspect_ratio.width, target_aspect_ratio.height
        )
        
        return image.crop(crop_box.to_tuple())
    
    # ========================
    # IMAGE LOADING & SAVING
    # ========================
    
    def load_image(self, source: Union[str, Path, bytes, Image.Image]) -> Image.Image:
        """
        Load an image from various sources.
        
        Args:
            source: File path, bytes, or PIL Image
            
        Returns:
            PIL Image object
        """
        if isinstance(source, Image.Image):
            return source.copy()
        
        if isinstance(source, bytes):
            return Image.open(io.BytesIO(source))
        
        if isinstance(source, (str, Path)):
            return Image.open(source)
        
        raise ImageProcessingError(f"Unsupported image source type: {type(source)}")
    
    def load_image_from_base64(self, base64_string: str) -> Image.Image:
        """
        Load an image from a base64 string.
        
        Args:
            base64_string: Base64 encoded image data
            
        Returns:
            PIL Image object
        """
        # Remove data URL prefix if present
        if ',' in base64_string:
            base64_string = base64_string.split(',')[1]
        
        image_data = base64.b64decode(base64_string)
        return Image.open(io.BytesIO(image_data))
    
    def save_image(
        self,
        image: Image.Image,
        output_path: Union[str, Path],
        format: Optional[str] = None,
        quality: int = 95
    ) -> str:
        """
        Save an image to a file.
        
        Args:
            image: PIL Image object
            output_path: Output file path
            format: Image format (auto-detected from extension if None)
            quality: Quality for JPEG/PNG (1-100)
            
        Returns:
            Path to saved image
        """
        output_path = Path(output_path)
        
        # Auto-detect format from extension
        if format is None:
            format = output_path.suffix.lstrip('.').upper()
            if format == 'JPG':
                format = 'JPEG'
        
        # Convert RGBA to RGB for JPEG
        if format == 'JPEG' and image.mode in ('RGBA', 'LA', 'P'):
            # Create white background
            background = Image.new('RGB', image.size, (255, 255, 255))
            if image.mode == 'P':
                image = image.convert('RGBA')
            if image.mode in ('RGBA', 'LA'):
                background.paste(image, mask=image.split()[-1])
                image = background
        
        # Ensure directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Save with appropriate options
        save_kwargs = {}
        if format in ('JPEG', 'JPG'):
            save_kwargs['quality'] = quality
            save_kwargs['optimize'] = True
        elif format == 'PNG':
            save_kwargs['optimize'] = True
        
        image.save(output_path, format=format, **save_kwargs)
        
        return str(output_path)
    
    def image_to_bytes(
        self,
        image: Image.Image,
        format: str = 'PNG',
        quality: int = 95
    ) -> bytes:
        """
        Convert an image to bytes.
        
        Args:
            image: PIL Image object
            format: Output format ('PNG', 'JPEG')
            quality: Quality for JPEG
            
        Returns:
            Image as bytes
        """
        buffer = io.BytesIO()
        
        # Handle RGBA to RGB conversion for JPEG
        if format == 'JPEG' and image.mode in ('RGBA', 'LA', 'P'):
            background = Image.new('RGB', image.size, (255, 255, 255))
            if image.mode == 'P':
                image = image.convert('RGBA')
            if image.mode in ('RGBA', 'LA'):
                background.paste(image, mask=image.split()[-1])
                image = background
        
        save_kwargs = {}
        if format == 'JPEG':
            save_kwargs['quality'] = quality
        elif format == 'PNG':
            save_kwargs['optimize'] = True
        
        image.save(buffer, format=format, **save_kwargs)
        
        return buffer.getvalue()
    
    def image_to_base64(
        self,
        image: Image.Image,
        format: str = 'PNG',
        quality: int = 95,
        include_data_url: bool = False
    ) -> str:
        """
        Convert an image to base64 string.
        
        Args:
            image: PIL Image object
            format: Output format
            quality: Quality for JPEG
            include_data_url: Include data URL prefix
            
        Returns:
            Base64 encoded image string
        """
        image_bytes = self.image_to_bytes(image, format, quality)
        base64_string = base64.b64encode(image_bytes).decode('utf-8')
        
        if include_data_url:
            mime_type = 'image/png' if format == 'PNG' else 'image/jpeg'
            return f"data:{mime_type};base64,{base64_string}"
        
        return base64_string
    
    # ========================
    # UTILITY METHODS
    # ========================
    
    def get_image_info(self, image: Image.Image) -> dict:
        """
        Get information about an image.
        
        Args:
            image: PIL Image object
            
        Returns:
            Dictionary with image information
        """
        return {
            'width': image.width,
            'height': image.height,
            'aspect_ratio': self.calculate_pixel_aspect_ratio(image.width, image.height),
            'mode': image.mode,
            'format': image.format,
        }
    
    def resize_for_placeholder(
        self,
        image: Image.Image,
        placeholder_width_emu: Emu,
        placeholder_height_emu: Emu,
        maintain_quality: bool = True
    ) -> Image.Image:
        """
        Prepare image for placeholder insertion.
        
        This method:
        1. Center-crops to match placeholder aspect ratio
        2. Resizes to fill placeholder at appropriate resolution
        
        Args:
            image: PIL Image object
            placeholder_width_emu: Placeholder width in EMU
            placeholder_height_emu: Placeholder height in EMU
            maintain_quality: If True, resize up if needed for quality
            
        Returns:
            Processed PIL Image ready for insertion
        """
        # First, center-crop to match aspect ratio
        cropped = self.center_crop_to_target(
            image,
            int(placeholder_width_emu),
            int(placeholder_height_emu),
            target_unit='emu'
        )
        
        if maintain_quality:
            # Calculate target pixel dimensions at good DPI
            target_width_px = max(
                cropped.width,
                int(placeholder_width_emu / self.EMU_PER_PIXEL_96DPI)
            )
            target_height_px = max(
                cropped.height,
                int(placeholder_height_emu / self.EMU_PER_PIXEL_96DPI)
            )
            
            # Resize if current is smaller
            if cropped.width < target_width_px or cropped.height < target_height_px:
                cropped = cropped.resize(
                    (target_width_px, target_height_px),
                    Image.Resampling.LANCZOS
                )
        
        return cropped


# Singleton instance for convenience
_processor_instance: Optional[BTSImageProcessor] = None

def get_image_processor() -> BTSImageProcessor:
    """Get or create the singleton image processor instance."""
    global _processor_instance
    if _processor_instance is None:
        _processor_instance = BTSImageProcessor()
    return _processor_instance


# Convenience functions
def center_crop_image(
    image: Image.Image,
    target_width: int,
    target_height: int
) -> Image.Image:
    """Convenience function for center-cropping."""
    return get_image_processor().center_crop_to_target(
        image, target_width, target_height
    )


def load_and_crop_image(
    image_source: Union[str, bytes],
    target_width: int,
    target_height: int
) -> Image.Image:
    """Convenience function to load and crop an image."""
    processor = get_image_processor()
    image = processor.load_image(image_source)
    return processor.center_crop_to_target(image, target_width, target_height)


if __name__ == "__main__":
    # Test the image processor
    print("BTS MarTech Image Processor")
    print("=" * 40)
    
    # Test aspect ratio calculations
    processor = BTSImageProcessor()
    
    # Test case: 16:9 source, 4:3 target
    print("\nTest 1: 16:9 source to 4:3 target")
    crop_box = processor.calculate_center_crop_box(1920, 1080, 800, 600)
    print(f"  Source: 1920x1080 (16:9)")
    print(f"  Target aspect: 800:600 (4:3)")
    print(f"  Crop box: {crop_box}")
    print(f"  Cropped dimensions: {crop_box.width}x{crop_box.height}")
    print(f"  Cropped aspect ratio: {crop_box.width/crop_box.height:.4f}")
    
    # Test case: 4:3 source, 16:9 target
    print("\nTest 2: 4:3 source to 16:9 target")
    crop_box = processor.calculate_center_crop_box(800, 600, 1920, 1080)
    print(f"  Source: 800x600 (4:3)")
    print(f"  Target aspect: 1920:1080 (16:9)")
    print(f"  Crop box: {crop_box}")
    print(f"  Cropped dimensions: {crop_box.width}x{crop_box.height}")
    print(f"  Cropped aspect ratio: {crop_box.width/crop_box.height:.4f}")
    
    # Test case: Square source, 16:9 target
    print("\nTest 3: Square source to 16:9 target")
    crop_box = processor.calculate_center_crop_box(1024, 1024, 1920, 1080)
    print(f"  Source: 1024x1024 (1:1)")
    print(f"  Target aspect: 1920:1080 (16:9)")
    print(f"  Crop box: {crop_box}")
    print(f"  Cropped dimensions: {crop_box.width}x{crop_box.height}")
    print(f"  Cropped aspect ratio: {crop_box.width/crop_box.height:.4f}")
    
    print("\n✓ Image processor tests complete")
