/**
 * Slide Placeholders API Route
 * 
 * Gets placeholder information for a specific slide in a template.
 */

import { NextRequest, NextResponse } from 'next/server';

const SLIDE_SERVICE_PORT = 3002;

/**
 * GET /api/slides/placeholders/[templateId]/[slideIndex]
 * Get all placeholders on a specific slide
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ templateId: string; slideIndex: string }> }
) {
  try {
    const { templateId, slideIndex } = await params;
    
    const response = await fetch(
      `http://localhost:${SLIDE_SERVICE_PORT}/templates/${templateId}/slides/${slideIndex}/placeholders`,
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
      return NextResponse.json(
        { error: errorData.detail || 'Failed to get placeholders' },
        { status: response.status }
      );
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Placeholders fetch error:', error);
    return NextResponse.json(
      { error: 'Failed to connect to slide generator service' },
      { status: 503 }
    );
  }
}
