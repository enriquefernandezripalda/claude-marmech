'use client';

import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Upload, Loader2, AlertCircle, CheckCircle2, Download, FileSpreadsheet, Sparkles, BarChart3, Table, X } from 'lucide-react';

// BTS Brand Colors for chart palette
const BTS_CHART_PALETTE = [
  { name: 'Deep Navy', hex: '#0A1A5F' },
  { name: 'Mid Blue', hex: '#0088C7' },
  { name: 'Light Cyan', hex: '#4AD8E0' },
  { name: 'Dark Blue', hex: '#004E8C' },
  { name: 'Heading Navy', hex: '#1A2A5F' },
];

interface CSVData {
  headers: string[];
  rows: string[][];
  rawText: string;
}

interface ChartGenerateResult {
  success: boolean;
  message: string;
  chart_type?: string;
  series_count?: number;
  colors_applied?: string[];
  download_url?: string;
  errors: string[];
  ai_analysis?: string;
}

export function ChartStudioForm() {
  // CSV Data state
  const [csvData, setCsvData] = useState<CSVData | null>(null);
  const [csvFileName, setCsvFileName] = useState<string>('');
  
  // AI Prompt state
  const [aiPrompt, setAiPrompt] = useState<string>('');
  
  // UI state
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<ChartGenerateResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState<boolean>(false);

  // Parse CSV file
  const parseCSV = (text: string): CSVData => {
    const lines = text.trim().split('\n');
    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const rows = lines.slice(1).map(line => 
      line.split(',').map(cell => cell.trim().replace(/"/g, ''))
    );
    return { headers, rows, rawText: text };
  };

  // Handle file upload
  const handleFileUpload = useCallback((file: File) => {
    if (!file.name.endsWith('.csv')) {
      setError('Please upload a CSV file');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const parsed = parseCSV(text);
        setCsvData(parsed);
        setCsvFileName(file.name);
        setError(null);
        setResult(null);
      } catch (err) {
        setError('Failed to parse CSV file');
      }
    };
    reader.readAsText(file);
  }, []);

  // Drag and drop handlers
  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  }, [handleFileUpload]);

  // Clear CSV data
  const clearCsvData = () => {
    setCsvData(null);
    setCsvFileName('');
    setResult(null);
    setError(null);
  };

  // Generate chart with AI
  const handleGenerateChart = async () => {
    if (!csvData) {
      setError('Please upload a CSV file first');
      return;
    }

    if (!aiPrompt.trim()) {
      setError('Please describe what chart you want to create');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('/api/slides/charts/ai-generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          csv_data: csvData.rawText,
          csv_headers: csvData.headers,
          csv_rows: csvData.rows,
          user_prompt: aiPrompt,
        }),
      });

      const data: ChartGenerateResult = await response.json();
      
      if (!response.ok) {
        setError(data.message || 'Failed to generate chart');
      } else {
        setResult(data);
      }
    } catch (err) {
      console.error('Chart generation error:', err);
      setError('Failed to connect to chart generator service.');
    } finally {
      setLoading(false);
    }
  };

  // Download handler
  const handleDownload = () => {
    if (result?.download_url) {
      const filename = result.download_url.split('/').pop();
      window.open(`/api/slides/download/${filename}`, '_blank');
    }
  };

  return (
    <div className="space-y-6">
      {/* CSV Upload Section */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2" style={{ color: 'var(--bts-heading)' }}>
            <FileSpreadsheet className="h-5 w-5" style={{ color: 'var(--bts-mid-blue)' }} />
            Upload Data Source
          </CardTitle>
          <CardDescription style={{ color: 'var(--bts-body)' }}>
            Upload a CSV file with your data. The AI will analyze it and create professional charts.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!csvData ? (
            // Upload Area
            <div
              className={`relative rounded-lg border-2 border-dashed p-8 text-center transition-all ${
                dragActive 
                  ? 'border-blue-400 bg-blue-50' 
                  : 'border-gray-300 hover:border-gray-400'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <input
                type="file"
                accept=".csv"
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <Upload className="h-12 w-12 mx-auto mb-4 text-gray-400" />
              <p className="text-sm font-medium" style={{ color: 'var(--bts-heading)' }}>
                Drop your CSV file here, or click to browse
              </p>
              <p className="text-xs mt-2 text-gray-500">
                Supports .csv files with headers
              </p>
            </div>
          ) : (
            // CSV Preview
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="h-5 w-5" style={{ color: 'var(--bts-mid-blue)' }} />
                  <span className="font-medium text-sm" style={{ color: 'var(--bts-heading)' }}>
                    {csvFileName}
                  </span>
                  <Badge variant="secondary" className="text-xs">
                    {csvData.rows.length} rows × {csvData.headers.length} columns
                  </Badge>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearCsvData}
                  className="h-8 w-8 p-0"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {/* Data Preview Table */}
              <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: 'var(--bts-gray)' }}>
                <div className="overflow-x-auto max-h-64">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="bg-white/50">
                        {csvData.headers.map((header, i) => (
                          <th 
                            key={i} 
                            className="px-3 py-2 text-left font-medium whitespace-nowrap"
                            style={{ color: 'var(--bts-heading)' }}
                          >
                            {header}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {csvData.rows.slice(0, 10).map((row, rowIndex) => (
                        <tr key={rowIndex} className="border-t border-gray-200">
                          {row.map((cell, cellIndex) => (
                            <td 
                              key={cellIndex} 
                              className="px-3 py-2 whitespace-nowrap"
                              style={{ color: 'var(--bts-body)' }}
                            >
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {csvData.rows.length > 10 && (
                  <div className="px-3 py-2 text-xs text-center border-t" style={{ color: 'var(--bts-body)' }}>
                    ... and {csvData.rows.length - 10} more rows
                  </div>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* AI Prompt Section */}
      {csvData && (
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2" style={{ color: 'var(--bts-heading)' }}>
              <Sparkles className="h-5 w-5" style={{ color: 'var(--bts-cyan)' }} />
              Chart Instructions
            </CardTitle>
            <CardDescription style={{ color: 'var(--bts-body)' }}>
              Describe what chart you want to create from your data. Be specific about columns, chart type, and insights.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              placeholder="Example: Create a bar chart showing the revenue by quarter. Use the 'Quarter' column for x-axis and 'Revenue' column for values. Include a title 'Quarterly Revenue Analysis' and make it professional."
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              className="min-h-[120px] text-sm"
              rows={5}
            />
            
            {/* Quick Prompt Suggestions */}
            <div className="flex flex-wrap gap-2">
              <span className="text-xs" style={{ color: 'var(--bts-body)' }}>Quick prompts:</span>
              {[
                'Bar chart comparing all numeric columns',
                'Pie chart showing distribution',
                'Line chart for trends over time',
                'Create a summary dashboard',
              ].map((suggestion) => (
                <Button
                  key={suggestion}
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs"
                  onClick={() => setAiPrompt(suggestion)}
                >
                  {suggestion}
                </Button>
              ))}
            </div>

            {/* BTS Color Palette Preview */}
            <div className="rounded-lg p-4" style={{ backgroundColor: 'var(--bts-gray)' }}>
              <p className="text-xs font-medium mb-2" style={{ color: 'var(--bts-heading)' }}>
                BTS Brand Colors (Auto-Applied)
              </p>
              <div className="flex flex-wrap gap-3">
                {BTS_CHART_PALETTE.map((color, index) => (
                  <div key={color.name} className="flex items-center gap-2">
                    <div
                      className="h-5 w-5 rounded shadow-sm"
                      style={{ backgroundColor: color.hex }}
                    />
                    <span className="text-xs" style={{ color: 'var(--bts-body)' }}>
                      {index + 1}. {color.name}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error Display */}
      {error && (
        <div className="flex items-start gap-3 rounded-lg border border-red-200 bg-red-50 p-4">
          <AlertCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
          <div>
            <p className="font-medium text-red-800">Error</p>
            <p className="text-sm text-red-600">{error}</p>
          </div>
        </div>
      )}

      {/* Result Display */}
      {result && (
        <div className={`flex items-start gap-3 rounded-lg border p-4 ${
          result.success 
            ? 'border-green-200 bg-green-50' 
            : 'border-yellow-200 bg-yellow-50'
        }`}>
          {result.success ? (
            <CheckCircle2 className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="h-5 w-5 text-yellow-500 shrink-0 mt-0.5" />
          )}
          <div className="flex-1">
            <p className={`font-medium ${result.success ? 'text-green-800' : 'text-yellow-800'}`}>
              {result.success ? 'Chart Generated!' : 'Partial Success'}
            </p>
            <p className={`text-sm ${result.success ? 'text-green-600' : 'text-yellow-600'}`}>
              {result.message}
            </p>
            {result.ai_analysis && (
              <div className="mt-2 p-2 rounded bg-white/50 text-xs" style={{ color: 'var(--bts-body)' }}>
                <strong>AI Analysis:</strong> {result.ai_analysis}
              </div>
            )}
            {result.colors_applied && result.colors_applied.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {result.colors_applied.map((color, i) => (
                  <Badge key={i} variant="secondary" className="text-xs">
                    Series {i + 1}: {color}
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      {csvData && (
        <div className="flex flex-col gap-3 sm:flex-row">
          <Button
            onClick={handleGenerateChart}
            disabled={loading || !aiPrompt.trim()}
            className="flex-1 text-white"
            style={{ backgroundColor: 'var(--bts-navy)' }}
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                AI Generating Chart...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                Generate Chart with AI
              </>
            )}
          </Button>

          {result?.download_url && (
            <Button
              onClick={handleDownload}
              variant="outline"
              className="flex-1"
              style={{ borderColor: 'var(--bts-mid-blue)', color: 'var(--bts-mid-blue)' }}
            >
              <Download className="h-4 w-4 mr-2" />
              Download PPTX
            </Button>
          )}
        </div>
      )}

      {/* Info Card */}
      <div className="rounded-lg p-4 text-xs" style={{ backgroundColor: 'var(--bts-gray)', color: 'var(--bts-body)' }}>
        <p className="font-medium mb-1 flex items-center gap-2" style={{ color: 'var(--bts-heading)' }}>
          <BarChart3 className="h-4 w-4" />
          AI-Powered Chart Studio
        </p>
        <p>
          Upload your CSV data and describe the chart you need. The AI will analyze your data, 
          select the best chart type, and create a professional, brand-compliant visualization. 
          All charts use BTS brand colors and are fully editable in PowerPoint.
        </p>
      </div>
    </div>
  );
}

export default ChartStudioForm;
