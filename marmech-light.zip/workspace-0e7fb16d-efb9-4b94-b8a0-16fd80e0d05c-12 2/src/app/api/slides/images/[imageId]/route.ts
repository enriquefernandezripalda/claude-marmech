/**
 * Image Delete API Route
 * 
 * Delete an uploaded image by ID.
 */

import { NextRequest, NextResponse } from 'next/server';

const SLIDE_SERVICE_PORT = 3002;

/**
 * DELETE /api/slides/images/[imageId]
 * Delete an uploaded image
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ imageId: string }> }
) {
  try {
    const { imageId } = await params;
    
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/images/${imageId}`, {
      method: 'DELETE',
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
      return NextResponse.json(
        { error: errorData.detail || 'Delete failed' },
        { status: response.status }
      );
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Image delete error:', error);
    return NextResponse.json(
      { error: 'Failed to connect to image service' },
      { status: 503 }
    );
  }
}
