'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Upload, Loader2, AlertCircle, CheckCircle2, Trash2, FileText, 
  Image as ImageIcon, Download, FolderOpen, Settings, X
} from 'lucide-react';

interface Template {
  id: string;
  name: string;
  slide_count: number;
  created_at?: string;
}

interface UploadedImage {
  id: string;
  name: string;
  url: string;
  width: number;
  height: number;
}

interface TemplateManagerProps {
  onTemplateSelect?: (templateId: string) => void;
  onImageSelect?: (imageId: string, imageUrl: string) => void;
}

export function TemplateManager({ onTemplateSelect, onImageSelect }: TemplateManagerProps) {
  // Templates state
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [loadingTemplates, setLoadingTemplates] = useState<boolean>(true);

  // Images state
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [loadingImages, setLoadingImages] = useState<boolean>(true);

  // Upload states
  const [uploadingTemplate, setUploadingTemplate] = useState<boolean>(false);
  const [uploadingImage, setUploadingImage] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // File input refs
  const templateInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  // Fetch templates and images on mount
  useEffect(() => {
    fetchTemplates();
    fetchImages();
  }, []);

  const fetchTemplates = async () => {
    setLoadingTemplates(true);
    try {
      // Ensure default template exists
      await fetch('/api/slides/default-template');
      const response = await fetch('/api/slides/templates');
      if (response.ok) {
        const data = await response.json();
        setTemplates(data);
      }
    } catch (err) {
      console.error('Failed to fetch templates:', err);
      setError('Failed to load templates');
    } finally {
      setLoadingTemplates(false);
    }
  };

  const fetchImages = async () => {
    setLoadingImages(true);
    try {
      const response = await fetch('/api/slides/images/list');
      if (response.ok) {
        const data = await response.json();
        setImages(data.images || []);
      }
    } catch (err) {
      console.error('Failed to fetch images:', err);
      // Don't show error for images - they may not exist yet
    } finally {
      setLoadingImages(false);
    }
  };

  const handleTemplateUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file extension
    if (!file.name.toLowerCase().endsWith('.pptx')) {
      setError('Invalid file type. Only .pptx files are accepted.');
      return;
    }

    setUploadingTemplate(true);
    setError(null);
    setSuccess(null);

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('name', file.name.replace('.pptx', ''));

      const response = await fetch('/api/slides/templates/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || data.detail || 'Failed to upload template');
      } else {
        setSuccess(`Template "${data.name}" uploaded successfully with ${data.slide_count} slides`);
        await fetchTemplates();
      }
    } catch (err) {
      console.error('Upload error:', err);
      setError('Failed to upload template. Please try again.');
    } finally {
      setUploadingTemplate(false);
      // Reset input
      if (templateInputRef.current) {
        templateInputRef.current.value = '';
      }
    }
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setError('Invalid image type. Only JPG, PNG, and WebP are accepted.');
      return;
    }

    setUploadingImage(true);
    setError(null);
    setSuccess(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/slides/images/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || data.detail || 'Failed to upload image');
      } else {
        setSuccess(`Image uploaded successfully (${data.width}x${data.height})`);
        await fetchImages();
      }
    } catch (err) {
      console.error('Upload error:', err);
      setError('Failed to upload image. Please try again.');
    } finally {
      setUploadingImage(false);
      // Reset input
      if (imageInputRef.current) {
        imageInputRef.current.value = '';
      }
    }
  };

  const handleDeleteTemplate = async (templateId: string) => {
    if (!confirm('Are you sure you want to delete this template?')) return;

    try {
      const response = await fetch(`/api/slides/templates/${templateId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setSuccess('Template deleted successfully');
        await fetchTemplates();
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to delete template');
      }
    } catch (err) {
      console.error('Delete error:', err);
      setError('Failed to delete template');
    }
  };

  const handleDeleteImage = async (imageId: string) => {
    if (!confirm('Are you sure you want to delete this image?')) return;

    try {
      const response = await fetch(`/api/slides/images/${imageId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setSuccess('Image deleted successfully');
        await fetchImages();
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to delete image');
      }
    } catch (err) {
      console.error('Delete error:', err);
      setError('Failed to delete image');
    }
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return 'Unknown';
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="space-y-6">
      {/* Error/Success Messages */}
      {error && (
        <div className="flex items-start gap-3 rounded-lg border border-red-200 bg-red-50 p-4">
          <AlertCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm text-red-600">{error}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setError(null)}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      {success && (
        <div className="flex items-start gap-3 rounded-lg border border-green-200 bg-green-50 p-4">
          <CheckCircle2 className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm text-green-600">{success}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setSuccess(null)}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Template Upload Section */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2" style={{ color: 'var(--bts-heading)' }}>
            <FileText className="h-5 w-5" style={{ color: 'var(--bts-navy)' }} />
            Master Templates
          </CardTitle>
          <CardDescription style={{ color: 'var(--bts-body)' }}>
            Upload and manage PowerPoint master templates (.pptx only)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Upload Button */}
          <div className="flex items-center gap-4">
            <input
              ref={templateInputRef}
              type="file"
              accept=".pptx"
              onChange={handleTemplateUpload}
              className="hidden"
              id="template-upload"
            />
            <Button
              onClick={() => templateInputRef.current?.click()}
              disabled={uploadingTemplate}
              className="text-white"
              style={{ backgroundColor: 'var(--bts-navy)' }}
            >
              {uploadingTemplate ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Template
                </>
              )}
            </Button>
            <p className="text-xs" style={{ color: 'var(--bts-body)' }}>
              Accepted format: .pptx only (Max 50MB)
            </p>
          </div>

          <Separator />

          {/* Template List */}
          <div className="space-y-2">
            <Label style={{ color: 'var(--bts-heading)' }}>Available Templates</Label>
            {loadingTemplates ? (
              <div className="flex items-center gap-2 py-4" style={{ color: 'var(--bts-body)' }}>
                <Loader2 className="h-4 w-4 animate-spin" />
                Loading templates...
              </div>
            ) : templates.length === 0 ? (
              <p className="text-sm py-4" style={{ color: 'var(--bts-body)' }}>
                No templates uploaded yet.
              </p>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {templates.map((template) => (
                  <div
                    key={template.id}
                    className={`flex items-center justify-between p-3 rounded-lg border transition-colors cursor-pointer ${
                      selectedTemplate === template.id
                        ? 'border-[var(--bts-mid-blue)] bg-blue-50'
                        : 'border-gray-200 hover:bg-gray-50'
                    }`}
                    onClick={() => {
                      setSelectedTemplate(template.id);
                      onTemplateSelect?.(template.id);
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <FileText className="h-5 w-5" style={{ color: 'var(--bts-navy)' }} />
                      <div>
                        <p className="text-sm font-medium" style={{ color: 'var(--bts-heading)' }}>
                          {template.name}
                        </p>
                        <p className="text-xs" style={{ color: 'var(--bts-body)' }}>
                          {template.slide_count} slides • {formatDate(template.created_at)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {selectedTemplate === template.id && (
                        <Badge style={{ backgroundColor: 'var(--bts-mid-blue)' }}>
                          Selected
                        </Badge>
                      )}
                      {template.id !== 'bts_master_template' && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteTemplate(template.id);
                          }}
                          className="h-8 w-8 text-red-500 hover:text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Image Upload Section */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2" style={{ color: 'var(--bts-heading)' }}>
            <ImageIcon className="h-5 w-5" style={{ color: 'var(--bts-mid-blue)' }} />
            Image Assets
          </CardTitle>
          <CardDescription style={{ color: 'var(--bts-body)' }}>
            Upload images for slide injection (auto-cropped to fit placeholders)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Upload Button */}
          <div className="flex items-center gap-4">
            <input
              ref={imageInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={handleImageUpload}
              className="hidden"
              id="image-upload"
            />
            <Button
              onClick={() => imageInputRef.current?.click()}
              disabled={uploadingImage}
              variant="outline"
              style={{ borderColor: 'var(--bts-mid-blue)', color: 'var(--bts-mid-blue)' }}
            >
              {uploadingImage ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Image
                </>
              )}
            </Button>
            <p className="text-xs" style={{ color: 'var(--bts-body)' }}>
              Accepted: JPG, PNG, WebP
            </p>
          </div>

          <Separator />

          {/* Image Grid */}
          {loadingImages ? (
            <div className="flex items-center gap-2 py-4" style={{ color: 'var(--bts-body)' }}>
              <Loader2 className="h-4 w-4 animate-spin" />
              Loading images...
            </div>
          ) : images.length === 0 ? (
            <p className="text-sm py-4" style={{ color: 'var(--bts-body)' }}>
              No images uploaded yet.
            </p>
          ) : (
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
              {images.map((image) => (
                <div
                  key={image.id}
                  className="relative group rounded-lg overflow-hidden border border-gray-200 cursor-pointer"
                  onClick={() => onImageSelect?.(image.id, image.url)}
                >
                  <div className="aspect-square">
                    <img
                      src={`http://localhost:3002${image.url}`}
                      alt={image.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteImage(image.id);
                      }}
                      className="h-8 w-8 bg-white/90 text-red-500 hover:text-red-600"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 bg-black/60 p-1">
                    <p className="text-xs text-white truncate">{image.name}</p>
                    <p className="text-xs text-white/70">{image.width}x{image.height}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Info Box */}
      <div className="rounded-lg p-4 text-xs" style={{ backgroundColor: 'var(--bts-gray)', color: 'var(--bts-body)' }}>
        <p className="font-medium mb-1" style={{ color: 'var(--bts-heading)' }}>
          Security & Validation
        </p>
        <ul className="space-y-1 list-disc list-inside">
          <li>Templates are validated for MIME type and file structure</li>
          <li>Only .pptx format accepted (no .ppt, .pdf, or images)</li>
          <li>Images are automatically center-cropped to match placeholder aspect ratios</li>
          <li>All uploaded files are stored securely and can be deleted at any time</li>
        </ul>
      </div>
    </div>
  );
}

export default TemplateManager;
