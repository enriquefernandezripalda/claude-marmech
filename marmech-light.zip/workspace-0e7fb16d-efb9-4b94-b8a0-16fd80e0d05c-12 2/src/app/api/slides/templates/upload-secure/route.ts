/**
 * Secure Template Upload API Route
 * 
 * Handles secure upload of .pptx templates with strict validation.
 */

import { NextRequest, NextResponse } from 'next/server';

const SLIDE_SERVICE_PORT = 3002;

/**
 * POST /api/slides/templates/upload-secure
 * Upload a template with strict MIME type validation
 */
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/templates/upload-secure`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
      return NextResponse.json(
        { error: errorData.detail || 'Upload failed' },
        { status: response.status }
      );
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Template upload error:', error);
    return NextResponse.json(
      { error: 'Failed to connect to template service' },
      { status: 503 }
    );
  }
}
