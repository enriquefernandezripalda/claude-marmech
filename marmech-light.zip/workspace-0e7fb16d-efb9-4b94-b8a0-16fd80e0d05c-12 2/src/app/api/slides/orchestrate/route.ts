/**
 * Orchestration API Route
 * 
 * Main endpoint that coordinates all phases (text, images, charts)
 * to generate a complete BTS-branded presentation.
 */

import { NextRequest, NextResponse } from 'next/server';

const SLIDE_SERVICE_PORT = 3002;

interface OrchestratorRequest {
  template_id: string;
  output_filename?: string;
  slides: Array<{
    slide_index: number;
    text_content?: {
      title?: string;
      subtitle?: string;
      body_paragraphs?: string[];
      custom_placeholders?: Record<string, string>;
    };
    images?: Array<{
      placeholder_idx: number;
      image_id?: string;
      image_source?: string;
    }>;
    chart?: {
      chart_type: string;
      chart_title?: string;
      labels: string[];
      series: Array<{ name: string; values: number[] }>;
      position?: { left?: number; top?: number };
      size?: { width?: number; height?: number };
    };
  }>;
}

/**
 * POST /api/slides/orchestrate
 * Main orchestration endpoint for complete presentation generation
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as OrchestratorRequest;
    
    if (!body.template_id) {
      return NextResponse.json(
        { error: 'template_id is required' },
        { status: 400 }
      );
    }

    if (!body.slides || body.slides.length === 0) {
      return NextResponse.json(
        { error: 'slides array is required and must not be empty' },
        { status: 400 }
      );
    }

    // Call Python service
    const response = await fetch(`http://localhost:${SLIDE_SERVICE_PORT}/orchestrate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
      return NextResponse.json(
        { error: errorData.detail || 'Orchestration failed' },
        { status: response.status }
      );
    }

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Orchestration error:', error);
    return NextResponse.json(
      { error: 'Failed to connect to orchestrator service' },
      { status: 503 }
    );
  }
}
